# YM work packet — R8B.1 opaque child mediation rehearsal

**Work unit:** `YM-R8B1-OPAQUE-CHILD-MEDIATION`
**Target:** synthetic child only
**Local source patching:** forbidden
**Authority:** NONE

Run the packaged mediator unchanged:

```powershell
.\r8b1\windows\run_r8b1_opaque_mediation.ps1 `
  -OutputPath .\R8B1_receipt.raw.json
```

Then:

```powershell
python .\r8b1\evaluate_r8b1.py `
  .\R8B1_receipt.raw.json `
  -o .\R8B1_result.json
```

Expected strongest result:

`R8B1_OPAQUE_MEDIATION_REHEARSAL_READY`

Required invariants:
- mediator authentication = `NOT_PERFORMED`
- child identity = `NOT_PROVED`
- child parent binding verified
- payload handling = `OPAQUE_BYTES_NOT_PARSED`
- child message trust = `UNTRUSTED_CHILD_INPUT`
- raw payload absent from receipt
- child cannot choose principal
- child cannot receive runtime grant
- `NOT_AUTHORIZED / NONE`

The synthetic child payload intentionally contains nested authority-looking text. The pass condition is that the
mediator hashes the raw bytes without interpreting that content as identity or authority.

## R9 gate

Do not start live mediator authentication after this run.

R9 is blocked at:

`R9_DEDICATED_MEDIATOR_BINARY_REQUIRED`

because the current PowerShell mediator runs under a shared interpreter and is not uniquely OS-observable as a
workload principal.

Use privacy seal v2 with source coverage when packaging the result.
