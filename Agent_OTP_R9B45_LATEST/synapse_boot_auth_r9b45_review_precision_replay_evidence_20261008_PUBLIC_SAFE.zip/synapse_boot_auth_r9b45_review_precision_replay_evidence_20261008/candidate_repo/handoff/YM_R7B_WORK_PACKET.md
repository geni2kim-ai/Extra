# YM work packet — R7B hook source/control assessment

**Work unit:** `YM-R7B-HOOK-SOURCE-ASSESSMENT`  
**Mutation/injection:** FORBIDDEN  
**Authority:** NONE

Use the exact PID selected in the R7A local evidence if it is still the same process instance. If that process
has restarted, repeat R7A target discovery first; do not reuse the old PID.

## Assessment

If there is a known project-controlled source/worktree root, supply it. If not, omit `-ControlledRoots`.

```powershell
.\r7b\windows\assess_r7b_target_readonly.ps1 `
  -ProcessId <CURRENT_EXACT_PID> `
  -OperatorLabel "opencode-desktop-agent" `
  -ControlledRoots "<KNOWN_PROJECT_ROOT_IF_ANY>" `
  -OutputPath .\R7B_assessment.json
```

Do not guess a root solely to obtain a favorable result.

Then:

```powershell
python .\r7b\evaluate_r7b_assessment.py `
  .\R7B_assessment.json `
  -o .\R7B_result.json
```

## Expected outcomes

### No controlled source/hook evidence

`R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED`

This is a valid stop result. Select a controlled agent launcher/runner instead of modifying an installed
third-party/opaque binary.

### Binary under a supplied controlled root

`R7B_SOURCE_REVIEW_REQUIRED`

This still does not authorize a hook. Return the exact source root + Git HEAD and the likely in-process entrypoint
for code review.

## Forbidden

- DLL injection
- process memory modification
- binary patching
- command-line capture
- replacing the target with a helper PowerShell process
- declaring `3X/3G/Support` verified from the operator label
- G1/F2/runtime grant

## Distribution

Run the privacy seal on the staged return package before sealing. Include raw↔masked digest lineage and the
CodeDiff usage log.

Strongest permitted conclusion in this phase:
- `R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED`, or
- `R7B_SOURCE_REVIEW_REQUIRED`

Never `WORKLOAD_VERIFIED`.
