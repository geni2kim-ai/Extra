# YM work packet — R7C controlled launcher discovery

**Work unit:** `YM-R7C-CONTROLLED-LAUNCHER-DISCOVERY`  
**Mode:** read-only  
**Authority:** NONE  
**Injection/modification:** forbidden

## Controlled roots

Supply only roots you already know are project-controlled. Do not add an installed application directory merely
to obtain a match.

Examples of acceptable roots are an actual Synapse/Workboard source checkout or staging worktree under your
control.

## Discovery

```powershell
.\r7c\windows\discover_r7c_controlled_launchers_readonly.ps1 `
  -ControlledRoots "<CONTROLLED_ROOT_1>","<CONTROLLED_ROOT_2_IF_ANY>" `
  -OutputPath .\R7C_discovery.raw.json
```

The script may inspect service/NSSM configuration locally to correlate controlled files, but it must not emit raw
service command lines or raw wrapper parameters.

Then evaluate:

```powershell
python .\r7c\evaluate_r7c_discovery.py `
  .\R7C_discovery.raw.json `
  -o .\R7C_result.json
```

## Interpretation

### `R7C_CONTROLLED_LAUNCHER_CANDIDATE_FOUND`

A controlled file has a runtime/service linkage. Return the linked relative path, SHA-256, root Git HEAD, and
service/process linkage for R7D source review.

This is **not workload verification**.

### `R7C_CONTROLLED_SOURCE_FILES_FOUND_NO_RUNTIME_BINDING`

Controlled source candidates exist but are not bound to the observed runtime. Stop and return evidence.

### `R7C_NO_CONTROLLED_LAUNCHER_FOUND`

Do not fall back to the installed OpenCode binary. The next design choice is to select or create a dedicated
controlled agent launcher.

## Privacy source material

Before masking/distribution, create a **local-only** source material file for this evidence source and include each
controlled root as an extra pattern:

```powershell
python .\r7c\distribution\make_privacy_source_material.py `
  --source-id YM-R7C `
  --extra "<CONTROLLED_ROOT_1>" `
  -o .\LOCAL_ONLY_YM_R7C_privacy_source.json
```

If multiple source hosts contributed files, provide one local-only material file per source host.

Run the privacy seal on the staged distributable:

```powershell
python .\r7c\distribution\privacy_seal.py `
  .\distribution_stage `
  --source-material .\LOCAL_ONLY_YM_R7C_privacy_source.json `
  --require-source-id YM-R7C `
  -o .\privacy_seal.json
```

`LOCAL_ONLY_*privacy_source.json` must **not** be packaged.

Any result other than `PASS` blocks sealing.

## Required package

Include:
- masked R7C discovery
- R7C result
- raw↔masked digest lineage
- privacy seal v2
- exact source used
- tests/logs
- CodeDiff usage log

Do not include:
- raw service command lines
- raw NSSM parameters
- command lines
- secrets
- local-only privacy source material

G1/F2/runtime authority remain closed.
