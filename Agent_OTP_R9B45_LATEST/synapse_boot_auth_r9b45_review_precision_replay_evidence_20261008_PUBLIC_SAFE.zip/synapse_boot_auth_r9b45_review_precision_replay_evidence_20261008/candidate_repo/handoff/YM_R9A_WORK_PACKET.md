# YM work packet — R9A dedicated mediator executable candidate

**Work unit:** `YM-R9A-DEDICATED-MEDIATOR-CANDIDATE`
**Authority:** NONE
**Real agent/OpenCode child:** forbidden
**Local source patching:** forbidden

## 1. Build

Use the packaged source unchanged.

```powershell
.\r9a\windows\build_r9a_mediator.ps1 `
  -SourcePath .\r9a\src\DedicatedMediator.cs `
  -OutputExe .\R9A_DedicatedMediator.exe `
  -BuildReceipt .\R9A_build_receipt.json
```

Record exact source/binary/compiler SHA-256.

## 2. Normal synthetic run

```powershell
.\R9A_DedicatedMediator.exe `
  --output .\R9A_receipt.raw.json `
  --mode normal `
  --stdout-limit 4096 `
  --stderr-limit 4096 `
  --timeout-ms 5000
```

Then:

```powershell
python .\r9a\evaluate_r9a.py `
  .\R9A_receipt.raw.json `
  --build-receipt .\R9A_build_receipt.json `
  -o .\R9A_result.json
```

Expected strongest result:

`R9A_DEDICATED_MEDIATOR_CANDIDATE_READY`

It must still say:
- mediator authentication `NOT_PERFORMED`
- child identity `NOT_PROVED`
- `NOT_AUTHORIZED / NONE`

## 3. Required fail-closed negative runs

Run the same binary with:
- `--mode stdout-overflow` -> expected exit **20**
- `--mode stderr-overflow` -> expected exit **21**
- `--mode timeout` -> expected exit **22**

Keep stdout/stderr and `exitcode.txt` for each.

## 4. Stop after R9A

Do **not** start live mediator authentication in this work unit.

R9B may begin only after exact binary/build lineage and all resource-boundary tests pass.

## Packaging

Use privacy seal v2 with source coverage. Include:
- source SHA
- compiler SHA
- binary SHA
- build receipt
- normal receipt/result
- three negative exit-code artifacts
- exact packaged source
- tests/lints
- CodeDiff usage log

Do not package raw synthetic payload or local-only privacy source material.
