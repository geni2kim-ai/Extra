# YM work packet — R9B.2 pre-provisioned registry measurement

**Work unit:** `YM-R9B2-PREPROVISIONED-PINNED-REGISTRY-MEASUREMENT`
**Authority:** NONE
**Authentication:** NOT YET
**Local source patching:** forbidden

## A. Build

Build R9B.1 binaries exactly as before using the packaged R9B.1 build script.

## B. Provision registry in a separate step

Determine the intended local Windows SID explicitly, then:

```powershell
.\r9b2\windows\provision_r9b2_registry.ps1 `
  -BuildReceipt .\R9B1_build_receipt.json `
  -AllowedUserSid "<EXPLICIT_SID>" `
  -DerivedWorkloadId "R9B1_DEDICATED_MEDIATOR_CANDIDATE" `
  -OutputRegistry .\R9B2_registry.raw.json `
  -OutputPin .\R9B2_registry_pin.json
```

After provisioning, do not modify either file.

Record both SHA-256 values.

## C. Run measurement using only the pre-provisioned registry

```powershell
.\r9b2\windows\run_r9b2_measurement.ps1 `
  -MediatorExe .\R9B1_DedicatedMediator.exe `
  -BuildReceipt .\R9B1_build_receipt.json `
  -RegistryPath .\R9B2_registry.raw.json `
  -RegistryPinPath .\R9B2_registry_pin.json `
  -OutputDirectory .\R9B2_measurement
```

Expected harness:
`R9B2_MEASUREMENT_CAPTURE_READY`

The measurement runner must not generate or mutate the registry.

## D. Evaluate

```powershell
python .\r9b2\evaluate_r9b2.py `
  .\R9B2_measurement\R9B2_capture.raw.json `
  --build-receipt .\R9B1_build_receipt.json `
  --registry .\R9B2_registry.raw.json `
  --registry-pin .\R9B2_registry_pin.json `
  -o .\R9B2_result.json
```

Expected strongest result:

`R9B2_PREPROVISIONED_WORKLOAD_MEASUREMENT_READY`

with:
- `registry_binding = EXACT_SHA256_PINNED`
- `registry_created_by_measurement_runner = false`
- `authentication_result = MEASURED_NOT_AUTHENTICATED`
- `stable_node_id = UNBOUND`
- `NOT_AUTHORIZED / NONE`

## E. Required negative pin check

Make a **copy of the pin only** and change its `registry_sha256` to another 64-hex value.

Run the measurement preflight against that copied bad pin.

Expected:
`R9B2_REGISTRY_PIN_MISMATCH`

The server/client should not be started after the pin failure.

## F. Privacy packaging

Evaluate before masking.

Do not distribute the raw SID-bearing registry or raw capture.

Return:
- exact source + source SHA lineage
- build receipt
- result
- measurement summary
- registry pin
- masked registry + raw↔masked registry lineage
- masked capture + raw↔masked capture lineage
- negative pin mismatch evidence
- privacy seal v2 with `YM-R9B2` coverage
- CodeDiff log

## G. Stop

Do not implement R9C credentials yet.

R9B.2 remains measurement only. No G1/F2/runtime grant.
