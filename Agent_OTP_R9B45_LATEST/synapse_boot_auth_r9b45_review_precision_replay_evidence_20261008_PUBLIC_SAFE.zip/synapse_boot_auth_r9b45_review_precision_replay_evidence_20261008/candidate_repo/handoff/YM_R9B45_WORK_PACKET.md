# YM work packet — R9B.4.5 review-evidence precision closure

**Work unit:** `YM-R9B45-REVIEW-EVIDENCE-PRECISION`
**R9C:** BLOCKED
**Source modification on YM:** forbidden

R9B.4.5 closes the remaining non-authoritative review precision findings:

- automatic complete review-safe change inventory, including preflight SID masking;
- exact distinction between packaged evidence bytes and Windows-runtime byte hashes;
- self-describing first/duplicate replay outputs.

## A. Static gates

From `candidate_repo`:

1. package completeness PASS;
2. `pytest r9b4` PASS;
3. PowerShell semantic lint PASS.

## B. Fresh Windows measurement/evaluation

A fresh run is required because the historical duplicate denial did not record its own timestamp/evaluator/input-set binding,
and the historical live evaluation used R9B.4.2 rather than the hardened review evaluator.

Use the R9B.4.5 package toolchain. Rebuild/provision/run measurement normally.

Required normal measurement ceiling remains:

`MEASURED_NOT_AUTHENTICATED / UNBOUND / NOT_AUTHORIZED / NONE`

## C. First live evaluation

Run `evaluate_r9b4.py` against a fresh replay ledger.

Expected:

`R9B4_ONE_TIME_EVALUATION_MEASUREMENT_READY`

The result must contain `execution_binding` with:

- evaluation_started_at_utc
- evaluation_completed_at_utc
- evaluator_cli_sha256
- evaluator_core_sha256
- replay_impl_sha256
- run_id
- measurement_nonce
- input_set_sha256
- input_bindings

## D. Immediate duplicate

Repeat the **exact same command**, with the same evidence, expected pins, and replay-ledger directory.

Expected:

`R9B4_DENIED / RUN_TOKEN_ALREADY_CONSUMED`

The denial result must contain the same:

- evaluator hashes;
- run_id / nonce;
- input_set_sha256;
- input_bindings;

and a later evaluation timestamp.

This is the evidence needed to prove the duplicate request was bound to the same input set and evaluator.

## E. Review-safe generation

Generate the new review-safe set using R9B.4.5 `make_review_safe_bundle.py`.

Required:
- privacy PASS;
- `TRANSFORMATION_RECEIPT.changed_fields` generated automatically;
- `COMPLETE_CHANGE_INVENTORY.json` exists;
- `/preflight/allowed_user_sid` appears as `PRIVACY_TRANSFORM / SID_MASK`;
- all derived SHA rebinding changes are enumerated.

Run `verify_review_safe_set.py`; expected:

`R9B4_OFFLINE_ARTIFACT_SET_BOUND`.

## F. Evidence provenance

Build the HUMAN supplement provenance report with:

```powershell
python .\r9b4\build_evidence_provenance.py `
  --source-zip-sha256 4298587e16c9836da66765aabf7620f22ebc83ebfbd9f387333493e0b0995354 `
  --source-anchor-commit 69a49faa35b56d48e9e3067e5f484b443735df67 `
  --source-anchor-path docs/anchors/20261008_R9B42_YM_return_source_zip_anchor.json `
  --runtime-root <runtime-evidence-supplement-root> `
  -o EVIDENCE_PROVENANCE.json
```

Do not claim the packaged LF files are the original runtime bytes when the harness digest differs.

## G. Regression checks

Reconfirm:
- authority negatives;
- external pin negatives;
- timeout cleanup;
- child-tree cleanup;
- wrong-SID cleanup;
- R9B.4.4 hardened cleanup validation.

## H. Return

Return:
- fresh measurement artifacts;
- first live result;
- duplicate result;
- replay ledger digest;
- review-safe set + complete change inventory;
- offline verifier result;
- evidence provenance report;
- completeness/test/lint logs;
- privacy seal;
- final review ZIP and separate external anchor payload.

## Stop

No stable-node authentication, runtime grant, G1, F2, or R9C activation.
After technical evidence is complete, HUMAN verdict is still mandatory.
