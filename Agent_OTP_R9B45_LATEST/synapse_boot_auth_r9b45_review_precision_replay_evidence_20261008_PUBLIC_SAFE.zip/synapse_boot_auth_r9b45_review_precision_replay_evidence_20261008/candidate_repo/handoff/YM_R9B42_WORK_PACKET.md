# YM work packet — R9B.4.2 verifier PID contract closure

**Work unit:** `YM-R9B42-VERIFIER-PID-CONTRACT-CLOSURE`
**Supersedes:** R9B.4.1 Windows rehearsal only for corrected source
**Source modification on YM:** forbidden
**R9C:** BLOCKED

R9B.4.2 is a narrow correction. The evaluator remains strict; the verifier producer now emits:
- `capture.verifier.pid`
- `completion.verifier_pid`

Both must equal the production harness `server_pid`.

Security ceiling remains:

`MEASURED_NOT_AUTHENTICATED / stable_node_id=UNBOUND / NOT_AUTHORIZED / NONE`

## 0. Package/completeness/tests

Run completeness from `candidate_repo` and pytest `r9b4`.

Required:
- completeness PASS
- producer/evaluator contract tests PASS
- PowerShell semantic lint PASS

## 1. Rebuild all three binaries from exact R9B.4.2 source

Do not reuse R9B.4.1 verifier binary because the verifier source changed.

Run `r9b4/windows/build_r9b4.ps1`.

Record new five operator rehearsal pins.

## 2. Normal Windows measurement

Provision a fresh registry and run `run_r9b4_measurement.ps1`.

Required:
- `R9B4_MEASUREMENT_CAPTURE_READY`
- server/client exit 0
- `capture.verifier.pid == harness.server_pid`
- `completion.verifier_pid == harness.server_pid`
- cleanup has no same-instance residual
- post-run hash verification PASS

## 3. First live one-time evaluation

Use a fresh replay-ledger directory that is retained for the duplicate.

Expected:

`R9B4_ONE_TIME_EVALUATION_MEASUREMENT_READY`

Required:
- evaluation time present
- `authority_ceiling_validated=true`
- `MEASURED_NOT_AUTHENTICATED`
- `UNBOUND / NOT_AUTHORIZED / NONE`
- one replay-consumption record created

## 4. Immediate same-ledger duplicate

Repeat the exact live evaluator command against the same evidence and same ledger.

Expected:

`R9B4_DENIED / RUN_TOKEN_ALREADY_CONSUMED`

This proves only local one-time evaluator consumption.

## 5. Review-safe set

Create the review-safe transformed/re-bound set and run `verify_review_safe_set.py`.

Expected:

`R9B4_OFFLINE_ARTIFACT_SET_BOUND`

Required:
- privacy scan PASS
- no per-field preimage hashes
- capture review set contains verifier pid
- completion review set contains verifier_pid

## 6. Regression confirmations

Reconfirm at minimum:
- five authority-ceiling negatives
- five external-pin preflight negatives
- production-harness timeout cleanup probe
- child-tree cleanup semantics probe
- wrong-SID cleanup

If any prior PASS regresses, stop and return BLOCKED.

## 7. External anchor

Create the final independent-review ZIP and publish its SHA-256 through a separate immutable channel before reviewer access.
Return the anchor reference.

`OUT_OF_BAND_ANCHOR_REQUIRED.txt` alone is not an anchor.

## 8. Return

Return:
- exact source/build hashes
- normal measurement
- first live evaluator success
- duplicate replay denial
- replay ledger digest/count, without sensitive raw content
- review-safe offline PASS
- regression confirmations
- privacy seal
- final external review ZIP SHA + immutable anchor reference
- test/lint/completeness logs

## Stop

No R9C, stable node binding, runtime grant, G1 or F2.
A Windows PASS still requires independent/HUMAN review.
