# YM work packet — R6.3 unmodified launch retest

**Work unit:** `YM-R6.3-UNMODIFIED-LAUNCH-RETEST`
**Local source patching:** FORBIDDEN
**Authority effect:** NONE
**G1/F2/runtime grant:** FORBIDDEN

## Goal

Verify that the packaged R6.3 runner closes the exact R6.2 launch-plumbing defect without a local patch.

## Execute

Run the packaged:

`r6/run_r6_synthetic_loopback.ps1`

from a fresh evidence directory.

## Required positive evidence

- packaged runner source SHA recorded before execution
- no local patch/diff
- `R6_SYNTHETIC_LOOPBACK_PASS`
- `R6_server_completion.json`
- completion capture SHA equals raw capture SHA
- pipe/session binding matches
- `R6_runner_status.json`
- if child ExitCode remains unavailable:
  `server_exit_code_available=false` plus verified completion marker is acceptable
- policy result:
  `WORKLOAD_PROVED_OFFLINE / NOT_AUTHORIZED / NONE`

## Required negative evidence

Repeat the three evaluator-only negatives:
- claimed node mismatch
- selector SHA mismatch
- selector SID mismatch

Each must preserve:
- evaluator stdout
- evaluator stderr
- `exitcode.txt=2`

## Packaging

Include:
- exact packaged source used
- `NO_LOCAL_PATCH` marker
- raw SHA-256 → masked SHA-256 lineage
- redacted workspace paths in distributable logs
- updated `PR_CODEDIFF_USAGE_LOG.jsonl`

## Pass condition

Only an unmodified packaged-runner PASS may return:

`R6_3_UNMODIFIED_NAMED_PIPE_CAPTURE_PASS`

Only then may R7A read-only real-workload discovery start.
