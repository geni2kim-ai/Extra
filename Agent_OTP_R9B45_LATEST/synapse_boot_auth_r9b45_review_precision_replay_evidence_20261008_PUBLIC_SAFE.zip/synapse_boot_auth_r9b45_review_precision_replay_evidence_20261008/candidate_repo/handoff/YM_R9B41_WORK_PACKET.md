# HISTORICAL — DO NOT RUN

Superseded by `YM_R9B42_WORK_PACKET.md` after real Windows execution exposed a verifier PID producer/evaluator contract mismatch.
