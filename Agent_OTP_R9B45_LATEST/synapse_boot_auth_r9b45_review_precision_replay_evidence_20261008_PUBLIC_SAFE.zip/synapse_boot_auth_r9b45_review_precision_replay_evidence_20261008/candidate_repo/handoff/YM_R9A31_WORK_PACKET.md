# YM work packet — R9A.3.1 portable matrix harness retest

**Work unit:** `YM-R9A31-PORTABLE-MATRIX-HARNESS`
**Target binary:** rebuild the unchanged R9A.3 mediator + synthetic child from packaged R9A.3 source
**Authority:** NONE
**Local patching:** forbidden

## Purpose

R9A.3 mediator functionality already produced normal 0 and negative 20/21/22 on YM.

This work unit validates only the replacement matrix evidence harness.

## Steps

1. Build R9A.3 exactly as before with packaged `r9a3/windows/build_r9a3.ps1`.
2. Run the **new** packaged runner:

```powershell
.\r9a31\windows\run_r9a31_matrix.ps1 `
  -MediatorExe .\R9A3_DedicatedMediator.exe `
  -OutputDirectory .\R9A31_matrix
```

Required:
- `normal.exitcode.txt = 0` + receipt present
- `stdout_overflow.exitcode.txt = 20` + receipt absent
- `stderr_overflow.exitcode.txt = 21` + receipt absent
- `timeout.exitcode.txt = 22` + receipt absent
- `matrix_summary.json.status = MATRIX_PASS`
- no cmd.exe workaround
- no source patch

If a first-execution transient hold occurs, preserve that first failure separately and allow **at most one**
confirmatory rerun. Do not overwrite the first-run evidence and do not grind retries.

R9B in this package is design/policy prep only; do not start live attestation yet.

Return privacy-sealed evidence, exact sources, build receipt, all four matrix artifacts and CodeDiff usage log.
