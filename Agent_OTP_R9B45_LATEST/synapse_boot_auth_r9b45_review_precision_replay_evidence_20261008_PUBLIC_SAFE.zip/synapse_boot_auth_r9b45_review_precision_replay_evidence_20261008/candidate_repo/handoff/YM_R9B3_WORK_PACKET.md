# YM work packet — R9B.3 externally pinned, run-bound measurement

**Work unit:** `YM-R9B3-EXTERNAL-PIN-RUN-BINDING-REHEARSAL`
**Authority:** NONE
**Authentication:** NOT YET
**Local source patching:** forbidden

## 0. Gate

Verify the issued ZIP SHA-256 first. Read `r9b3/EXPECTED_ISSUED_SOURCE_HASHES.json`.

This package does not have a trusted CodeDiff gate. Do not treat SHADOW output as approval.

## 1. Build R9B.3

```powershell
.\r9b3\windows\build_r9b3.ps1 `
  -MediatorSource .\r9b3\src\DedicatedMediator.cs `
  -ChildSource .\r9b3\src\SyntheticChild.cs `
  -MediatorExe .\R9B3_DedicatedMediator.exe `
  -ChildExe .\R9B3_SyntheticChild.exe `
  -BuildReceipt .\R9B3_build_receipt.json
```

Record the exact mediator binary SHA from the receipt/console as an **operator input**. Do not allow the measurement script to discover a replacement expected value.

## 2. Provision registry — separate step, no overwrite

Determine the intended local Windows SID explicitly.

```powershell
python .\r9b3\provision_registry.py `
  --build-receipt .\R9B3_build_receipt.json `
  --mediator-exe .\R9B3_DedicatedMediator.exe `
  --allowed-user-sid "<EXPLICIT_SID>" `
  --derived-workload-id "R9B3_DEDICATED_MEDIATOR_CANDIDATE" `
  -o .\R9B3_registry.raw.json
```

The command refuses an existing output. Record the printed `registry_sha256` separately. Do not edit the registry after this point.

## 3. Run measurement with explicit expected hashes

Use:

- `EXPECTED_REGISTRY_SHA256` = recorded registry SHA from step 2;
- `EXPECTED_MEDIATOR_SHA256` = recorded binary SHA from step 1;
- `EXPECTED_SERVER_SCRIPT_SHA256` = `r9b3/EXPECTED_ISSUED_SOURCE_HASHES.json` → `r6_server_script`;
- `EXPECTED_CAPTURE_SOURCE_SHA256` = same file → `r6_capture_source`.

```powershell
.\r9b3\windows\run_r9b3_measurement.ps1 `
  -MediatorExe .\R9B3_DedicatedMediator.exe `
  -BuildReceipt .\R9B3_build_receipt.json `
  -RegistryPath .\R9B3_registry.raw.json `
  -ExpectedRegistrySha256 "<EXPECTED_REGISTRY_SHA256>" `
  -ExpectedMediatorSha256 "<EXPECTED_MEDIATOR_SHA256>" `
  -ExpectedServerScriptSha256 "<EXPECTED_SERVER_SCRIPT_SHA256>" `
  -ExpectedCaptureSourceSha256 "<EXPECTED_CAPTURE_SOURCE_SHA256>" `
  -OutputDirectory .\R9B3_measurement
```

Preflight must finish before either server or client starts.

Expected harness status:

`R9B3_MEASUREMENT_CAPTURE_READY`

## 4. Evaluate immediately in live-freshness mode

```powershell
python .\r9b3\evaluate_r9b3.py `
  .\R9B3_measurement\R9B3_capture.raw.json `
  --build-receipt .\R9B3_build_receipt.json `
  --registry .\R9B3_registry.raw.json `
  --run-context .\R9B3_measurement\R9B3_run_context.json `
  --harness-summary .\R9B3_measurement\measurement_harness_summary.json `
  --server-completion .\R9B3_measurement\R9B3_server_completion.json `
  --mediator-exe .\R9B3_DedicatedMediator.exe `
  --server-script .\r6\windows\invoke_r6_capture_server.ps1 `
  --capture-source .\r6\windows\R6NamedPipeCapture.cs `
  --expected-registry-sha256 "<EXPECTED_REGISTRY_SHA256>" `
  --expected-mediator-sha256 "<EXPECTED_MEDIATOR_SHA256>" `
  --expected-server-script-sha256 "<EXPECTED_SERVER_SCRIPT_SHA256>" `
  --expected-capture-source-sha256 "<EXPECTED_CAPTURE_SOURCE_SHA256>" `
  -o .\R9B3_result.json
```

Expected strongest result:

`R9B3_EXTERNALLY_PINNED_RUN_BOUND_MEASUREMENT_READY`

and simultaneously:

- `authentication_result = MEASURED_NOT_AUTHENTICATED`
- `stable_node_id = UNBOUND`
- `loaded_image_hash_verified = false`
- `authorization_status = NOT_AUTHORIZED`
- `authority_effect = NONE`
- `review_gate = UNSATISFIED_CODEDIFF_ADVERSARIAL_REQUIRED`

For later package review, `--offline-artifact-check` may be used. It may only return `R9B3_OFFLINE_ARTIFACT_SET_BOUND`, never the live READY status.

## 5. Required negative tests

### N1 — bad registry expected SHA

Change only the supplied expected registry SHA literal to another lowercase 64-hex value.

Expected preflight result:

`REGISTRY_EXTERNAL_SHA_MISMATCH`

Verify no server/client process was started and no capture was produced.

### N2 — bad R6 server script expected SHA

Change only `ExpectedServerScriptSha256`.

Expected:

`SERVER_SCRIPT_EXTERNAL_SHA_MISMATCH`

Again, no server/client start.

### N3 — bad R6 C# source expected SHA

Change only `ExpectedCaptureSourceSha256`.

Expected:

`CAPTURE_SOURCE_EXTERNAL_SHA_MISMATCH`

### N4 — replay mutation

Make copies of a successful artifact set and change one at a time:

- `captured_at_utc` to 2019;
- captured session ID;
- captured pipe name;
- captured measurement nonce.

Expected typed DENY for every mutation. Do not overwrite the successful originals.

### N5 — malformed evaluator input

Use malformed JSON and a top-level JSON list in copies. Expected:

- exit 2;
- `R9B3_DENIED` output file always created;
- no Python traceback.

### N6 — cleanup path

Use a separately provisioned registry with a valid SID that does not match the client token. Preserve all harness failure artifacts and verify the server process is not left running after the script returns.

## 6. Privacy packaging

Generate local-only privacy material including the current SID:

```powershell
python .\r9b3\distribution\make_privacy_source_material.py `
  --source-id YM-R9B3 `
  --auto-current-sid `
  -o .\R9B3_privacy_source.local.json
```

Mask raw capture and registry **after** live evaluation:

```powershell
python .\r9b3\distribution\mask_r9b3_capture.py `
  .\R9B3_measurement\R9B3_capture.raw.json `
  -o .\R9B3_capture.masked.json `
  --lineage .\R9B3_capture_masking_lineage.json

python .\r9b3\distribution\mask_r9b3_registry.py `
  .\R9B3_registry.raw.json `
  -o .\R9B3_registry.masked.json `
  --lineage .\R9B3_registry_masking_lineage.json
```

Run the distributable privacy seal against the return package with `YM-R9B3` source coverage. The seal now scans evidence for SID-like values and emits no literal commitments.

Do **not** package:

- raw capture;
- raw registry;
- raw preflight file (contains SID);
- local privacy source material.

## 7. Return evidence

Return:

- exact packaged source hashes;
- build receipt;
- operator-supplied expected SHA values (not SID);
- `R9B3_result.json`;
- run context;
- harness summary;
- server completion;
- masked capture + lineage;
- masked registry + lineage;
- all negative test results;
- failure cleanup evidence;
- privacy seal v3;
- pytest/lint results;
- CodeDiff log.

## 8. Stop

Do not start R9C credential work in this unit.

R9B.3 remains measurement only and the CodeDiff ADVERSARIAL/HUMAN gate is still unsatisfied.
