# YM work packet — R7A one-workload read-only discovery

**Work unit:** `YM-R7A-ONE-REAL-WORKLOAD-DISCOVERY`  
**Authority:** NONE  
**Mutation:** forbidden  
**G1/F2/runtime grant:** forbidden

## 1. Find candidates narrowly

Choose a regex relevant to the actual local agent/runtime names. Do not use `.*`.

```powershell
.\r7a\windows\discover_r7a_candidates_readonly.ps1 `
  -NameRegex "synapse|agent|runner|workboard|opencode|python|powershell" `
  -OutputPath .\R7A_candidates.json
```

This output is discovery only. A process name does not prove 3X/3G/Support.

## 2. Select exactly one target

Selection must be based on the actual running process/service relationship, not just the desired label.

```powershell
.\r7a\windows\collect_r7a_target_readonly.ps1 `
  -ProcessId <EXACT_PID> `
  -OperatorLabel "<candidate label only>" `
  -OutputPath .\R7A_target.json
```

## 3. Evaluate

```powershell
python .\r7a\evaluate_r7a_target.py .\R7A_target.json -o .\R7A_result.json
```

Expected strongest result:

`R7A_DISCOVERY_EVIDENCE_READY`

with:
- `operator_label_trust=UNVERIFIED_CLAIM`
- `authentication_result=NOT_PERFORMED`
- `authorization_status=NOT_AUTHORIZED`
- `authority_effect=NONE`

## 4. Distribution privacy seal

Before creating a return ZIP, stage only the files intended for distribution and run:

```powershell
python .\r7a\distribution\privacy_seal.py `
  .\distribution_stage `
  -o .\privacy_seal.json
```

The scanner derives current account/computer/profile/temp identifiers from the environment and searches raw bytes
in UTF-8, UTF-16LE and UTF-16BE forms.

A result other than `PASS` blocks distribution.

If extra local identifiers need protection, place them in a **local-only** patterns file and pass
`--patterns-file`. Do not include that patterns file in the return ZIP.

## Return package

Include:
- R7A_candidates.json
- R7A_target.json
- R7A_result.json
- exact collector/evaluator source used
- privacy_seal.json
- raw↔masked digest lineage
- tests/logs
- CodeDiff usage log

Do not include raw command lines, secrets, or unredacted CLIXML metadata.

## Stop condition

If the selected process cannot be confidently tied to an actual project workload:

`R7A_TARGET_NOT_ATTRIBUTABLE`

If discovery succeeds but the process has no known native client hook:

`R7B_CLIENT_HOOK_ASSESSMENT_REQUIRED`

Do not substitute a helper PowerShell process for the real workload.
