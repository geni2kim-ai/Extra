# YM work packet — R8 dedicated controlled launcher synthetic rehearsal

**Work unit:** `YM-R8-CONTROLLED-LAUNCHER-SYNTHETIC-REHEARSAL`  
**Target:** synthetic child only  
**Installed OpenCode modification:** forbidden  
**Authority:** NONE

## Why

R7D completed a bounded source-root search and found no existing Synapse source checkout on YM. Do not widen the
search merely to force a hit.

R8 tests a new controlled launcher boundary with a short-lived synthetic child.

## Execute

Run the packaged script unchanged:

```powershell
.\r8\windows\run_r8_synthetic_controlled_launcher.ps1 `
  -OutputPath .\R8_receipt.raw.json
```

Then:

```powershell
python .\r8\evaluate_r8_receipt.py `
  .\R8_receipt.raw.json `
  -o .\R8_result.json
```

Expected strongest result:

`R8_CONTROLLED_LAUNCHER_REHEARSAL_READY`

Required invariants:
- child PID source = `System.Diagnostics.Process.Start`
- creation time recheck equal
- executable path recheck equal
- expected SHA == observed SHA
- `child_identity_claim=NOT_PROVED`
- `launcher_proves_child_identity=false`
- `child_native_pipe_hook=NOT_IMPLEMENTED`
- `NOT_AUTHORIZED / NONE`

## Important

A successful controlled launch **does not authenticate the child**.

Do not replace the synthetic child with OpenCode or another agent in this work unit.

The following phase, R8B, must first define how an opaque child is mediated through a controlled boundary without
pretending the launcher is the child.

## Packaging

Use privacy seal v2 and source material coverage. Include exact source, tests, raw↔masked lineage and CodeDiff
usage log. Local-only privacy pattern material must not be packaged.
