# YM work packet — R7D locate actual controlled source root, then R7C.1

**Work unit:** `YM-R7D-CONTROLLED-SOURCE-ROOT-LOCATOR`  
**Mode:** read-only  
**Authority:** NONE

## Why

The prior R7C root was a sandbox staging workspace, not a Synapse/Workboard source checkout. Also, R7C's filename
prefilter could miss neutral-named files referenced by a runtime configuration.

## A. Locate source-root candidates

Choose one or more **bounded parent directories that you already expect may contain your project source**.
Do not use the entire system drive unless there is no narrower choice.

```powershell
python .\r7d\locate_controlled_roots.py `
  --search-root "<BOUNDED_PARENT_1>" `
  --search-root "<BOUNDED_PARENT_2_IF_NEEDED>" `
  -o .\R7D_roots.raw.json

python .\r7d\evaluate_root_candidates.py `
  .\R7D_roots.raw.json `
  -o .\R7D_result.json
```

A candidate with >=2 distinct known fingerprints may return:

`R7D_SOURCE_ROOT_CANDIDATE_FOUND`

This is discovery only, not proof of ownership or workload identity.

## B. Rerun reference-first R7C.1

Only after selecting a root that you actually recognize as project-controlled:

```powershell
.\r7c1\windows\discover_r7c1_reference_first_readonly.ps1 `
  -ControlledRoots "<SELECTED_CONTROLLED_SOURCE_ROOT>" `
  -OutputPath .\R7C1_discovery.raw.json

python .\r7c1\evaluate_r7c1.py `
  .\R7C1_discovery.raw.json `
  -o .\R7C1_result.json
```

Strongest useful result:

`R7C1_CONTROLLED_RUNTIME_CANDIDATE_FOUND`

Then return the candidate relative path, SHA-256, root Git HEAD if present, and runtime-link metadata for source
review.

## Stop results are valid

- `R7D_NO_SOURCE_ROOT_CANDIDATE`
- `R7D_WEAK_SOURCE_ROOT_CANDIDATE_ONLY`
- `R7C1_NO_CANDIDATE_IN_SUPPLIED_ROOTS`
- `R7C1_HEURISTIC_SOURCE_ONLY`

Do not fall back to the installed OpenCode binary.

## Privacy

Use privacy seal v2 with source material for every source host contributing evidence. Local-only privacy material
must not be packaged.

## Forbidden

- modification/injection
- command-line capture
- raw service/wrapper reference export
- G1/F2/runtime authority
- labeling a root/workload verified from filename matches alone
