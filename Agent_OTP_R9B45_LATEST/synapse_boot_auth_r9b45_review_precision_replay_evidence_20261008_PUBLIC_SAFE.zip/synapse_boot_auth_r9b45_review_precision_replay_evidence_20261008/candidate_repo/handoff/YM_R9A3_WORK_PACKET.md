# YM work packet — R9A.3 native handle-bound process evidence

**Work unit:** `YM-R9A3-NATIVE-HANDLE-PROCESS-EVIDENCE`
**Authority:** NONE
**Real agent/OpenCode child:** forbidden
**Local source patching:** forbidden

## 1. Build

```powershell
.\r9a3\windows\build_r9a3.ps1 `
  -MediatorSource .\r9a3\src\DedicatedMediator.cs `
  -ChildSource .\r9a3\src\SyntheticChild.cs `
  -MediatorExe .\R9A3_DedicatedMediator.exe `
  -ChildExe .\R9A3_SyntheticChild.exe `
  -BuildReceipt .\R9A3_build_receipt.json
```

## 2. Run matrix

```powershell
.\r9a3\windows\run_r9a3_matrix.ps1 `
  -MediatorExe .\R9A3_DedicatedMediator.exe `
  -OutputDirectory .\R9A3_matrix
```

Required:
- normal -> exit 0 + receipt
- stdout overflow -> exit 20 + no receipt
- stderr overflow -> exit 21 + no receipt
- timeout -> exit 22 + no receipt

Normal receipt must prove:
- `handle_pid_matches_start_pid=true`
- `creation_time_source=GET_PROCESS_TIMES`
- creation time recheck equal
- `path_source=QUERY_FULL_PROCESS_IMAGE_NAME`
- `parent_pid_source=TOOLHELP32_SNAPSHOT`
- `parent_binding_verified=true`
- exact child build SHA
- `process_observation_mode=NATIVE_HANDLE_BOUND`
- WMI not used for runtime evidence
- child identity remains `NOT_PROVED`
- `NOT_AUTHORIZED / NONE`

## 3. Evaluate

```powershell
python .\r9a3\evaluate_r9a3.py `
  .\R9A3_matrix\normal.receipt.json `
  --build-receipt .\R9A3_build_receipt.json `
  -o .\R9A3_result.json
```

Expected strongest result:

`R9A3_NATIVE_HANDLE_MEDIATOR_CANDIDATE_READY`

## 4. Stop

Do not begin R9B authentication until the complete 0/20/21/22 matrix and privacy seal return for review.

Package exact source/build/normal receipt/result/all matrix exit artifacts, privacy seal v2 with source coverage,
tests/lints, and the CodeDiff usage log.
