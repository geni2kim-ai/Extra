# YM work packet — R9B.1 local Named Pipe workload measurement

**Work unit:** `YM-R9B1-LOCAL-NAMED-PIPE-WORKLOAD-MEASUREMENT`
**Authority:** NONE
**Authentication target:** NONE — measurement only
**Real agent/OpenCode child:** forbidden
**Local source patching:** forbidden

## 1. Build R9B.1 binaries

```powershell
.\r9b1\windows\build_r9b1.ps1 `
  -MediatorSource .\r9b1\src\DedicatedMediator.cs `
  -ChildSource .\r9b1\src\SyntheticChild.cs `
  -MediatorExe .\R9B1_DedicatedMediator.exe `
  -ChildExe .\R9B1_SyntheticChild.exe `
  -BuildReceipt .\R9B1_build_receipt.json
```

## 2. Regression: run R9A.3.1 matrix runner on the new binary

```powershell
.\r9a31\windows\run_r9a31_matrix.ps1 `
  -MediatorExe .\R9B1_DedicatedMediator.exe `
  -OutputDirectory .\R9B1_synthetic_matrix
```

Expected 0/20/21/22. Preserve a first-execution transient separately and allow at most one confirmatory rerun.

## 3. Local Named Pipe measurement

```powershell
.\r9b1\windows\run_r9b1_measurement.ps1 `
  -MediatorExe .\R9B1_DedicatedMediator.exe `
  -BuildReceipt .\R9B1_build_receipt.json `
  -OutputDirectory .\R9B1_measurement
```

This launches the existing R6 capture server and the dedicated mediator's local pipe measurement mode.

The mediator sends an empty JSON object. No node/workload identity claim is allowed.

## 4. Evaluate raw local capture

```powershell
python .\r9b1\evaluate_r9b1.py `
  .\R9B1_measurement\R9B1_capture.raw.json `
  --build-receipt .\R9B1_build_receipt.json `
  --registry .\R9B1_measurement\local_verifier_registry.raw.json `
  -o .\R9B1_result.json
```

Expected strongest result:

`R9B1_LOCAL_WORKLOAD_MEASUREMENT_READY`

with:

`authentication_result = MEASURED_NOT_AUTHENTICATED`
`stable_node_id = UNBOUND`
`authorization_status = NOT_AUTHORIZED`
`authority_effect = NONE`

## 5. Privacy packaging

Evaluate **before masking**.

Then create a distributable masked capture:

```powershell
python .\r9b1\distribution\mask_r9b1_capture.py `
  .\R9B1_measurement\R9B1_capture.raw.json `
  -o .\R9B1_capture.masked.json `
  --lineage .\R9B1_capture_masking_lineage.json
```

Do not package:
- raw capture
- raw local registry
- local-only privacy source material

Package:
- exact source + SHA lineage
- build receipt after ordinary privacy masking
- `R9B1_result.json`
- `measurement_harness_summary.json`
- masked capture + masking lineage
- server/client exit/stdout/stderr after privacy check
- synthetic 0/20/21/22 regression matrix
- privacy seal v2 with `YM-R9B1` source coverage
- tests/lints
- CodeDiff usage log

## 6. Stop

Do not create a runtime grant or bind stable node identity.

A R9B.1 PASS proves only a local measured workload instance. It does **not** prove possession of a protected
installation credential.

Return evidence for review before credential/challenge work.
