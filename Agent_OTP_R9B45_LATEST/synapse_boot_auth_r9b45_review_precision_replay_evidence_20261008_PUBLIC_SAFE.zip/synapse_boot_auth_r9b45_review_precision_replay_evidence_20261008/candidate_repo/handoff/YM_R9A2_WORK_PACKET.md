# YM work packet — R9A.2 observation-race remediation

**Work unit:** `YM-R9A2-INSTANCE-ANCHORED-PROCESS-OBSERVATION`
**Authority:** NONE
**Real agent/OpenCode child:** forbidden
**Local source patching:** forbidden

## 1. Build

```powershell
.\r9a2\windows\build_r9a2.ps1 `
  -MediatorSource .\r9a2\src\DedicatedMediator.cs `
  -ChildSource .\r9a2\src\SyntheticChild.cs `
  -MediatorExe .\R9A2_DedicatedMediator.exe `
  -ChildExe .\R9A2_SyntheticChild.exe `
  -BuildReceipt .\R9A2_build_receipt.json
```

## 2. Run matrix

```powershell
.\r9a2\windows\run_r9a2_matrix.ps1 `
  -MediatorExe .\R9A2_DedicatedMediator.exe `
  -OutputDirectory .\R9A2_matrix
```

Required:
- normal -> exit 0 + receipt
- stdout overflow -> exit 20 + no receipt
- stderr overflow -> exit 21 + no receipt
- timeout -> exit 22 + no receipt

The normal receipt must show:
- `wmi_path_resolved=true`
- observation attempts >= 1
- process creation time equal before/after
- `dotnet_path_matches_expected=true`
- exact mediator/child build SHA binding
- `child_identity=NOT_PROVED`
- `NOT_AUTHORIZED / NONE`

## 3. Evaluate

```powershell
python .\r9a2\evaluate_r9a2.py `
  .\R9A2_matrix\normal.receipt.json `
  --build-receipt .\R9A2_build_receipt.json `
  -o .\R9A2_result.json
```

Expected strongest result:

`R9A2_DEDICATED_MEDIATOR_OBSERVATION_BOUND_READY`

## 4. Stop

Do not start R9B authentication yet. Return evidence first.

Use privacy seal v2 with source coverage. Include exact source, build receipt, normal receipt/result, all four matrix
exit-code/stdout/stderr artifacts, tests/lints, and CodeDiff usage log.
