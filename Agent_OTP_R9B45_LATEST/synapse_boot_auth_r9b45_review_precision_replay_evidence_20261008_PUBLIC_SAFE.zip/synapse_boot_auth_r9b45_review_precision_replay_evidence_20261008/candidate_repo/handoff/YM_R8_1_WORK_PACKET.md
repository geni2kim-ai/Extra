# YM work packet — R8.1 parent-bound launcher retest

**Work unit:** `YM-R8.1-PARENT-BOUND-CONTROLLED-LAUNCHER`
**Target:** synthetic child only
**Local source patching:** forbidden
**Authority:** NONE

Run the packaged R8.1 launcher unchanged.

Expected strongest result:

`R8_1_CONTROLLED_LAUNCHER_PARENT_BOUND_READY`

Required:
- child PID source = `System.Diagnostics.Process.Start`
- OS-observed `child.parent_pid == launcher.launcher_pid`
- `parent_pid_matches_launcher=true`
- `boundary.os_parent_binding_verified=true`
- creation time/path/SHA rechecks match
- `child_identity=NOT_PROVED`
- `child_native_pipe_hook=NOT_IMPLEMENTED`
- `NOT_AUTHORIZED / NONE`

Do not substitute OpenCode or a real agent for the synthetic child.

R8B is design/prep only in this package and must not be treated as live authentication.

Package the return using privacy seal v2 and exact source SHA lineage.
