# YM work packet — R9A.1 packaged synthetic-child helper

**Work unit:** `YM-R9A1-PACKAGED-SYNTHETIC-CHILD-HELPER`
**Authority:** NONE
**Real agent/OpenCode child:** forbidden
**Local source patching:** forbidden

## 1. Build both packaged executables

```powershell
.\r9a1\windows\build_r9a1.ps1 `
  -MediatorSource .\r9a1\src\DedicatedMediator.cs `
  -ChildSource .\r9a1\src\SyntheticChild.cs `
  -MediatorExe .\R9A1_DedicatedMediator.exe `
  -ChildExe .\R9A1_SyntheticChild.exe `
  -BuildReceipt .\R9A1_build_receipt.json
```

Expected build status:

`R9A1_BUILD_CANDIDATE_READY`

The build receipt must bind:
- mediator source SHA
- child source SHA
- mediator binary SHA
- child binary SHA
- compiler SHA

## 2. Run the packaged matrix

```powershell
.\r9a1\windows\run_r9a1_matrix.ps1 `
  -MediatorExe .\R9A1_DedicatedMediator.exe `
  -OutputDirectory .\R9A1_matrix
```

Required:
- normal -> exit 0 + receipt
- stdout overflow -> exit 20 + no receipt
- stderr overflow -> exit 21 + no receipt
- timeout -> exit 22 + no receipt

## 3. Evaluate normal receipt

```powershell
python .\r9a1\evaluate_r9a1.py `
  .\R9A1_matrix\normal.receipt.json `
  --build-receipt .\R9A1_build_receipt.json `
  -o .\R9A1_result.json
```

Expected strongest result:

`R9A1_DEDICATED_MEDIATOR_AND_CHILD_CANDIDATE_READY`

Still required:
- mediator authentication `NOT_PERFORMED`
- child identity `NOT_PROVED`
- child message `UNTRUSTED_CHILD_INPUT`
- `NOT_AUTHORIZED / NONE`
- no G1/F2/runtime grant

## 4. Stop after R9A.1

Do not start R9B live workload authentication in this work unit.

R9B preparation begins only after:
- both binary/source lineages match,
- normal receipt evaluates,
- all three negative exit codes match,
- privacy seal v2 passes.

## Packaging

Return exact source, build receipt, normal receipt/result, matrix stdout/stderr/exitcode files, source SHA lineage,
privacy seal v2 with source coverage, tests/lints, and CodeDiff usage log.

Do not package raw synthetic payload or local-only privacy source material.
