# R9A.3 — native handle-bound process evidence

R9A.2 showed that WMI `ExecutablePath` and `.NET Process.StartTime` property observation can fail at different
stages on YM even when the packaged child process is created.

R9A.3 stops treating those provider/property observations as the security anchor.

For the child created by `Process.Start()`, it uses the exact process handle to obtain:
- process ID via `GetProcessId`
- creation time via `GetProcessTimes`
- executable path via `QueryFullProcessImageName`

Parent PID is read from a documented Toolhelp process snapshot. Before and after parent observation, the exact
child handle's PID and creation time are revalidated.

WMI/System.Management is removed from the runtime evidence path.

The stdout/stderr bounds, opaque payload handling, binary SHA lineage and authority=NONE invariants remain.
