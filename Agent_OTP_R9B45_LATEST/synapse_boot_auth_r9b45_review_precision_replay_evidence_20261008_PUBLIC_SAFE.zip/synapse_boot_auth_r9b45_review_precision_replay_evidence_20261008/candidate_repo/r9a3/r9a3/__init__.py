"""R9A.3 native handle-bound process evidence."""
