from __future__ import annotations
from typing import Any
import re
class Denied(RuntimeError):
    def __init__(self,code:str): super().__init__(code); self.code=code
HEX64=re.compile(r"[0-9a-f]{64}")
def _hex(v:object)->bool: return isinstance(v,str) and HEX64.fullmatch(v) is not None

def evaluate(r:dict[str,Any],b:dict[str,Any])->dict[str,Any]:
    if r.get("schema_version")!="SYNAPSE-R9A3-NATIVE-HANDLE-MEDIATOR-CANDIDATE-1": raise Denied("SCHEMA_VERSION_MISMATCH")
    if b.get("schema_version")!="SYNAPSE-R9A3-BUILD-RECEIPT-1": raise Denied("BUILD_SCHEMA_VERSION_MISMATCH")
    if r.get("authority_effect")!="NONE" or b.get("authority_effect")!="NONE": raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if r.get("authorization_status")!="NOT_AUTHORIZED" or b.get("authorization_status")!="NOT_AUTHORIZED": raise Denied("AUTH_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if r.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")

    med=r.get("mediator") or {}
    if med.get("status")!="CANDIDATE" or med.get("authentication_result")!="NOT_PERFORMED": raise Denied("MEDIATOR_STATUS_INVALID")
    if med.get("executable_name")!=b.get("mediator_binary_name"): raise Denied("MEDIATOR_NAME_MISMATCH")
    if not _hex(med.get("executable_sha256")) or med.get("executable_sha256")!=b.get("mediator_binary_sha256"): raise Denied("MEDIATOR_BUILD_SHA_MISMATCH")

    c=r.get("child_instance") or {}
    if c.get("identity")!="NOT_PROVED" or b.get("child_identity")!="NOT_PROVED": raise Denied("CHILD_IDENTITY_OVERCLAIM")
    if c.get("executable_name")!=b.get("child_binary_name"): raise Denied("CHILD_NAME_MISMATCH")
    if not _hex(c.get("executable_sha256")) or c.get("executable_sha256")!=b.get("child_binary_sha256"): raise Denied("CHILD_BUILD_SHA_MISMATCH")
    if c.get("handle_pid_matches_start_pid") is not True or c.get("handle_pid")!=c.get("pid"): raise Denied("HANDLE_PID_BINDING_INVALID")
    if c.get("creation_time_source")!="GET_PROCESS_TIMES": raise Denied("CREATION_TIME_SOURCE_INVALID")
    if c.get("path_source")!="QUERY_FULL_PROCESS_IMAGE_NAME": raise Denied("PATH_SOURCE_INVALID")
    if c.get("parent_pid_source")!="TOOLHELP32_SNAPSHOT": raise Denied("PARENT_SOURCE_INVALID")
    if c.get("creation_time_filetime_100ns")!=c.get("creation_time_rechecked_filetime_100ns"): raise Denied("CHILD_INSTANCE_RECHECK_FAILED")
    if c.get("parent_binding_verified") is not True or c.get("parent_pid")!=med.get("pid"): raise Denied("CHILD_PARENT_BINDING_INVALID")
    if not isinstance(c.get("parent_observation_attempts"),int) or c["parent_observation_attempts"]<1: raise Denied("PARENT_ATTEMPTS_INVALID")
    if c.get("same_directory_binding_verified") is not True: raise Denied("DIRECTORY_BINDING_REQUIRED")

    msg=r.get("child_message") or {}
    if msg.get("payload_handling")!="OPAQUE_BYTES_NOT_PARSED" or msg.get("trust")!="UNTRUSTED_CHILD_INPUT": raise Denied("CHILD_MESSAGE_TRUST_INVALID")
    if msg.get("payload_content_in_receipt") is not False or not _hex(msg.get("payload_sha256")): raise Denied("PAYLOAD_RECEIPT_INVALID")

    rb=r.get("resource_bounds") or {}
    if rb.get("drain_mode")!="CONCURRENT_BOUNDED": raise Denied("DRAIN_MODE_INVALID")
    if rb.get("stdout_limit_exceeded") is not False: raise Denied("STDOUT_LIMIT_EXCEEDED")
    if rb.get("stderr_limit_exceeded") is not False: raise Denied("STDERR_LIMIT_EXCEEDED")
    if rb.get("timeout_triggered") is not False: raise Denied("CHILD_EXECUTION_TIMEOUT")

    boundary=r.get("boundary") or {}
    if boundary.get("process_observation_mode")!="NATIVE_HANDLE_BOUND": raise Denied("OBSERVATION_MODE_INVALID")
    if boundary.get("wmi_used_for_runtime_evidence") is not False: raise Denied("WMI_RUNTIME_EVIDENCE_FORBIDDEN")
    if boundary.get("dotnet_process_properties_used_for_child_identity") is not False: raise Denied("DOTNET_PROPERTY_IDENTITY_FORBIDDEN")
    if boundary.get("mediator_is_authenticated") is not False: raise Denied("MEDIATOR_AUTH_OVERCLAIM")
    if boundary.get("child_can_choose_principal") is not False or boundary.get("child_can_receive_runtime_grant") is not False: raise Denied("CHILD_AUTHORITY_BOUNDARY_INVALID")
    if boundary.get("raw_local_paths_serialized") is not False: raise Denied("RAW_PATH_SERIALIZATION_FORBIDDEN")

    if b.get("process_observation_mode")!="NATIVE_HANDLE_BOUND": raise Denied("BUILD_OBSERVATION_MODE_INVALID")
    for k in ("mediator_source_sha256","child_source_sha256","mediator_binary_sha256","child_binary_sha256","compiler_sha256"):
        if not _hex(b.get(k)): raise Denied("BUILD_LINEAGE_SHA_INVALID")

    return {
      "result":"R9A3_NATIVE_HANDLE_MEDIATOR_CANDIDATE_READY",
      "process_observation":"NATIVE_HANDLE_BOUND",
      "mediator_authentication":"NOT_PERFORMED","child_identity":"NOT_PROVED",
      "next_action":"R9B_OS_WORKLOAD_ATTESTATION_PREP",
      "authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,
      "g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
    }
