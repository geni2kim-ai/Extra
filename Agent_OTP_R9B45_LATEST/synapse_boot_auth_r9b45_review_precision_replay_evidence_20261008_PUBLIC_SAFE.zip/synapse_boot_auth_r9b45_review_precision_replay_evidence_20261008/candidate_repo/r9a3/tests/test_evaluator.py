from r9a3.evaluator import evaluate,Denied
def pair():
    a="a"*64;b="b"*64
    r={"schema_version":"SYNAPSE-R9A3-NATIVE-HANDLE-MEDIATOR-CANDIDATE-1",
      "mediator":{"pid":100,"executable_name":"R9A3_DedicatedMediator.exe","executable_sha256":a,"status":"CANDIDATE","authentication_result":"NOT_PERFORMED"},
      "child_instance":{"pid":200,"handle_pid":200,"handle_pid_matches_start_pid":True,"creation_time_filetime_100ns":1,"creation_time_rechecked_filetime_100ns":1,
        "creation_time_source":"GET_PROCESS_TIMES","executable_name":"R9A3_SyntheticChild.exe","executable_sha256":b,"path_source":"QUERY_FULL_PROCESS_IMAGE_NAME",
        "parent_pid":100,"parent_pid_source":"TOOLHELP32_SNAPSHOT","parent_binding_verified":True,"parent_observation_attempts":1,"parent_observation_elapsed_ms":2,
        "same_directory_binding_verified":True,"identity":"NOT_PROVED"},
      "child_message":{"payload_handling":"OPAQUE_BYTES_NOT_PARSED","trust":"UNTRUSTED_CHILD_INPUT","payload_content_in_receipt":False,"payload_sha256":"c"*64},
      "resource_bounds":{"drain_mode":"CONCURRENT_BOUNDED","stdout_limit_exceeded":False,"stderr_limit_exceeded":False,"timeout_triggered":False},
      "boundary":{"process_observation_mode":"NATIVE_HANDLE_BOUND","wmi_used_for_runtime_evidence":False,"dotnet_process_properties_used_for_child_identity":False,
        "mediator_is_authenticated":False,"child_can_choose_principal":False,"child_can_receive_runtime_grant":False,"raw_local_paths_serialized":False},
      "authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"}
    bb={"schema_version":"SYNAPSE-R9A3-BUILD-RECEIPT-1","mediator_source_sha256":"d"*64,"child_source_sha256":"e"*64,
        "mediator_binary_sha256":a,"child_binary_sha256":b,"compiler_sha256":"f"*64,"mediator_binary_name":"R9A3_DedicatedMediator.exe",
        "child_binary_name":"R9A3_SyntheticChild.exe","process_observation_mode":"NATIVE_HANDLE_BOUND","child_identity":"NOT_PROVED",
        "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}
    return r,bb
def test_ready():
    r,b=pair(); assert evaluate(r,b)["result"]=="R9A3_NATIVE_HANDLE_MEDIATOR_CANDIDATE_READY"
def test_handle_pid_mismatch_denied():
    r,b=pair(); r["child_instance"]["handle_pid"]=201
    try:evaluate(r,b)
    except Denied as e: assert e.code=="HANDLE_PID_BINDING_INVALID"
    else:assert False
def test_getprocesstimes_required():
    r,b=pair();r["child_instance"]["creation_time_source"]="DOTNET_STARTTIME"
    try:evaluate(r,b)
    except Denied as e: assert e.code=="CREATION_TIME_SOURCE_INVALID"
    else:assert False
def test_native_path_required():
    r,b=pair();r["child_instance"]["path_source"]="WMI"
    try:evaluate(r,b)
    except Denied as e: assert e.code=="PATH_SOURCE_INVALID"
    else:assert False
def test_wmi_forbidden():
    r,b=pair();r["boundary"]["wmi_used_for_runtime_evidence"]=True
    try:evaluate(r,b)
    except Denied as e: assert e.code=="WMI_RUNTIME_EVIDENCE_FORBIDDEN"
    else:assert False
def test_child_identity_overclaim():
    r,b=pair();r["child_instance"]["identity"]="VERIFIED"
    try:evaluate(r,b)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else:assert False
