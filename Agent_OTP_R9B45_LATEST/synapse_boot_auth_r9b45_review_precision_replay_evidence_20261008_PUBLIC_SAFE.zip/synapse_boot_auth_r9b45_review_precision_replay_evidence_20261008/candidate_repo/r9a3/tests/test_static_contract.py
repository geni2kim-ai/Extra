from pathlib import Path
ROOT=Path(__file__).parents[1]
S=(ROOT/"src"/"DedicatedMediator.cs").read_text(encoding="utf-8")
B=(ROOT/"windows"/"build_r9a3.ps1").read_text(encoding="utf-8")
M=(ROOT/"windows"/"run_r9a3_matrix.ps1").read_text(encoding="utf-8")
def test_no_system_management_or_wmi_runtime_provider():
    assert "System.Management" not in S
    assert "ManagementObject" not in S
    assert "Win32_Process" not in S
    assert "System.Management.dll" not in B
def test_handle_bound_native_apis_present():
    for token in ("GetProcessId","GetProcessTimes","QueryFullProcessImageName"):
        assert token in S
def test_parent_uses_toolhelp():
    for token in ("CreateToolhelp32Snapshot","Process32First","Process32Next","th32ParentProcessID"):
        assert token in S
def test_handle_instance_revalidated():
    assert "R9A3_CHILD_HANDLE_PID_RECHECK_FAILED" in S
    assert "R9A3_CHILD_INSTANCE_RECHECK_FAILED" in S
    assert "R9A3_CHILD_PATH_RECHECK_FAILED" in S
def test_bounded_drains_start_before_native_observation():
    assert S.index("Task<byte[]> stdoutTask") < S.index("ObserveNative(child")
def test_typed_negative_matrix_kept():
    assert 'Run-Case "normal" "normal" 0 $true' in M
    assert 'Run-Case "stdout_overflow" "stdout-overflow" 20 $false' in M
    assert 'Run-Case "stderr_overflow" "stderr-overflow" 21 $false' in M
    assert 'Run-Case "timeout" "timeout" 22 $false' in M
def test_no_raw_path_serialization():
    assert '"raw_local_paths_serialized", false' in S
    assert '"executable_name"' in S
