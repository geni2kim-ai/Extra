#!/usr/bin/env python3
import argparse,json
from pathlib import Path
from r9a3.evaluator import evaluate,Denied
def main():
    ap=argparse.ArgumentParser();ap.add_argument("receipt");ap.add_argument("--build-receipt",required=True);ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    r=json.loads(Path(ns.receipt).read_text(encoding="utf-8-sig"));b=json.loads(Path(ns.build_receipt).read_text(encoding="utf-8-sig"))
    try: out=evaluate(r,b);code=0
    except Denied as e: out={"result":"R9A3_DENIED","code":e.code,"authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"};code=2
    Path(ns.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n",encoding="utf-8");print(json.dumps(out,indent=2,ensure_ascii=False));return code
if __name__=="__main__": raise SystemExit(main())
