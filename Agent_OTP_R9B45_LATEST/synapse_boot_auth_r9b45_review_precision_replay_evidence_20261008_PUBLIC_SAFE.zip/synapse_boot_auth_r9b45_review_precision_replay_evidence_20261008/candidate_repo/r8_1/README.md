# R8.1 — controlled launcher with OS parent binding

R8.1 strengthens R8 by recording and enforcing:

`OS-observed child ParentProcessId == launcher PID`

This proves the observed process instance is a direct child of the launcher at capture time.

It still does **not** prove workload identity. The child remains `NOT_PROVED`, untrusted, and receives no grant.
