"""R8.1 controlled launcher with OS parent binding."""
