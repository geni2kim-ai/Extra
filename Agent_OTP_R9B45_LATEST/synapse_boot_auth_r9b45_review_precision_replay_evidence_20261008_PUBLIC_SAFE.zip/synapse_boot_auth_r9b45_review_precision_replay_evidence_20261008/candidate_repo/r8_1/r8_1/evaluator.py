from __future__ import annotations
from typing import Any
import re

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

def evaluate(doc:dict[str,Any])->dict[str,Any]:
    if doc.get("schema_version")!="SYNAPSE-R8.1-CONTROLLED-LAUNCHER-RECEIPT-1":
        raise Denied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect")!="NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status")!="NOT_AUTHORIZED" or doc.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("AUTH_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if doc.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")

    launcher=doc.get("launcher") or {}
    launcher_pid=launcher.get("launcher_pid")
    if not isinstance(launcher_pid,int) or launcher_pid<=0:
        raise Denied("LAUNCHER_PID_INVALID")
    if launcher.get("trust")!="CONTROLLED_CODE_REHEARSAL":
        raise Denied("LAUNCHER_TRUST_INVALID")

    child=doc.get("child") or {}
    if child.get("pid_source")!="System.Diagnostics.Process.Start":
        raise Denied("CHILD_PID_SOURCE_INVALID")
    if child.get("parent_pid")!=launcher_pid:
        raise Denied("CHILD_PARENT_PID_MISMATCH")
    if child.get("parent_pid_expected")!=launcher_pid:
        raise Denied("CHILD_PARENT_EXPECTED_MISMATCH")
    if child.get("parent_pid_matches_launcher") is not True:
        raise Denied("CHILD_PARENT_BINDING_NOT_VERIFIED")
    c1=child.get("creation_time_filetime_100ns"); c2=child.get("creation_time_rechecked_filetime_100ns")
    if not isinstance(c1,int) or c1<=0 or c1!=c2:
        raise Denied("CHILD_INSTANCE_RECHECK_FAILED")
    p1=child.get("executable_path"); p2=child.get("executable_path_rechecked")
    if not p1 or not p2 or p1.casefold()!=p2.casefold():
        raise Denied("CHILD_PATH_RECHECK_FAILED")
    e=child.get("executable_sha256_expected"); o=child.get("executable_sha256_observed")
    if not all(isinstance(x,str) and re.fullmatch(r"[0-9a-f]{64}",x) for x in (e,o)) or e!=o:
        raise Denied("CHILD_SHA_MISMATCH")
    if child.get("child_identity_claim")!="NOT_PROVED":
        raise Denied("CHILD_IDENTITY_OVERCLAIM")

    b=doc.get("boundary") or {}
    if b.get("launcher_controls_child_creation") is not True:
        raise Denied("LAUNCH_CONTROL_NOT_CONFIRMED")
    if b.get("os_parent_binding_verified") is not True:
        raise Denied("OS_PARENT_BINDING_NOT_VERIFIED")
    if b.get("launcher_proves_child_identity") is not False:
        raise Denied("CHILD_IDENTITY_OVERCLAIM")
    if b.get("child_native_pipe_hook")!="NOT_IMPLEMENTED":
        raise Denied("HOOK_STATE_OVERCLAIM")

    return {
      "result":"R8_1_CONTROLLED_LAUNCHER_PARENT_BOUND_READY",
      "launcher_pid":launcher_pid,
      "child_pid":child["pid"],
      "os_parent_binding_verified":True,
      "child_identity":"NOT_PROVED",
      "next_action":"R8B_MEDIATED_BOUNDARY_REVIEW",
      "authentication_result":"NOT_PERFORMED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
    }
