from pathlib import Path
S=(Path(__file__).parents[1]/"windows"/"run_r8_1_synthetic_controlled_launcher.ps1").read_text(encoding="utf-8")
def test_os_parent_pid_observed_and_checked():
    assert "$proc1.ParentProcessId" in S
    assert "R8_CHILD_PARENT_PID_MISMATCH" in S
    assert "parent_pid_matches_launcher" in S
    assert "os_parent_binding_verified" in S
def test_identity_not_promoted():
    assert 'child_identity_claim = "NOT_PROVED"' in S
    assert 'launcher_proves_child_identity = $false' in S
