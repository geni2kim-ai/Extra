from __future__ import annotations
from r8_1.evaluator import evaluate,Denied

def base():
    return {
      "schema_version":"SYNAPSE-R8.1-CONTROLLED-LAUNCHER-RECEIPT-1",
      "launcher":{"session_id":"x","launcher_pid":100,"implementation":"PACKAGED","trust":"CONTROLLED_CODE_REHEARSAL"},
      "child":{"pid":200,"pid_source":"System.Diagnostics.Process.Start",
        "parent_pid":100,"parent_pid_expected":100,"parent_pid_matches_launcher":True,
        "creation_time_filetime_100ns":1000,"creation_time_rechecked_filetime_100ns":1000,
        "executable_path":r"C:\x.exe","executable_path_rechecked":r"c:\X.EXE",
        "executable_sha256_expected":"a"*64,"executable_sha256_observed":"a"*64,
        "active_after_recheck":True,"child_identity_claim":"NOT_PROVED"},
      "boundary":{"launcher_controls_child_creation":True,"os_parent_binding_verified":True,
        "launcher_proves_child_identity":False,"child_native_pipe_hook":"NOT_IMPLEMENTED"},
      "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
    }

def test_parent_bound_ready_but_identity_not_proved():
    r=evaluate(base())
    assert r["result"]=="R8_1_CONTROLLED_LAUNCHER_PARENT_BOUND_READY"
    assert r["os_parent_binding_verified"] is True
    assert r["child_identity"]=="NOT_PROVED"

def test_parent_pid_mismatch_denied():
    d=base(); d["child"]["parent_pid"]=999
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_PARENT_PID_MISMATCH"
    else: assert False

def test_boolean_parent_claim_alone_not_enough():
    d=base(); d["child"]["parent_pid_matches_launcher"]=False
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_PARENT_BINDING_NOT_VERIFIED"
    else: assert False

def test_boundary_parent_claim_required():
    d=base(); d["boundary"]["os_parent_binding_verified"]=False
    try:evaluate(d)
    except Denied as e: assert e.code=="OS_PARENT_BINDING_NOT_VERIFIED"
    else: assert False

def test_child_identity_still_not_proved():
    d=base(); d["child"]["child_identity_claim"]="VERIFIED"
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else: assert False
