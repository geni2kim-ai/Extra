# R7D.1

Portability-only fix for R7D controlled-root locator.

Search-root IDs are assigned by `enumerate()` before path resolution, so relative and absolute roots behave
consistently when a fingerprint hit is found.

No authentication or authority behavior is added.
