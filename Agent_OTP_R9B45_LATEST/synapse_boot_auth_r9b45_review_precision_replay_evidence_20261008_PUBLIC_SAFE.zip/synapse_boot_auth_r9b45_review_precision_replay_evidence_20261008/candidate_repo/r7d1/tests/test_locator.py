from __future__ import annotations
import importlib.util, os
from pathlib import Path

P=Path(__file__).parents[1]/"locate_controlled_roots.py"
spec=importlib.util.spec_from_file_location("loc",P)
m=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(m)

def test_relative_search_root_with_hit(tmp_path,monkeypatch):
    repo=tmp_path/"repo"; repo.mkdir(); (repo/".git").mkdir()
    (repo/"watcher.py").write_text("x",encoding="utf-8")
    monkeypatch.chdir(tmp_path)
    r=m.scan([Path("repo")],{"watcher.py"},100)
    assert r["status"]=="COMPLETE"
    assert len(r["hits"])==1
    assert r["hits"][0]["search_root_id"]=="1"
    assert r["hits"][0]["relative_to_search_root"]=="watcher.py"

def test_multiple_roots_keep_stable_ids(tmp_path):
    a=tmp_path/"a"; b=tmp_path/"b"; a.mkdir(); b.mkdir()
    (a/"watcher.py").write_text("a",encoding="utf-8")
    (b/"watcher.py").write_text("b",encoding="utf-8")
    r=m.scan([a,b],{"watcher.py"},100)
    assert [x["search_root_id"] for x in r["hits"]]==["1","2"]

def test_scan_limit_still_fails_closed(tmp_path):
    for i in range(4): (tmp_path/f"x{i}.txt").write_text("x")
    r=m.scan([tmp_path],{"watcher.py"},2)
    assert r["status"]=="SCAN_LIMIT_REACHED"
