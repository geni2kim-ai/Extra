#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os
from collections import defaultdict
from pathlib import Path

DEFAULT_FINGERPRINTS = [
    "watcher.py",
    "monitor_daemon.py",
    "push_daemon.py",
    "db_connector.py",
    "lane_guard.py",
    "partition_recon.py",
    "packet_validator.py",
    "validate_pending.ps1",
]

def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""): h.update(c)
    return h.hexdigest()

def nearest_marker_root(path:Path, search_root:Path)->Path:
    cur=path.parent
    search_root=search_root.resolve()
    while True:
        for marker in (".git","AGENTS.md","pyproject.toml","requirements.txt"):
            if (cur/marker).exists():
                return cur
        if cur==search_root or cur.parent==cur:
            return search_root
        cur=cur.parent

def scan(search_roots:list[Path], fingerprints:set[str], max_files:int)->dict:
    hits=[]
    visited=0
    for root_index, raw_root in enumerate(search_roots, 1):
        root=raw_root.resolve()
        if not root.is_dir(): continue
        for dirpath,dirnames,filenames in os.walk(root):
            # Avoid very noisy/generated trees.
            dirnames[:] = [d for d in dirnames if d.casefold() not in {
                ".git","node_modules",".venv","venv","__pycache__",".pytest_cache","build","dist"
            }]
            for name in filenames:
                visited += 1
                if visited > max_files:
                    return {"status":"SCAN_LIMIT_REACHED","visited_files":visited,"hits":hits}
                if name.casefold() not in fingerprints: continue
                p=Path(dirpath)/name
                marker_root=nearest_marker_root(p,root)
                hits.append({
                    "search_root_id":str(root_index),
                    "relative_to_search_root":p.relative_to(root).as_posix(),
                    "fingerprint":name,
                    "sha256":sha(p),
                    "marker_root_relative":marker_root.relative_to(root).as_posix() if marker_root!=root else ".",
                })
    return {"status":"COMPLETE","visited_files":visited,"hits":hits}

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--search-root",action="append",required=True)
    ap.add_argument("--fingerprint",action="append",default=[])
    ap.add_argument("--max-files",type=int,default=20000)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    fps={x.casefold() for x in (ns.fingerprint or DEFAULT_FINGERPRINTS)}
    roots=[Path(x) for x in ns.search_root]
    result=scan(roots,fps,ns.max_files)

    grouped=defaultdict(lambda:{"fingerprints":set(),"hits":0})
    for h in result["hits"]:
        key=(h["search_root_id"],h["marker_root_relative"])
        grouped[key]["fingerprints"].add(h["fingerprint"])
        grouped[key]["hits"] += 1

    candidates=[]
    for (rid,rel),info in grouped.items():
        candidates.append({
            "search_root_id":rid,
            "marker_root_relative":rel,
            "fingerprints":sorted(info["fingerprints"]),
            "distinct_fingerprint_count":len(info["fingerprints"]),
            "hit_count":info["hits"],
            "classification":"SOURCE_ROOT_CANDIDATE_UNVERIFIED",
        })
    candidates.sort(key=lambda x:(-x["distinct_fingerprint_count"],-x["hit_count"],x["marker_root_relative"]))
    output={
        "schema_version":"SYNAPSE-R7D-CONTROLLED-ROOT-LOCATOR-1",
        "scan_status":result["status"],
        "visited_files":result["visited_files"],
        "fingerprint_names":sorted(fps),
        "hits":result["hits"],
        "root_candidates":candidates,
        "authentication_result":"NOT_PERFORMED",
        "authorization_status":"NOT_AUTHORIZED",
        "authority_effect":"NONE",
    }
    Path(ns.output).write_text(json.dumps(output,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({
        "scan_status":output["scan_status"],
        "visited_files":output["visited_files"],
        "hits":len(output["hits"]),
        "root_candidates":len(output["root_candidates"]),
    },indent=2))
    return 0 if result["status"]=="COMPLETE" else 2

if __name__=="__main__": raise SystemExit(main())
