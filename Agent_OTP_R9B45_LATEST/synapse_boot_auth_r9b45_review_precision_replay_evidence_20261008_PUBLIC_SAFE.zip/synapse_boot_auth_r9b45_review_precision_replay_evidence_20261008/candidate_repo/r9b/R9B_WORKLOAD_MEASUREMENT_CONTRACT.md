# R9B — local dedicated-mediator workload measurement contract

Status: `PREP ONLY / NOT AUTHENTICATION`

R9A.3 establishes a uniquely observable dedicated mediator binary and a reliable native process-evidence path.

R9B's next goal is narrower than authentication:

> prove that the process which connects to the local verifier pipe is the expected dedicated mediator binary
> running under an allowed local Windows identity.

## Intended evidence chain

`Named Pipe connection`
→ `GetNamedPipeClientProcessId`
→ `OpenProcess`
→ `GetProcessTimes`
→ `QueryFullProcessImageName`
→ executable SHA-256
→ impersonated token SID
→ verifier-side registry mapping

The caller does not choose its authenticated/derived workload ID.

`claimed_node_id` and `claimed_workload_id` remain untrusted input and are ignored for identity derivation.

## Why this is still not authentication

A measured binary SHA and user SID are not a non-exportable credential. The same approved binary can be copied
and started again by an actor with equivalent local execution rights.

Therefore the strongest R9B policy result is:

`MEASURED_NOT_AUTHENTICATED`

and:
- stable node ID remains `UNBOUND`
- no runtime grant
- no G1 token
- F2 remains closed

## R9B.1 implementation target

Add a native Named Pipe client path to the same dedicated mediator executable and bind its connection to the
existing R6 broker-style capture.

Only after that Windows rehearsal passes should a later phase bind the measured mediator to a fresh challenge and
a protected/non-exportable installation credential.
