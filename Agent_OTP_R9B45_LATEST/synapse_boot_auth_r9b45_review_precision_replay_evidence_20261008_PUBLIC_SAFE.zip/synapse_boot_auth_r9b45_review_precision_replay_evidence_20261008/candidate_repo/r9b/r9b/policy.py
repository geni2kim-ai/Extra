from __future__ import annotations
from pathlib import PureWindowsPath
from typing import Any
import re

class MeasurementDenied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

HEX64=re.compile(r"[0-9a-f]{64}")

def _hex(v:object)->bool:
    return isinstance(v,str) and HEX64.fullmatch(v) is not None

def evaluate_measurement(
    capture:dict[str,Any],
    build:dict[str,Any],
    verifier_registry:dict[str,Any]
)->dict[str,Any]:
    if capture.get("schema_version")!="SYNAPSE-R6-NAMED-PIPE-CAPTURE-1":
        raise MeasurementDenied("CAPTURE_SCHEMA_INVALID")
    if build.get("schema_version")!="SYNAPSE-R9A3-BUILD-RECEIPT-1":
        raise MeasurementDenied("BUILD_SCHEMA_INVALID")
    if verifier_registry.get("schema_version")!="SYNAPSE-R9B-VERIFIER-REGISTRY-1":
        raise MeasurementDenied("REGISTRY_SCHEMA_INVALID")

    if capture.get("authority_effect")!="NONE" or build.get("authority_effect")!="NONE":
        raise MeasurementDenied("AUTHORITY_EFFECT_NOT_NONE")
    if capture.get("authorization_status")!="NOT_AUTHORIZED":
        raise MeasurementDenied("CAPTURE_AUTHORIZATION_PRECLAIMED")
    if capture.get("authentication_result")!="CAPTURE_ONLY":
        raise MeasurementDenied("CAPTURE_AUTH_RESULT_INVALID")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if capture.get(k) is not False:
            raise MeasurementDenied("AUTHORITY_FLAG_TRUE")

    client=capture.get("client") or {}
    if client.get("pid_source")!="GetNamedPipeClientProcessId":
        raise MeasurementDenied("CLIENT_PID_SOURCE_INVALID")
    if client.get("process_creation_time_100ns")!=client.get("process_creation_time_rechecked_100ns"):
        raise MeasurementDenied("CLIENT_INSTANCE_RECHECK_FAILED")
    p1=client.get("process_path"); p2=client.get("process_path_rechecked")
    if not isinstance(p1,str) or not isinstance(p2,str) or p1.casefold()!=p2.casefold():
        raise MeasurementDenied("CLIENT_PATH_RECHECK_FAILED")
    if client.get("process_active_after_capture") is not True:
        raise MeasurementDenied("CLIENT_NOT_ACTIVE")
    observed_sha=client.get("process_sha256")
    if not _hex(observed_sha):
        raise MeasurementDenied("CLIENT_SHA_INVALID")

    expected_sha=build.get("mediator_binary_sha256")
    expected_name=build.get("mediator_binary_name")
    if not _hex(expected_sha) or observed_sha!=expected_sha:
        raise MeasurementDenied("MEDIATOR_BINARY_SHA_MISMATCH")
    if not isinstance(expected_name,str) or PureWindowsPath(p1).name.casefold()!=expected_name.casefold():
        raise MeasurementDenied("MEDIATOR_BINARY_NAME_MISMATCH")

    token=capture.get("token") or {}
    if token.get("impersonation_succeeded") is not True:
        raise MeasurementDenied("CLIENT_IMPERSONATION_REQUIRED")
    if token.get("token_source")!="ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)":
        raise MeasurementDenied("TOKEN_SOURCE_INVALID")
    sid=token.get("user_sid")
    if not isinstance(sid,str) or not sid.startswith("S-"):
        raise MeasurementDenied("CLIENT_SID_INVALID")

    entries=verifier_registry.get("entries")
    if not isinstance(entries,list):
        raise MeasurementDenied("REGISTRY_ENTRIES_INVALID")
    matches=[
        e for e in entries
        if isinstance(e,dict)
        and e.get("mediator_binary_sha256")==observed_sha
        and isinstance(e.get("allowed_user_sid"),str)
        and e.get("allowed_user_sid").casefold()==sid.casefold()
    ]
    if len(matches)!=1:
        raise MeasurementDenied("VERIFIER_REGISTRY_MATCH_NOT_UNIQUE")
    entry=matches[0]
    workload_id=entry.get("derived_workload_id")
    if not isinstance(workload_id,str) or not workload_id:
        raise MeasurementDenied("DERIVED_WORKLOAD_ID_INVALID")

    # Caller claims are intentionally not identity inputs.
    claims=capture.get("caller_claims") or {}
    ignored_claims={
        "claimed_node_id":claims.get("claimed_node_id"),
        "claimed_workload_id":claims.get("claimed_workload_id"),
    }

    return {
      "result":"R9B_LOCAL_WORKLOAD_MEASUREMENT_READY",
      "derived_workload_id":workload_id,
      "derived_from":"VERIFIER_REGISTRY_BINARY_SHA_PLUS_USER_SID",
      "caller_claims_trust":"IGNORED_FOR_IDENTITY",
      "ignored_caller_claims":ignored_claims,
      "stable_node_id":"UNBOUND",
      "measurement_result":"MEASURED",
      "authentication_result":"MEASURED_NOT_AUTHENTICATED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
      "next_action":"R9B1_NATIVE_PIPE_CLIENT_BINDING_REHEARSAL",
    }
