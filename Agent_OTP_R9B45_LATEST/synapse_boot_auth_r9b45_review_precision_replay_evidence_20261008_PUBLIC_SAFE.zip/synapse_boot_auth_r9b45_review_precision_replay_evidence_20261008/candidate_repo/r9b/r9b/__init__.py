"""R9B local workload measurement policy; not authentication."""
