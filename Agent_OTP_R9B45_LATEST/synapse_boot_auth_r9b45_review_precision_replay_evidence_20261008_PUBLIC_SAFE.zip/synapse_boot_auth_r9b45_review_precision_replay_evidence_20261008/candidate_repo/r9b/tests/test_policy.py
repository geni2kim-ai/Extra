from r9b.policy import evaluate_measurement,MeasurementDenied
def data():
    sha="a"*64
    capture={
      "schema_version":"SYNAPSE-R6-NAMED-PIPE-CAPTURE-1",
      "client":{"pid":200,"pid_source":"GetNamedPipeClientProcessId","process_creation_time_100ns":1,
        "process_creation_time_rechecked_100ns":1,"process_path":r"C:\x\R9A3_DedicatedMediator.exe",
        "process_path_rechecked":r"c:\X\R9A3_DedicatedMediator.exe","process_sha256":sha,"process_active_after_capture":True},
      "token":{"user_sid":"S-1-5-21-123","service_sids":[],"token_source":"ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)",
        "impersonation_succeeded":True},
      "caller_claims":{"claimed_node_id":"3X","claimed_workload_id":"FAKE_SELF_CLAIM"},
      "authentication_result":"CAPTURE_ONLY","authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"}
    build={"schema_version":"SYNAPSE-R9A3-BUILD-RECEIPT-1","mediator_binary_sha256":sha,
      "mediator_binary_name":"R9A3_DedicatedMediator.exe","authority_effect":"NONE"}
    reg={"schema_version":"SYNAPSE-R9B-VERIFIER-REGISTRY-1","entries":[{
      "derived_workload_id":"R9_MEDIATOR_CANDIDATE","mediator_binary_sha256":sha,"allowed_user_sid":"S-1-5-21-123"}]}
    return capture,build,reg
def test_measurement_ready_but_not_authenticated():
    c,b,r=data();o=evaluate_measurement(c,b,r)
    assert o["result"]=="R9B_LOCAL_WORKLOAD_MEASUREMENT_READY"
    assert o["authentication_result"]=="MEASURED_NOT_AUTHENTICATED"
    assert o["stable_node_id"]=="UNBOUND"
    assert o["authorization_status"]=="NOT_AUTHORIZED"
def test_caller_workload_claim_cannot_choose_identity():
    c,b,r=data();c["caller_claims"]["claimed_workload_id"]="ADMIN"
    o=evaluate_measurement(c,b,r)
    assert o["derived_workload_id"]=="R9_MEDIATOR_CANDIDATE"
    assert o["caller_claims_trust"]=="IGNORED_FOR_IDENTITY"
def test_binary_mismatch_denied():
    c,b,r=data();c["client"]["process_sha256"]="b"*64
    try:evaluate_measurement(c,b,r)
    except MeasurementDenied as e: assert e.code=="MEDIATOR_BINARY_SHA_MISMATCH"
    else:assert False
def test_sid_mismatch_denied():
    c,b,r=data();c["token"]["user_sid"]="S-1-5-21-999"
    try:evaluate_measurement(c,b,r)
    except MeasurementDenied as e: assert e.code=="VERIFIER_REGISTRY_MATCH_NOT_UNIQUE"
    else:assert False
def test_instance_recheck_required():
    c,b,r=data();c["client"]["process_creation_time_rechecked_100ns"]=2
    try:evaluate_measurement(c,b,r)
    except MeasurementDenied as e: assert e.code=="CLIENT_INSTANCE_RECHECK_FAILED"
    else:assert False
def test_client_must_be_active():
    c,b,r=data();c["client"]["process_active_after_capture"]=False
    try:evaluate_measurement(c,b,r)
    except MeasurementDenied as e: assert e.code=="CLIENT_NOT_ACTIVE"
    else:assert False
def test_registry_match_must_be_unique():
    c,b,r=data();r["entries"].append(dict(r["entries"][0]))
    try:evaluate_measurement(c,b,r)
    except MeasurementDenied as e: assert e.code=="VERIFIER_REGISTRY_MATCH_NOT_UNIQUE"
    else:assert False
