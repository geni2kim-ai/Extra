"""Bounded opaque-child I/O policy."""
