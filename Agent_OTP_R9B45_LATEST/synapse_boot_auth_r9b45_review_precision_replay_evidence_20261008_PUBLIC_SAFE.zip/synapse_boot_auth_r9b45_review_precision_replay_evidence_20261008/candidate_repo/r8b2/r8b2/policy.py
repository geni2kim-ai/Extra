from __future__ import annotations
from typing import Any

class ResourceDenied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

MAX_STDOUT_BYTES=65536
MAX_STDERR_BYTES=16384
MAX_TIMEOUT_MS=30000

def validate_bounds(doc:dict[str,Any])->dict[str,Any]:
    out_limit=doc.get("stdout_limit_bytes")
    err_limit=doc.get("stderr_limit_bytes")
    timeout=doc.get("timeout_ms")
    if not isinstance(out_limit,int) or not 1 <= out_limit <= MAX_STDOUT_BYTES:
        raise ResourceDenied("STDOUT_LIMIT_INVALID")
    if not isinstance(err_limit,int) or not 1 <= err_limit <= MAX_STDERR_BYTES:
        raise ResourceDenied("STDERR_LIMIT_INVALID")
    if not isinstance(timeout,int) or not 1 <= timeout <= MAX_TIMEOUT_MS:
        raise ResourceDenied("TIMEOUT_INVALID")

    out_count=doc.get("stdout_bytes")
    err_count=doc.get("stderr_bytes")
    if not isinstance(out_count,int) or out_count < 0 or out_count > out_limit:
        raise ResourceDenied("STDOUT_OBSERVED_OUT_OF_BOUNDS")
    if not isinstance(err_count,int) or err_count < 0 or err_count > err_limit:
        raise ResourceDenied("STDERR_OBSERVED_OUT_OF_BOUNDS")
    if doc.get("stdout_limit_exceeded") is not False:
        raise ResourceDenied("STDOUT_LIMIT_EXCEEDED")
    if doc.get("stderr_limit_exceeded") is not False:
        raise ResourceDenied("STDERR_LIMIT_EXCEEDED")
    if doc.get("timeout_triggered") is not False:
        raise ResourceDenied("CHILD_EXECUTION_TIMEOUT")
    if doc.get("drain_mode")!="CONCURRENT_BOUNDED":
        raise ResourceDenied("DRAIN_MODE_INVALID")
    return {
      "result":"R8B2_RESOURCE_BOUNDARY_READY",
      "stdout_bytes":out_count,
      "stderr_bytes":err_count,
      "authority_effect":"NONE",
    }
