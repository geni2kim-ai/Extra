from r8b2.policy import validate_bounds,ResourceDenied
def base():
    return {"stdout_limit_bytes":4096,"stderr_limit_bytes":4096,"timeout_ms":5000,
      "stdout_bytes":91,"stderr_bytes":0,"stdout_limit_exceeded":False,
      "stderr_limit_exceeded":False,"timeout_triggered":False,"drain_mode":"CONCURRENT_BOUNDED"}
def test_ready():
    assert validate_bounds(base())["result"]=="R8B2_RESOURCE_BOUNDARY_READY"
def test_stdout_overflow_denied():
    d=base(); d["stdout_bytes"]=4097
    try:validate_bounds(d)
    except ResourceDenied as e: assert e.code=="STDOUT_OBSERVED_OUT_OF_BOUNDS"
    else:assert False
def test_stderr_flag_denied():
    d=base(); d["stderr_limit_exceeded"]=True
    try:validate_bounds(d)
    except ResourceDenied as e: assert e.code=="STDERR_LIMIT_EXCEEDED"
    else:assert False
def test_timeout_denied():
    d=base(); d["timeout_triggered"]=True
    try:validate_bounds(d)
    except ResourceDenied as e: assert e.code=="CHILD_EXECUTION_TIMEOUT"
    else:assert False
def test_sequential_drain_denied():
    d=base(); d["drain_mode"]="SEQUENTIAL"
    try:validate_bounds(d)
    except ResourceDenied as e: assert e.code=="DRAIN_MODE_INVALID"
    else:assert False
