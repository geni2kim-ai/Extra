# R8B.2 — bounded opaque-child I/O policy

R8B.2 closes the R8B.1 resource-boundary gap before any real opaque child is considered.

Requirements:
- stdout byte cap
- stderr byte cap
- concurrent bounded drain
- execution timeout
- overflow/timeout fail closed
- receipt stores hashes/counts, not raw payload
- authority remains NONE
