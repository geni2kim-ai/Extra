from __future__ import annotations
from typing import Any
import re

class AssessmentDenied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

def evaluate(doc:dict[str,Any])->dict[str,Any]:
    if doc.get("schema_version")!="SYNAPSE-R7B-HOOK-ASSESSMENT-1":
        raise AssessmentDenied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect")!="NONE":
        raise AssessmentDenied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status")!="NOT_AUTHORIZED":
        raise AssessmentDenied("AUTHORIZATION_PRECLAIMED")
    if doc.get("authentication_result")!="NOT_PERFORMED":
        raise AssessmentDenied("AUTHENTICATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if doc.get(k) is not False:
            raise AssessmentDenied("AUTHORITY_FLAG_TRUE")

    label=doc.get("operator_label") or {}
    if label.get("trust")!="UNVERIFIED_CLAIM":
        raise AssessmentDenied("OPERATOR_LABEL_MUST_REMAIN_UNVERIFIED")

    p=doc.get("process") or {}
    if p.get("pid_source")!="OPERATOR_SELECTED_READONLY":
        raise AssessmentDenied("PID_SOURCE_INVALID")
    if not isinstance(p.get("pid"),int) or p["pid"]<=0:
        raise AssessmentDenied("PID_INVALID")
    c1=p.get("creation_time_filetime_100ns")
    c2=p.get("creation_time_rechecked_filetime_100ns")
    if not isinstance(c1,int) or c1<=0 or c1!=c2:
        raise AssessmentDenied("PROCESS_INSTANCE_RECHECK_FAILED")
    path=p.get("executable_path"); path2=p.get("executable_path_rechecked")
    if not path or not path2 or path.casefold()!=path2.casefold():
        raise AssessmentDenied("EXECUTABLE_PATH_RECHECK_MISMATCH")
    h=p.get("executable_sha256")
    if not isinstance(h,str) or not re.fullmatch(r"[0-9a-f]{64}",h):
        raise AssessmentDenied("EXECUTABLE_SHA256_INVALID")
    if p.get("active_after_assessment") is not True:
        raise AssessmentDenied("PROCESS_NOT_ACTIVE")
    if p.get("command_line_captured") is not False:
        raise AssessmentDenied("COMMAND_LINE_CAPTURE_FORBIDDEN")

    hook=doc.get("native_pipe_client_hook") or {}
    if hook.get("status") not in {"NOT_CONFIRMED","SOURCE_HOOK_CONFIRMED","NOT_CAPABLE"}:
        raise AssessmentDenied("HOOK_STATUS_INVALID")

    source_status=doc.get("source_control_status")
    roots=doc.get("controlled_roots") or []
    under=[r for r in roots if r.get("target_executable_under_root") is True]
    git_heads=[r.get("git_head") for r in roots if r.get("git_head")]

    # R7B is conservative: a binary being under a supplied root is not enough to
    # prove hook source ownership. Source hook remains unconfirmed unless a later
    # source review explicitly proves an entrypoint.
    if hook.get("status")=="SOURCE_HOOK_CONFIRMED":
        raise AssessmentDenied("SOURCE_HOOK_CANNOT_BE_SELF_DECLARED_IN_R7B")

    if source_status=="TARGET_BINARY_OUTSIDE_OPERATOR_CONTROLLED_ROOTS":
        result="R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED"
        next_action="SELECT_CONTROLLED_AGENT_LAUNCHER_OR_SOURCE_ENTRYPOINT"
    elif source_status=="TARGET_BINARY_UNDER_OPERATOR_CONTROLLED_ROOT":
        result="R7B_SOURCE_REVIEW_REQUIRED"
        next_action="REVIEW_CONTROLLED_SOURCE_FOR_IN_PROCESS_PIPE_CLIENT"
    else:
        result="R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED"
        next_action="PROVIDE_PROJECT_CONTROLLED_ROOT_OR_SELECT_DIFFERENT_WORKLOAD"

    return {
      "result":result,
      "operator_label":label.get("value"),
      "operator_label_trust":"UNVERIFIED_CLAIM",
      "pid":p["pid"],
      "executable_sha256":h,
      "mapped_service_count":len(doc.get("mapped_services") or []),
      "source_control_status":source_status,
      "controlled_root_git_heads":git_heads,
      "native_pipe_client_hook":"NOT_CONFIRMED",
      "next_action":next_action,
      "authentication_result":"NOT_PERFORMED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE"
    }
