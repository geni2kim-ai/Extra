"""R7B read-only client-hook assessment. No authority."""
