param(
    [Parameter(Mandatory=$true)]
    [int]$ProcessId,

    [Parameter(Mandatory=$true)]
    [string]$OperatorLabel,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath,

    [string[]]$ControlledRoots = @()
)

$ErrorActionPreference = "Stop"

function Get-TargetProcess([int]$TargetPid) {
    return Get-CimInstance Win32_Process -Filter ("ProcessId=" + $TargetPid)
}

function Normalize-FullPath([string]$PathValue) {
    if ([string]::IsNullOrWhiteSpace($PathValue)) { return $null }
    try { return [System.IO.Path]::GetFullPath($PathValue) } catch { return $null }
}

function Is-UnderRoot([string]$CandidatePath, [string]$RootPath) {
    $c = Normalize-FullPath $CandidatePath
    $r = Normalize-FullPath $RootPath
    if (-not $c -or -not $r) { return $false }
    if (-not $r.EndsWith([System.IO.Path]::DirectorySeparatorChar)) {
        $r = $r + [System.IO.Path]::DirectorySeparatorChar
    }
    return $c.StartsWith($r, [System.StringComparison]::OrdinalIgnoreCase)
}

$proc1 = Get-TargetProcess $ProcessId
if (-not $proc1) { throw "TARGET_PROCESS_NOT_FOUND" }

$exe = [string]$proc1.ExecutablePath
if (-not $exe -or -not (Test-Path -LiteralPath $exe -PathType Leaf)) {
    throw "TARGET_EXECUTABLE_NOT_RESOLVED"
}

$creation1 = $proc1.CreationDate
if (-not ($creation1 -is [datetime])) { throw "TARGET_CREATION_TIME_INVALID" }
$creationUtc1 = ([datetime]$creation1).ToUniversalTime()
$exeHash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()

$ownerSidResult = Invoke-CimMethod -InputObject $proc1 -MethodName GetOwnerSid
$ownerSid = $ownerSidResult.Sid
if (-not $ownerSid) { throw "TARGET_OWNER_SID_NOT_RESOLVED" }

$signature = Get-AuthenticodeSignature -LiteralPath $exe
$item = Get-Item -LiteralPath $exe
$version = $item.VersionInfo

$services = @(Get-CimInstance Win32_Service | Where-Object { [int]$_.ProcessId -eq $ProcessId } | ForEach-Object {
    [ordered]@{
        name = $_.Name
        state = $_.State
        start_name = $_.StartName
        path_name = $_.PathName
    }
})

$parentChain=@()
$current=[int]$proc1.ParentProcessId
for ($i=0; $i -lt 5 -and $current -gt 0; $i++) {
    $p = Get-TargetProcess $current
    if (-not $p) { break }
    $parentPath=[string]$p.ExecutablePath
    $parentChain += [ordered]@{
        pid = [int]$p.ProcessId
        parent_pid = [int]$p.ParentProcessId
        process_name = [string]$p.Name
        executable_path = if ($parentPath) { $parentPath } else { $null }
    }
    $current=[int]$p.ParentProcessId
}

$controlledRootObservations=@()
foreach ($root in $ControlledRoots) {
    if ([string]::IsNullOrWhiteSpace($root)) { continue }
    $exists=Test-Path -LiteralPath $root -PathType Container
    $gitHead=$null
    if ($exists -and (Get-Command git.exe -ErrorAction SilentlyContinue)) {
        try {
            $gitHead = (& git.exe -C $root rev-parse HEAD 2>$null | Select-Object -First 1)
        } catch {}
    }
    $controlledRootObservations += [ordered]@{
        supplied_root = $root
        exists = [bool]$exists
        git_head = $gitHead
        target_executable_under_root = if ($exists) { Is-UnderRoot $exe $root } else { $false }
        classification = "OPERATOR_SUPPLIED_ROOT_OBSERVATION"
    }
}

$proc2=Get-TargetProcess $ProcessId
if (-not $proc2) { throw "TARGET_PROCESS_EXITED_DURING_ASSESSMENT" }
$creation2=$proc2.CreationDate
if (-not ($creation2 -is [datetime])) { throw "TARGET_CREATION_TIME_RECHECK_INVALID" }
$creationUtc2=([datetime]$creation2).ToUniversalTime()
$exe2=[string]$proc2.ExecutablePath

$sourceStatus="UNKNOWN"
if (@($controlledRootObservations | Where-Object { $_.target_executable_under_root }).Count -gt 0) {
    $sourceStatus="TARGET_BINARY_UNDER_OPERATOR_CONTROLLED_ROOT"
} elseif ($ControlledRoots.Count -gt 0) {
    $sourceStatus="TARGET_BINARY_OUTSIDE_OPERATOR_CONTROLLED_ROOTS"
}

$report=[ordered]@{
    schema_version="SYNAPSE-R7B-HOOK-ASSESSMENT-1"
    collected_at_utc=(Get-Date).ToUniversalTime().ToString("o")
    operator_label=[ordered]@{
        value=$OperatorLabel
        trust="UNVERIFIED_CLAIM"
    }
    process=[ordered]@{
        pid=$ProcessId
        pid_source="OPERATOR_SELECTED_READONLY"
        process_name=[string]$proc1.Name
        parent_pid=[int]$proc1.ParentProcessId
        creation_time_filetime_100ns=$creationUtc1.ToFileTimeUtc()
        creation_time_rechecked_filetime_100ns=$creationUtc2.ToFileTimeUtc()
        executable_path=$exe
        executable_path_rechecked=$exe2
        executable_sha256=$exeHash
        active_after_assessment=$true
        command_line_captured=$false
    }
    binary_metadata=[ordered]@{
        authenticode_status=[string]$signature.Status
        signer_thumbprint=if ($signature.SignerCertificate) { $signature.SignerCertificate.Thumbprint } else { $null }
        signer_subject=if ($signature.SignerCertificate) { $signature.SignerCertificate.Subject } else { $null }
        company_name=$version.CompanyName
        product_name=$version.ProductName
        file_description=$version.FileDescription
        original_filename=$version.OriginalFilename
        file_version=$version.FileVersion
        product_version=$version.ProductVersion
    }
    mapped_services=$services
    parent_chain=$parentChain
    controlled_roots=$controlledRootObservations
    source_control_status=$sourceStatus
    native_pipe_client_hook=[ordered]@{
        status="NOT_CONFIRMED"
        reason="R7B performs no injection and does not infer hook capability from process/binary names."
    }
    authentication_result="NOT_PERFORMED"
    authorization_status="NOT_AUTHORIZED"
    runtime_grant_issued=$false
    g1_token_issued=$false
    f2_unlocked=$false
    authority_effect="NONE"
}

$report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
$sha=(Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ("WROTE " + $OutputPath)
Write-Host ("SHA256 " + $sha)
Write-Host "AUTHORITY_EFFECT=NONE"
