from __future__ import annotations
import importlib.util
from pathlib import Path

ROOT=Path(__file__).parents[2]
LINT=ROOT/"tools"/"powershell_semantic_lint.py"
spec=importlib.util.spec_from_file_location("pslint",LINT)
m=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(m)

def test_r7a_and_r7b_powershell_have_no_known_auto_var_param_collisions():
    findings=[]
    for d in (ROOT/"r7a",ROOT/"r7b"):
        for p in d.rglob("*.ps1"):
            findings.extend(m.scan_file(p))
    assert findings == []

def test_lint_detects_pid_collision(tmp_path):
    p=tmp_path/"bad.ps1"
    p.write_text("function Get-X([int]$Pid) { return $Pid }",encoding="utf-8")
    f=m.scan_file(p)
    assert len(f)==1
    assert f[0]["code"]=="POWERSHELL_AUTOMATIC_VARIABLE_COLLISION"
