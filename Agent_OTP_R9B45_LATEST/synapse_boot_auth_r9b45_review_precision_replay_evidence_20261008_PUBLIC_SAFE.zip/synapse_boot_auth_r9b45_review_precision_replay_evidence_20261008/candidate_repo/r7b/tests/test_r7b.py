from __future__ import annotations
from r7b.evaluator import evaluate,AssessmentDenied

def base():
    return {
      "schema_version":"SYNAPSE-R7B-HOOK-ASSESSMENT-1",
      "operator_label":{"value":"candidate","trust":"UNVERIFIED_CLAIM"},
      "process":{
        "pid":123,"pid_source":"OPERATOR_SELECTED_READONLY",
        "creation_time_filetime_100ns":100,
        "creation_time_rechecked_filetime_100ns":100,
        "executable_path":r"C:\Program Files\App\x.exe",
        "executable_path_rechecked":r"c:\program files\app\X.EXE",
        "executable_sha256":"a"*64,
        "active_after_assessment":True,
        "command_line_captured":False
      },
      "binary_metadata":{"authenticode_status":"Valid"},
      "mapped_services":[],
      "parent_chain":[],
      "controlled_roots":[],
      "source_control_status":"UNKNOWN",
      "native_pipe_client_hook":{"status":"NOT_CONFIRMED","reason":"not assessed"},
      "authentication_result":"NOT_PERFORMED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE"
    }

def test_unknown_source_stops_without_hook():
    r=evaluate(base())
    assert r["result"]=="R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED"
    assert r["native_pipe_client_hook"]=="NOT_CONFIRMED"
    assert r["authority_effect"]=="NONE"

def test_outside_controlled_roots_stops():
    d=base()
    d["controlled_roots"]=[{"target_executable_under_root":False,"git_head":"abc"}]
    d["source_control_status"]="TARGET_BINARY_OUTSIDE_OPERATOR_CONTROLLED_ROOTS"
    r=evaluate(d)
    assert r["result"]=="R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED"

def test_inside_root_requires_source_review_not_authentication():
    d=base()
    d["controlled_roots"]=[{"target_executable_under_root":True,"git_head":"abc"}]
    d["source_control_status"]="TARGET_BINARY_UNDER_OPERATOR_CONTROLLED_ROOT"
    r=evaluate(d)
    assert r["result"]=="R7B_SOURCE_REVIEW_REQUIRED"
    assert r["authorization_status"]=="NOT_AUTHORIZED"

def test_self_declared_hook_confirmation_denied():
    d=base(); d["native_pipe_client_hook"]["status"]="SOURCE_HOOK_CONFIRMED"
    try: evaluate(d)
    except AssessmentDenied as e: assert e.code=="SOURCE_HOOK_CANNOT_BE_SELF_DECLARED_IN_R7B"
    else: assert False

def test_label_must_stay_unverified():
    d=base(); d["operator_label"]["trust"]="VERIFIED"
    try: evaluate(d)
    except AssessmentDenied as e: assert e.code=="OPERATOR_LABEL_MUST_REMAIN_UNVERIFIED"
    else: assert False

def test_process_recheck_required():
    d=base(); d["process"]["creation_time_rechecked_filetime_100ns"]=101
    try: evaluate(d)
    except AssessmentDenied as e: assert e.code=="PROCESS_INSTANCE_RECHECK_FAILED"
    else: assert False

def test_authority_flag_denied():
    d=base(); d["g1_token_issued"]=True
    try: evaluate(d)
    except AssessmentDenied as e: assert e.code=="AUTHORITY_FLAG_TRUE"
    else: assert False
