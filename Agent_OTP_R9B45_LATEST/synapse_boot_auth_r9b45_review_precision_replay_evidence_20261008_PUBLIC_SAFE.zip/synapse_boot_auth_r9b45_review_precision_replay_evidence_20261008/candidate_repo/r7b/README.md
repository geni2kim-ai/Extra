# R7B — client-hook source/control assessment

Status: `CANDIDATE / READ-ONLY / NO INJECTION / NO AUTHORITY`

R7B does not add a Named Pipe client to the discovered process.

It answers a narrower question:

> Is there a project-controlled source/launcher boundary where an in-process workload client could later be
> implemented and reviewed?

Evidence collected:
- process instance recheck
- executable hash
- Authenticode status/signer metadata
- file version/product metadata
- mapped Windows services
- parent process chain (without command lines)
- operator-supplied controlled-root observations and Git HEADs

A target binary being under a supplied root is **not** itself proof of hook ownership. It only triggers a source
review requirement.

Possible results:
- `R7B_CLIENT_HOOK_SOURCE_NOT_CONFIRMED`
- `R7B_SOURCE_REVIEW_REQUIRED`

No R7B result means the workload is authenticated.
