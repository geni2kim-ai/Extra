param(
    [Parameter(Mandatory=$true)]
    [string]$OutputPath,

    [ValidateRange(1, 30)]
    [int]$ChildLifetimeSeconds = 3
)

$ErrorActionPreference = "Stop"

$launcherSessionId = "r8-launcher-" + [guid]::NewGuid().ToString("N")
$launcherPid = $PID
$targetExe = (Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$targetHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash.ToLowerInvariant()

$childCommand = "Start-Sleep -Seconds " + $ChildLifetimeSeconds
$encodedChild = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($childCommand))

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $targetExe
$psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -EncodedCommand " + $encodedChild
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true

$child = New-Object System.Diagnostics.Process
$child.StartInfo = $psi

$started = $false
try {
    $started = $child.Start()
    if (-not $started) { throw "R8_CHILD_START_FAILED" }

    $childPid = [int]$child.Id
    $proc1 = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $childPid)
    if (-not $proc1) { throw "R8_CHILD_PROCESS_NOT_OBSERVED" }

    $path1 = [string]$proc1.ExecutablePath
    if (-not $path1) { throw "R8_CHILD_PATH_NOT_OBSERVED" }
    if (-not $path1.Equals($targetExe,[System.StringComparison]::OrdinalIgnoreCase)) {
        throw "R8_CHILD_PATH_MISMATCH"
    }

    $ctime1 = $proc1.CreationDate
    if (-not ($ctime1 -is [datetime])) { throw "R8_CHILD_CREATION_TIME_INVALID" }
    $ctimeUtc1 = ([datetime]$ctime1).ToUniversalTime()

    $observedHash = (Get-FileHash -LiteralPath $path1 -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($observedHash -ne $targetHash) { throw "R8_CHILD_HASH_MISMATCH" }

    Start-Sleep -Milliseconds 100
    $proc2 = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $childPid)
    if (-not $proc2) { throw "R8_CHILD_EXITED_BEFORE_RECHECK" }
    $ctime2 = $proc2.CreationDate
    if (-not ($ctime2 -is [datetime])) { throw "R8_CHILD_CREATION_RECHECK_INVALID" }
    $ctimeUtc2 = ([datetime]$ctime2).ToUniversalTime()
    $path2 = [string]$proc2.ExecutablePath

    $report = [ordered]@{
        schema_version = "SYNAPSE-R8-CONTROLLED-LAUNCHER-RECEIPT-1"
        collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
        launcher = [ordered]@{
            session_id = $launcherSessionId
            launcher_pid = $launcherPid
            implementation = "PACKAGED_R8_SYNTHETIC_POWERSHELL_LAUNCHER"
            trust = "CONTROLLED_CODE_REHEARSAL"
        }
        child = [ordered]@{
            pid = $childPid
            pid_source = "System.Diagnostics.Process.Start"
            creation_time_filetime_100ns = $ctimeUtc1.ToFileTimeUtc()
            creation_time_rechecked_filetime_100ns = $ctimeUtc2.ToFileTimeUtc()
            executable_path = $path1
            executable_path_rechecked = $path2
            executable_sha256_expected = $targetHash
            executable_sha256_observed = $observedHash
            active_after_recheck = $true
            child_identity_claim = "NOT_PROVED"
        }
        boundary = [ordered]@{
            launcher_controls_child_creation = $true
            launcher_proves_child_identity = $false
            child_native_pipe_hook = "NOT_IMPLEMENTED"
        }
        authentication_result = "NOT_PERFORMED"
        authorization_status = "NOT_AUTHORIZED"
        runtime_grant_issued = $false
        g1_token_issued = $false
        f2_unlocked = $false
        authority_effect = "NONE"
    }

    $report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    $sha = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
    Write-Host ("R8_SYNTHETIC_LAUNCHER_RECEIPT_READY")
    Write-Host ("SHA256 " + $sha)
    Write-Host "AUTHORITY_EFFECT=NONE"
}
finally {
    if ($started -and $child -and -not $child.HasExited) {
        try {
            $child.Kill()
            $child.WaitForExit(5000) | Out-Null
        } catch {}
    }
    if ($child) { $child.Dispose() }
}
