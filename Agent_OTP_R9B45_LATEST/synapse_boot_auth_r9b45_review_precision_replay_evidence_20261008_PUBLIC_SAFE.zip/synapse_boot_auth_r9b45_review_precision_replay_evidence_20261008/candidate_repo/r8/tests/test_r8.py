from __future__ import annotations
from r8.evaluator import evaluate,Denied

def base():
    return {
      "schema_version":"SYNAPSE-R8-CONTROLLED-LAUNCHER-RECEIPT-1",
      "launcher":{"session_id":"r8-x","launcher_pid":100,"implementation":"PACKAGED_R8_SYNTHETIC_POWERSHELL_LAUNCHER","trust":"CONTROLLED_CODE_REHEARSAL"},
      "child":{
        "pid":200,"pid_source":"System.Diagnostics.Process.Start",
        "creation_time_filetime_100ns":1000,"creation_time_rechecked_filetime_100ns":1000,
        "executable_path":r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
        "executable_path_rechecked":r"c:\windows\system32\WindowsPowerShell\v1.0\POWERSHELL.EXE",
        "executable_sha256_expected":"a"*64,"executable_sha256_observed":"a"*64,
        "active_after_recheck":True,"child_identity_claim":"NOT_PROVED"
      },
      "boundary":{"launcher_controls_child_creation":True,"launcher_proves_child_identity":False,"child_native_pipe_hook":"NOT_IMPLEMENTED"},
      "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
    }

def test_ready_but_child_identity_not_proved():
    r=evaluate(base())
    assert r["result"]=="R8_CONTROLLED_LAUNCHER_REHEARSAL_READY"
    assert r["child_identity"]=="NOT_PROVED"
    assert r["authority_effect"]=="NONE"

def test_hash_mismatch_denied():
    d=base();d["child"]["executable_sha256_observed"]="b"*64
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_SHA_MISMATCH"
    else:assert False

def test_child_identity_overclaim_denied():
    d=base();d["child"]["child_identity_claim"]="VERIFIED"
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else:assert False

def test_launcher_cannot_claim_child_identity():
    d=base();d["boundary"]["launcher_proves_child_identity"]=True
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else:assert False

def test_hook_cannot_be_preclaimed():
    d=base();d["boundary"]["child_native_pipe_hook"]="IMPLEMENTED"
    try:evaluate(d)
    except Denied as e: assert e.code=="HOOK_STATE_OVERCLAIM"
    else:assert False

def test_authority_flag_denied():
    d=base();d["g1_token_issued"]=True
    try:evaluate(d)
    except Denied as e: assert e.code=="AUTHORITY_FLAG_TRUE"
    else:assert False
