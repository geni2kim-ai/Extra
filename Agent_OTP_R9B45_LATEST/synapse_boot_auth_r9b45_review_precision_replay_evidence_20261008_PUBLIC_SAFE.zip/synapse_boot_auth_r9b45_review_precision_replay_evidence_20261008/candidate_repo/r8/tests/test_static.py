from pathlib import Path
SCRIPT=(Path(__file__).parents[1]/"windows"/"run_r8_synthetic_controlled_launcher.ps1").read_text(encoding="utf-8")
def test_no_shell_execute():
    assert "$psi.UseShellExecute = $false" in SCRIPT
def test_exact_hash_recheck():
    assert "R8_CHILD_HASH_MISMATCH" in SCRIPT
def test_child_identity_explicitly_not_proved():
    assert 'child_identity_claim = "NOT_PROVED"' in SCRIPT
    assert 'launcher_proves_child_identity = $false' in SCRIPT
def test_no_authority():
    assert 'authorization_status = "NOT_AUTHORIZED"' in SCRIPT
    assert 'authority_effect = "NONE"' in SCRIPT
