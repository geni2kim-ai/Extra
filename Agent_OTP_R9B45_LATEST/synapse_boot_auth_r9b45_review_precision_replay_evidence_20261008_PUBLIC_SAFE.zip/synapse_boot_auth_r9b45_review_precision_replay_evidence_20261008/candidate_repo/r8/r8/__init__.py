"""R8 controlled launcher receipt policy. No child identity claim."""
