from __future__ import annotations
from typing import Any
import re

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

def evaluate(doc:dict[str,Any])->dict[str,Any]:
    if doc.get("schema_version")!="SYNAPSE-R8-CONTROLLED-LAUNCHER-RECEIPT-1":
        raise Denied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect")!="NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status")!="NOT_AUTHORIZED" or doc.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("AUTH_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if doc.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")

    launcher=doc.get("launcher") or {}
    if launcher.get("trust")!="CONTROLLED_CODE_REHEARSAL":
        raise Denied("LAUNCHER_TRUST_INVALID")
    if not launcher.get("session_id"):
        raise Denied("LAUNCHER_SESSION_MISSING")

    child=doc.get("child") or {}
    if child.get("pid_source")!="System.Diagnostics.Process.Start":
        raise Denied("CHILD_PID_SOURCE_INVALID")
    if not isinstance(child.get("pid"),int) or child["pid"]<=0:
        raise Denied("CHILD_PID_INVALID")
    c1=child.get("creation_time_filetime_100ns")
    c2=child.get("creation_time_rechecked_filetime_100ns")
    if not isinstance(c1,int) or c1<=0 or c1!=c2:
        raise Denied("CHILD_INSTANCE_RECHECK_FAILED")
    p1=child.get("executable_path"); p2=child.get("executable_path_rechecked")
    if not p1 or not p2 or p1.casefold()!=p2.casefold():
        raise Denied("CHILD_PATH_RECHECK_FAILED")
    e=child.get("executable_sha256_expected")
    o=child.get("executable_sha256_observed")
    if not all(isinstance(x,str) and re.fullmatch(r"[0-9a-f]{64}",x) for x in (e,o)):
        raise Denied("CHILD_SHA_INVALID")
    if e!=o:
        raise Denied("CHILD_SHA_MISMATCH")
    if child.get("active_after_recheck") is not True:
        raise Denied("CHILD_NOT_ACTIVE")
    if child.get("child_identity_claim")!="NOT_PROVED":
        raise Denied("CHILD_IDENTITY_OVERCLAIM")

    boundary=doc.get("boundary") or {}
    if boundary.get("launcher_controls_child_creation") is not True:
        raise Denied("LAUNCH_CONTROL_NOT_CONFIRMED")
    if boundary.get("launcher_proves_child_identity") is not False:
        raise Denied("CHILD_IDENTITY_OVERCLAIM")
    if boundary.get("child_native_pipe_hook")!="NOT_IMPLEMENTED":
        raise Denied("HOOK_STATE_OVERCLAIM")

    return {
        "result":"R8_CONTROLLED_LAUNCHER_REHEARSAL_READY",
        "launcher_session_id":launcher["session_id"],
        "child_pid":child["pid"],
        "child_identity":"NOT_PROVED",
        "next_action":"R8B_DEFINE_MEDIATED_WORKLOAD_BOUNDARY",
        "authentication_result":"NOT_PERFORMED",
        "authorization_status":"NOT_AUTHORIZED",
        "runtime_grant_issued":False,
        "g1_token_issued":False,
        "f2_unlocked":False,
        "authority_effect":"NONE",
    }
