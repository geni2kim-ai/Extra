# R8 — dedicated controlled launcher synthetic rehearsal

R7D found no existing Synapse source root on YM. R8 therefore starts a **new controlled launcher boundary**
instead of widening filesystem search or modifying the installed OpenCode binary.

R8 is synthetic:
- packaged PowerShell launcher starts a short-lived packaged test child command through the exact
  `powershell.exe` binary it hashed;
- PID comes from `System.Diagnostics.Process.Start`;
- child creation time/path/hash are read back and rechecked;
- child is terminated after evidence collection.

Critical invariant:

> Launch control is not child identity proof.

The receipt must keep:
- `child_identity_claim=NOT_PROVED`
- `launcher_proves_child_identity=false`
- `child_native_pipe_hook=NOT_IMPLEMENTED`
- `NOT_AUTHORIZED / NONE`

A PASS only permits design work for a mediated workload boundary.
