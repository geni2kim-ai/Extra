# Leonardo review — YM R4.1 / R5.1 boundary retest

**Input:** `ym_r41_r51_package_20261007.zip`
**Input SHA-256:** `8b7af810641f776c701984fd87e77f6799c1532f9d20d1367da0792f412d3a74`
**Manifest verification:** PASS (all listed files matched)
**Verdict:** `EVIDENCE_ACCEPTED / R4.1 BLOCK IS REAL / R6 MAY PROCEED INDEPENDENTLY`

## Accepted findings

1. **R4.1 host probe is now informative.**
   - `Get-Tpm` probe status: `OK`
   - TPM `present=false`
   - `ready=false`, `enabled=false`, `activated=false`
   - Microsoft Platform Crypto Provider visible
   - therefore the gate result `R4_1_TPM_REHEARSAL_BLOCKED` is a measured block, not an access-denied ambiguity.

2. **Host/workload binding worked.**
   - host and workload reports carry the same masked `machine_binding_sha256`.
   - R4.1 joined the reports and did not confuse a workload-account report with TPM host capability.

3. **R5.1 collector defect is fixed.**
   - sandbox reports the first-line check passed for all scripts.
   - creation time is emitted both as UTC and Windows FILETIME integer.
   - inventory is explicitly `NOT_AUTHORIZED`, `NOT_PERFORMED`, `authority_effect=NONE`.

4. **The measured workload is not an agent.**
   - target was `Explorer.EXE`.
   - `LogicalWorkloadId=YM-R41-RETEST-Explorer` was an explicit sandbox test assumption.
   - therefore it does not prove 3G, 3X, Support/L5, or any production workload.

5. **No key mutation occurred.**
   - correct, because R4.1 gate was blocked.

## Strongest supported conclusion

`YM_R41_R51_BOUNDARY_RETEST_PASS_AS_EVIDENCE`

with the narrower facts:

```text
YM sandbox has no usable TPM according to successful Get-Tpm measurement.
R4.1 correctly blocked TPM rehearsal.
R5.1 correctly measured an operator-selected real process as inventory only.
No node identity, workload identity, runtime authority, G1, or F2 was established.
```

## Leonardo next decision

Do **not** weaken the TPM requirement merely to make YM pass R4.1.

Proceed with R6 independently:
- R6 tests the Windows workload capture boundary.
- It does not require TPM.
- It does not create a node session with authority.
- It uses a synthetic node-session identifier only to test evidence binding.
- even on PASS it returns `authorization_status=NOT_AUTHORIZED`.
