# R7D — bounded controlled source-root locator

R7C on YM was intentionally run against a sandbox staging workspace, not a real Synapse source checkout.

R7D searches only operator-supplied parent roots for exact known project fingerprints. It does not scan an entire
machine unless the operator explicitly supplies such a root.

Default fingerprints include known Synapse component basenames such as:
- watcher.py
- monitor_daemon.py
- push_daemon.py
- db_connector.py
- lane_guard.py
- partition_recon.py
- packet_validator.py
- validate_pending.ps1

A root candidate is still `UNVERIFIED`; finding two or more distinct fingerprints only makes it eligible for
operator selection and an R7C.1 rerun.
