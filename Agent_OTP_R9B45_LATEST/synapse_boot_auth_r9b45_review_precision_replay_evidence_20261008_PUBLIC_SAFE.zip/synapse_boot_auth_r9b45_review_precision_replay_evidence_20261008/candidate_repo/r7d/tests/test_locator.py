from __future__ import annotations
import importlib.util
from pathlib import Path

P=Path(__file__).parents[1]/"locate_controlled_roots.py"
spec=importlib.util.spec_from_file_location("loc",P)
m=importlib.util.module_from_spec(spec); assert spec.loader; spec.loader.exec_module(m)

def test_finds_known_fingerprints_and_groups_root(tmp_path):
    repo=tmp_path/"repo"; repo.mkdir(); (repo/".git").mkdir()
    (repo/"watcher.py").write_text("x",encoding="utf-8")
    sub=repo/"core"; sub.mkdir()
    (sub/"db_connector.py").write_text("y",encoding="utf-8")
    r=m.scan([tmp_path],{"watcher.py","db_connector.py"},100)
    assert r["status"]=="COMPLETE"
    assert len(r["hits"])==2
    assert {h["marker_root_relative"] for h in r["hits"]}=={"repo"}

def test_scan_is_bounded(tmp_path):
    for i in range(5): (tmp_path/f"x{i}.txt").write_text("x")
    r=m.scan([tmp_path],{"watcher.py"},2)
    assert r["status"]=="SCAN_LIMIT_REACHED"
