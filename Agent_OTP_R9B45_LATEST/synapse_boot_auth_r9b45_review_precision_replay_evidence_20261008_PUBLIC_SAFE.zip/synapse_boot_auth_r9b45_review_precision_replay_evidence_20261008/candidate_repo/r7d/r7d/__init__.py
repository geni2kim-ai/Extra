"""Bounded controlled source-root locator."""
