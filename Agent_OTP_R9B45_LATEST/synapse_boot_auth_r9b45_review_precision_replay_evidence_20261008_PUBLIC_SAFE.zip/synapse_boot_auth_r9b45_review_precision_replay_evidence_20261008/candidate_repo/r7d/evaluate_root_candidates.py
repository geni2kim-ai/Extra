#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument("input"); ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args(); doc=json.loads(Path(ns.input).read_text(encoding="utf-8-sig"))
    if doc.get("authority_effect")!="NONE" or doc.get("authorization_status")!="NOT_AUTHORIZED":
        raise SystemExit(2)
    cands=doc.get("root_candidates") or []
    strong=[c for c in cands if c.get("distinct_fingerprint_count",0)>=2]
    if strong:
        result="R7D_SOURCE_ROOT_CANDIDATE_FOUND"
        nxt="RERUN_R7C1_ON_SELECTED_ROOT"
    elif cands:
        result="R7D_WEAK_SOURCE_ROOT_CANDIDATE_ONLY"
        nxt="OPERATOR_CONFIRM_ROOT_BEFORE_R7C1"
    else:
        result="R7D_NO_SOURCE_ROOT_CANDIDATE"
        nxt="CREATE_DEDICATED_CONTROLLED_AGENT_LAUNCHER"
    out={
        "result":result,
        "strong_candidate_count":len(strong),
        "candidate_count":len(cands),
        "next_action":nxt,
        "authentication_result":"NOT_PERFORMED",
        "authorization_status":"NOT_AUTHORIZED",
        "authority_effect":"NONE"
    }
    Path(ns.output).write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(out,indent=2)); return 0

if __name__=="__main__": raise SystemExit(main())
