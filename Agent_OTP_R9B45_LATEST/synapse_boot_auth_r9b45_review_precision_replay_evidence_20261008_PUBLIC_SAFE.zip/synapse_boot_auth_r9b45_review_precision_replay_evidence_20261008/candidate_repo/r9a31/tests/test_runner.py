from pathlib import Path
S=(Path(__file__).parents[1]/"windows"/"run_r9a31_matrix.ps1").read_text(encoding="utf-8")
def test_uses_process_api_not_native_invocation():
    assert "System.Diagnostics.ProcessStartInfo" in S
    assert "System.Diagnostics.Process" in S
    assert "& $exe" not in S
def test_exitcode_is_read_from_process_object():
    assert "$p.ExitCode" in S
    assert ".exitcode.txt" in S
def test_streams_are_redirected_and_drained():
    assert "$psi.RedirectStandardOutput = $true" in S
    assert "$psi.RedirectStandardError = $true" in S
    assert "ReadToEndAsync()" in S
    assert "$p.WaitForExit()" in S
def test_all_matrix_cases_preserved():
    assert 'Invoke-NativeCase "normal" "normal" 0 $true' in S
    assert 'Invoke-NativeCase "stdout_overflow" "stdout-overflow" 20 $false' in S
    assert 'Invoke-NativeCase "stderr_overflow" "stderr-overflow" 21 $false' in S
    assert 'Invoke-NativeCase "timeout" "timeout" 22 $false' in S
def test_no_power_shell_native_preference_dependency():
    assert "PSNativeCommandUseErrorActionPreference" not in S
def test_stale_artifacts_removed_before_case():
    assert "Remove-Item -LiteralPath $p -Force" in S
