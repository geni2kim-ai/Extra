param(
    [Parameter(Mandatory=$true)]
    [string]$MediatorExe,

    [Parameter(Mandatory=$true)]
    [string]$OutputDirectory
)

$ErrorActionPreference = "Stop"

$exe = [IO.Path]::GetFullPath($MediatorExe)
$out = [IO.Path]::GetFullPath($OutputDirectory)
if ($exe.Contains('"') -or $out.Contains('"')) { throw "R9A31_QUOTE_IN_PATH_FORBIDDEN" }
if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) { throw "R9A31_MEDIATOR_EXE_NOT_FOUND" }

New-Item -ItemType Directory -Force -Path $out | Out-Null

function Quote-Arg([string]$Value) {
    if ($Value.Contains('"')) { throw "R9A31_QUOTE_IN_ARGUMENT_FORBIDDEN" }
    return '"' + $Value + '"'
}

function Invoke-NativeCase(
    [string]$Name,
    [string]$Mode,
    [int]$ExpectedExit,
    [bool]$NeedsReceipt
) {
    $stdoutPath = Join-Path $out ($Name + ".stdout.txt")
    $stderrPath = Join-Path $out ($Name + ".stderr.txt")
    $receiptPath = Join-Path $out ($Name + ".receipt.json")
    $exitPath = Join-Path $out ($Name + ".exitcode.txt")

    foreach ($p in @($stdoutPath,$stderrPath,$receiptPath,$exitPath)) {
        if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force }
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $exe
    $psi.Arguments = (
        "--output " + (Quote-Arg $receiptPath) +
        " --mode " + $Mode +
        " --stdout-limit 4096 --stderr-limit 4096 --timeout-ms 2000"
    )
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true

    $p = New-Object System.Diagnostics.Process
    $p.StartInfo = $psi
    $started = $false
    try {
        $started = $p.Start()
        if (-not $started) { throw "R9A31_CASE_START_FAILED" }

        $stdoutTask = $p.StandardOutput.ReadToEndAsync()
        $stderrTask = $p.StandardError.ReadToEndAsync()

        if (-not $p.WaitForExit(15000)) {
            try { $p.Kill() } catch {}
            throw ("R9A31_HARNESS_TIMEOUT " + $Name)
        }

        # Required by .NET Process docs to ensure async redirected output is fully drained.
        $p.WaitForExit()
        $stdoutText = $stdoutTask.GetAwaiter().GetResult()
        $stderrText = $stderrTask.GetAwaiter().GetResult()
        $exitCode = [int]$p.ExitCode

        [IO.File]::WriteAllText($stdoutPath, $stdoutText, (New-Object Text.UTF8Encoding($false)))
        [IO.File]::WriteAllText($stderrPath, $stderrText, (New-Object Text.UTF8Encoding($false)))
        [IO.File]::WriteAllText($exitPath, ([string]$exitCode + [Environment]::NewLine), (New-Object Text.UTF8Encoding($false)))

        if ($exitCode -ne $ExpectedExit) {
            throw ("R9A31_CASE_EXIT_MISMATCH " + $Name + " actual=" + $exitCode + " expected=" + $ExpectedExit)
        }

        $hasReceipt = Test-Path -LiteralPath $receiptPath -PathType Leaf
        if ($NeedsReceipt -and -not $hasReceipt) {
            throw ("R9A31_EXPECTED_RECEIPT_MISSING " + $Name)
        }
        if (-not $NeedsReceipt -and $hasReceipt) {
            throw ("R9A31_UNEXPECTED_RECEIPT_PRESENT " + $Name)
        }
    }
    finally {
        if ($p) { $p.Dispose() }
    }
}

Invoke-NativeCase "normal" "normal" 0 $true
Invoke-NativeCase "stdout_overflow" "stdout-overflow" 20 $false
Invoke-NativeCase "stderr_overflow" "stderr-overflow" 21 $false
Invoke-NativeCase "timeout" "timeout" 22 $false

$summary = [ordered]@{
    schema_version = "SYNAPSE-R9A31-MATRIX-SUMMARY-1"
    status = "MATRIX_PASS"
    runner = "SYSTEM_DIAGNOSTICS_PROCESS"
    expected_exit_codes = [ordered]@{
        normal = 0
        stdout_overflow = 20
        stderr_overflow = 21
        timeout = 22
    }
    authority_effect = "NONE"
}
$summary | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $out "matrix_summary.json") -Encoding UTF8
Write-Host "R9A31_MATRIX_PASS"
