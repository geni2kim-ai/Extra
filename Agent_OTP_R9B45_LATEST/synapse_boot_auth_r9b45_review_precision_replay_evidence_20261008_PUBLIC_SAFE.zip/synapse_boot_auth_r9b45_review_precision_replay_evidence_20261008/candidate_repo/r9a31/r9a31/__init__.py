"""R9A.3.1 portable matrix harness."""
