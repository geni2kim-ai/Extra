# R9A.3.1 — portable matrix evidence harness

R9A.3 mediator behavior passed on YM, but the packaged PowerShell runner did not reliably preserve expected
nonzero native exit codes under the host shell semantics.

R9A.3.1 does not change the mediator binary.

The runner launches the existing R9A.3 mediator through `System.Diagnostics.Process`, captures stdout/stderr and
the exact `Process.ExitCode`, and writes evidence before validating the expected outcome.

It does not depend on PowerShell native-command error preference behavior.
