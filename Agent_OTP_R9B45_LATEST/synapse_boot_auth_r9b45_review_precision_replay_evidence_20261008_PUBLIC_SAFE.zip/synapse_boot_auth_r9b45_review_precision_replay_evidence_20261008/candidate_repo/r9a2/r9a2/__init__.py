"""R9A.2 observation-race-remediated candidate."""
