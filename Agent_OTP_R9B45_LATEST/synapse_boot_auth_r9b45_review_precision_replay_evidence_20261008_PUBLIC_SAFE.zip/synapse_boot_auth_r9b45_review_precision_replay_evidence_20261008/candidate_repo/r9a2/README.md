# R9A.2 — instance-anchored bounded Windows process observation

R9A.1 showed that the packaged helper starts, but the first immediate WMI `ExecutablePath` read can be empty on
YM while later observations resolve.

R9A.2 does not use a fixed sleep and does not relax path verification.

It:
1. starts bounded stdout/stderr drains immediately;
2. anchors the child process instance with PID + creation time;
3. verifies parent PID;
4. retries only the WMI path observation inside a 1200 ms budget;
5. revalidates the same PID/creation time on each attempt;
6. requires resolved WMI path == expected packaged helper path;
7. corroborates with `.NET Process.MainModule.FileName`;
8. verifies exact helper SHA;
9. keeps all resource, opaque-payload and authority invariants.

Failure to observe the path in budget is:

`R9A2_CHILD_PATH_OBSERVATION_TIMEOUT`

No authentication or authority is added.
