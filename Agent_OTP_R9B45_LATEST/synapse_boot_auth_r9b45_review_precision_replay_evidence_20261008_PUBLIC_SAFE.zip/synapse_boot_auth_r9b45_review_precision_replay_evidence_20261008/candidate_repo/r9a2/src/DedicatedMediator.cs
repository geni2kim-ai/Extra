using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace SynapseR9A2
{
    internal sealed class LimitExceededException : Exception
    {
        internal readonly string Code;
        internal LimitExceededException(string code) : base(code) { Code = code; }
    }

    internal sealed class ChildObservation
    {
        internal long CreationTime;
        internal int ParentPid;
        internal string WmiPath;
        internal string DotNetPath;
        internal int PathAttempts;
        internal long PathElapsedMs;
    }

    internal static class DedicatedMediator
    {
        private const int ExitStdoutLimit = 20;
        private const int ExitStderrLimit = 21;
        private const int ExitTimeout = 22;
        private const int ExitGeneric = 23;
        private const string HelperName = "R9A2_SyntheticChild.exe";
        private const int StartTimeObservationTimeoutMs = 1000;
        private const int PathObservationTimeoutMs = 1200;

        private static string Sha256File(string path)
        {
            using (var sha = SHA256.Create())
            using (var s = File.OpenRead(path))
                return Hex(sha.ComputeHash(s));
        }

        private static string Sha256Bytes(byte[] data)
        {
            using (var sha = SHA256.Create())
                return Hex(sha.ComputeHash(data));
        }

        private static string Hex(byte[] data)
        {
            var sb = new StringBuilder(data.Length * 2);
            foreach (byte b in data) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }

        private static async Task<byte[]> ReadBoundedAsync(Stream stream, int maxBytes, string code)
        {
            var buffer = new byte[1024];
            using (var ms = new MemoryStream())
            {
                while (true)
                {
                    int n = await stream.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
                    if (n == 0) break;
                    if (ms.Length + n > maxBytes) throw new LimitExceededException(code);
                    ms.Write(buffer, 0, n);
                }
                return ms.ToArray();
            }
        }

        private static long StartTimeFileTimeWithRetry(int pid)
        {
            var sw = Stopwatch.StartNew();
            Exception last = null;
            while (sw.ElapsedMilliseconds < StartTimeObservationTimeoutMs)
            {
                try
                {
                    using (var p = Process.GetProcessById(pid))
                        return p.StartTime.ToUniversalTime().ToFileTimeUtc();
                }
                catch (Exception ex)
                {
                    last = ex;
                    Thread.Sleep(20);
                }
            }
            throw new InvalidOperationException("R9A2_CHILD_STARTTIME_OBSERVATION_TIMEOUT", last);
        }

        private static void ReadWmiProcess(int pid, out int parentPid, out string executablePath)
        {
            parentPid = -1;
            executablePath = null;
            using (var searcher = new ManagementObjectSearcher(
                "SELECT ParentProcessId, ExecutablePath FROM Win32_Process WHERE ProcessId=" + pid))
            {
                foreach (ManagementObject mo in searcher.Get())
                {
                    parentPid = Convert.ToInt32((UInt32)mo["ParentProcessId"]);
                    executablePath = Convert.ToString(mo["ExecutablePath"]);
                    return;
                }
            }
        }

        private static string DotNetProcessPath(int pid)
        {
            using (var p = Process.GetProcessById(pid))
                return p.MainModule.FileName;
        }

        private static ChildObservation ObserveChildIdentity(int pid, int expectedParentPid, string expectedPath)
        {
            long anchor = StartTimeFileTimeWithRetry(pid);
            var sw = Stopwatch.StartNew();
            int attempts = 0;

            while (sw.ElapsedMilliseconds < PathObservationTimeoutMs)
            {
                attempts++;

                long current = StartTimeFileTimeWithRetry(pid);
                if (current != anchor)
                    throw new InvalidOperationException("R9A2_CHILD_INSTANCE_CHANGED_DURING_PATH_OBSERVATION");

                int parentPid;
                string wmiPath;
                ReadWmiProcess(pid, out parentPid, out wmiPath);

                if (parentPid != -1 && parentPid != expectedParentPid)
                    throw new InvalidOperationException("R9A2_CHILD_PARENT_PID_MISMATCH");

                if (!String.IsNullOrWhiteSpace(wmiPath))
                {
                    if (!String.Equals(wmiPath, expectedPath, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("R9A2_CHILD_PATH_MISMATCH");

                    string dotNetPath = DotNetProcessPath(pid);
                    if (!String.Equals(dotNetPath, expectedPath, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("R9A2_CHILD_DOTNET_PATH_MISMATCH");

                    long finalCreation = StartTimeFileTimeWithRetry(pid);
                    if (finalCreation != anchor)
                        throw new InvalidOperationException("R9A2_CHILD_INSTANCE_RECHECK_FAILED");

                    return new ChildObservation {
                        CreationTime = anchor,
                        ParentPid = parentPid,
                        WmiPath = wmiPath,
                        DotNetPath = dotNetPath,
                        PathAttempts = attempts,
                        PathElapsedMs = sw.ElapsedMilliseconds
                    };
                }

                Thread.Sleep(25);
            }

            throw new InvalidOperationException("R9A2_CHILD_PATH_OBSERVATION_TIMEOUT");
        }

        private static void KillQuiet(Process p)
        {
            try { if (!p.HasExited) p.Kill(); } catch { }
            try { p.WaitForExit(2000); } catch { }
        }

        private static int Main(string[] args)
        {
            try { return MainCore(args); }
            catch (Exception ex)
            {
                Console.Error.WriteLine("R9A2_GENERIC_FAILURE " + ex.GetType().Name + " " + ex.Message);
                return ExitGeneric;
            }
        }

        private static int MainCore(string[] args)
        {
            string output = null;
            string mode = "normal";
            int stdoutLimit = 4096;
            int stderrLimit = 4096;
            int timeoutMs = 5000;

            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--output" && i + 1 < args.Length) output = args[++i];
                else if (args[i] == "--mode" && i + 1 < args.Length) mode = args[++i];
                else if (args[i] == "--stdout-limit" && i + 1 < args.Length) stdoutLimit = Int32.Parse(args[++i]);
                else if (args[i] == "--stderr-limit" && i + 1 < args.Length) stderrLimit = Int32.Parse(args[++i]);
                else if (args[i] == "--timeout-ms" && i + 1 < args.Length) timeoutMs = Int32.Parse(args[++i]);
                else throw new ArgumentException("R9A2_ARGUMENT_INVALID");
            }

            if (String.IsNullOrWhiteSpace(output)) throw new ArgumentException("R9A2_OUTPUT_REQUIRED");
            if (stdoutLimit < 1 || stdoutLimit > 65536) throw new ArgumentException("R9A2_STDOUT_LIMIT_INVALID");
            if (stderrLimit < 1 || stderrLimit > 16384) throw new ArgumentException("R9A2_STDERR_LIMIT_INVALID");
            if (timeoutMs < 1 || timeoutMs > 30000) throw new ArgumentException("R9A2_TIMEOUT_INVALID");
            if (mode != "normal" && mode != "stdout-overflow" && mode != "stderr-overflow" && mode != "timeout")
                throw new ArgumentException("R9A2_MODE_INVALID");

            var self = Process.GetCurrentProcess();
            int mediatorPid = self.Id;
            string mediatorExe = self.MainModule.FileName;
            string mediatorSha = Sha256File(mediatorExe);
            string mediatorDir = Path.GetDirectoryName(mediatorExe);
            string helperExe = Path.Combine(mediatorDir, HelperName);
            if (!File.Exists(helperExe))
                throw new FileNotFoundException("R9A2_HELPER_EXE_NOT_FOUND");

            string helperExpectedSha = Sha256File(helperExe);
            string mediatorSession = "r9a2-mediator-" + Guid.NewGuid().ToString("N");

            var psi = new ProcessStartInfo();
            psi.FileName = helperExe;
            psi.Arguments = mode;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;

            using (var child = new Process())
            {
                child.StartInfo = psi;
                if (!child.Start())
                    throw new InvalidOperationException("R9A2_CHILD_START_FAILED");
                int childPid = child.Id;

                // Start both drains immediately so observation retries cannot create pipe backpressure.
                Task<byte[]> stdoutTask = ReadBoundedAsync(
                    child.StandardOutput.BaseStream, stdoutLimit, "R9A2_CHILD_STDOUT_LIMIT_EXCEEDED");
                Task<byte[]> stderrTask = ReadBoundedAsync(
                    child.StandardError.BaseStream, stderrLimit, "R9A2_CHILD_STDERR_LIMIT_EXCEEDED");

                ChildObservation obs;
                try
                {
                    obs = ObserveChildIdentity(childPid, mediatorPid, helperExe);
                }
                catch
                {
                    KillQuiet(child);
                    throw;
                }

                string observedSha = Sha256File(obs.WmiPath);
                if (observedSha != helperExpectedSha)
                {
                    KillQuiet(child);
                    throw new InvalidOperationException("R9A2_CHILD_SHA_MISMATCH");
                }

                var execWatch = Stopwatch.StartNew();
                while (!child.HasExited && !stdoutTask.IsFaulted && !stderrTask.IsFaulted &&
                       execWatch.ElapsedMilliseconds < timeoutMs)
                    Thread.Sleep(10);

                bool timedOut = !child.HasExited && execWatch.ElapsedMilliseconds >= timeoutMs;
                if (timedOut || stdoutTask.IsFaulted || stderrTask.IsFaulted)
                    KillQuiet(child);
                if (!child.HasExited)
                    child.WaitForExit();

                try { Task.WaitAll(new Task[] { stdoutTask, stderrTask }, 2000); }
                catch (AggregateException) { }

                if (stdoutTask.IsFaulted)
                {
                    var ex = stdoutTask.Exception.Flatten().InnerException as LimitExceededException;
                    if (ex != null && ex.Code == "R9A2_CHILD_STDOUT_LIMIT_EXCEEDED")
                    {
                        Console.Error.WriteLine(ex.Code);
                        return ExitStdoutLimit;
                    }
                    throw stdoutTask.Exception.Flatten().InnerException;
                }

                if (stderrTask.IsFaulted)
                {
                    var ex = stderrTask.Exception.Flatten().InnerException as LimitExceededException;
                    if (ex != null && ex.Code == "R9A2_CHILD_STDERR_LIMIT_EXCEEDED")
                    {
                        Console.Error.WriteLine(ex.Code);
                        return ExitStderrLimit;
                    }
                    throw stderrTask.Exception.Flatten().InnerException;
                }

                if (timedOut)
                {
                    Console.Error.WriteLine("R9A2_CHILD_EXECUTION_TIMEOUT");
                    return ExitTimeout;
                }

                byte[] stdoutBytes = stdoutTask.Result;
                byte[] stderrBytes = stderrTask.Result;
                if (mode != "normal")
                    throw new InvalidOperationException("R9A2_NEGATIVE_MODE_DID_NOT_TRIGGER");

                string expectedPayload =
                    "{\"meta\":{\"node_id\":\"UNTRUSTED_CHILD_CLAIM\",\"token\":\"UNTRUSTED_CHILD_TOKEN\"},\"data\":\"hello\"}";
                string expectedPayloadSha = Sha256Bytes(Encoding.UTF8.GetBytes(expectedPayload));
                string observedPayloadSha = Sha256Bytes(stdoutBytes);
                if (observedPayloadSha != expectedPayloadSha)
                    throw new InvalidOperationException("R9A2_PAYLOAD_HASH_MISMATCH");
                if (stderrBytes.Length != 0)
                    throw new InvalidOperationException("R9A2_CHILD_STDERR_NONEMPTY");
                if (child.ExitCode != 0)
                    throw new InvalidOperationException("R9A2_CHILD_EXIT_NONZERO");

                var receipt = new Dictionary<string, object>();
                receipt["schema_version"] = "SYNAPSE-R9A2-DEDICATED-MEDIATOR-CANDIDATE-1";
                receipt["collected_at_utc"] = DateTime.UtcNow.ToString("o");

                receipt["mediator"] = new Dictionary<string, object> {
                    {"session_id", mediatorSession},
                    {"pid", mediatorPid},
                    {"executable_name", Path.GetFileName(mediatorExe)},
                    {"executable_sha256", mediatorSha},
                    {"workload_identity_mode", "DEDICATED_EXECUTABLE_CANDIDATE"},
                    {"authentication_result", "NOT_PERFORMED"},
                    {"status", "CANDIDATE"}
                };

                receipt["child_instance"] = new Dictionary<string, object> {
                    {"pid", childPid},
                    {"pid_source", "System.Diagnostics.Process.Start"},
                    {"parent_pid", obs.ParentPid},
                    {"parent_binding_verified", true},
                    {"creation_time_filetime_100ns", obs.CreationTime},
                    {"creation_time_rechecked_filetime_100ns", StartTimeFileTimeWithRetry(childPid)},
                    {"executable_name", Path.GetFileName(obs.WmiPath)},
                    {"executable_sha256", observedSha},
                    {"same_directory_binding_verified", true},
                    {"wmi_path_observation_attempts", obs.PathAttempts},
                    {"wmi_path_observation_elapsed_ms", obs.PathElapsedMs},
                    {"wmi_path_resolved", true},
                    {"dotnet_path_matches_expected", true},
                    {"identity", "NOT_PROVED"}
                };

                receipt["child_message"] = new Dictionary<string, object> {
                    {"sequence", 0},
                    {"generated_by", "DEDICATED_MEDIATOR_CANDIDATE"},
                    {"payload_handling", "OPAQUE_BYTES_NOT_PARSED"},
                    {"payload_sha256", observedPayloadSha},
                    {"payload_length", stdoutBytes.Length},
                    {"trust", "UNTRUSTED_CHILD_INPUT"},
                    {"payload_content_in_receipt", false}
                };

                receipt["resource_bounds"] = new Dictionary<string, object> {
                    {"stdout_limit_bytes", stdoutLimit},
                    {"stderr_limit_bytes", stderrLimit},
                    {"timeout_ms", timeoutMs},
                    {"stdout_bytes", stdoutBytes.Length},
                    {"stderr_bytes", stderrBytes.Length},
                    {"stdout_limit_exceeded", false},
                    {"stderr_limit_exceeded", false},
                    {"timeout_triggered", false},
                    {"drain_mode", "CONCURRENT_BOUNDED"}
                };

                receipt["boundary"] = new Dictionary<string, object> {
                    {"child_content_schema", "NOT_INSPECTED"},
                    {"child_can_choose_principal", false},
                    {"child_can_receive_runtime_grant", false},
                    {"mediator_is_authenticated", false},
                    {"shared_interpreter_child_removed", true},
                    {"raw_local_paths_serialized", false},
                    {"process_instance_anchored_during_path_retry", true}
                };

                receipt["authorization_status"] = "NOT_AUTHORIZED";
                receipt["runtime_grant_issued"] = false;
                receipt["g1_token_issued"] = false;
                receipt["f2_unlocked"] = false;
                receipt["authority_effect"] = "NONE";

                var serializer = new JavaScriptSerializer();
                File.WriteAllText(output, serializer.Serialize(receipt), new UTF8Encoding(false));
                Console.WriteLine("R9A2_DEDICATED_MEDIATOR_CANDIDATE_RECEIPT_READY");
                Console.WriteLine("AUTHORITY_EFFECT=NONE");
                return 0;
            }
        }
    }
}
