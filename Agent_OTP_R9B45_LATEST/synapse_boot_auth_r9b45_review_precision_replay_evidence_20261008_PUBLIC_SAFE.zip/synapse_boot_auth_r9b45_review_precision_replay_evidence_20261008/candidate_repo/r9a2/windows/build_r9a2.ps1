param(
    [Parameter(Mandatory=$true)][string]$MediatorSource,
    [Parameter(Mandatory=$true)][string]$ChildSource,
    [Parameter(Mandatory=$true)][string]$MediatorExe,
    [Parameter(Mandatory=$true)][string]$ChildExe,
    [Parameter(Mandatory=$true)][string]$BuildReceipt
)
$ErrorActionPreference="Stop"
$candidates=@(
 (Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
 (Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe")
)
$csc=$candidates|Where-Object {Test-Path -LiteralPath $_ -PathType Leaf}|Select-Object -First 1
if(-not $csc){throw "R9A2_CSC_NOT_FOUND"}
$medSrc=[IO.Path]::GetFullPath($MediatorSource)
$childSrc=[IO.Path]::GetFullPath($ChildSource)
$medOut=[IO.Path]::GetFullPath($MediatorExe)
$childOut=[IO.Path]::GetFullPath($ChildExe)
$receipt=[IO.Path]::GetFullPath($BuildReceipt)
& $csc /nologo /target:exe /optimize+ /platform:anycpu ("/out:"+$childOut) $childSrc
if($LASTEXITCODE -ne 0){throw "R9A2_CHILD_CSC_BUILD_FAILED"}
& $csc /nologo /target:exe /optimize+ /platform:anycpu ("/out:"+$medOut) /reference:System.Management.dll /reference:System.Web.Extensions.dll $medSrc
if($LASTEXITCODE -ne 0){throw "R9A2_MEDIATOR_CSC_BUILD_FAILED"}
$build=[ordered]@{
 schema_version="SYNAPSE-R9A2-BUILD-RECEIPT-1";status="CANDIDATE"
 mediator_source_sha256=(Get-FileHash -LiteralPath $medSrc -Algorithm SHA256).Hash.ToLowerInvariant()
 child_source_sha256=(Get-FileHash -LiteralPath $childSrc -Algorithm SHA256).Hash.ToLowerInvariant()
 mediator_binary_sha256=(Get-FileHash -LiteralPath $medOut -Algorithm SHA256).Hash.ToLowerInvariant()
 child_binary_sha256=(Get-FileHash -LiteralPath $childOut -Algorithm SHA256).Hash.ToLowerInvariant()
 compiler_sha256=(Get-FileHash -LiteralPath $csc -Algorithm SHA256).Hash.ToLowerInvariant()
 compiler_kind="DOTNET_FRAMEWORK_CSC"
 mediator_binary_name=[IO.Path]::GetFileName($medOut)
 child_binary_name=[IO.Path]::GetFileName($childOut)
 workload_identity_mode="DEDICATED_EXECUTABLE_CANDIDATE"
 child_identity="NOT_PROVED"
 authentication_result="NOT_PERFORMED";authorization_status="NOT_AUTHORIZED";authority_effect="NONE"
}
$build|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $receipt -Encoding UTF8
Write-Host "R9A2_BUILD_CANDIDATE_READY"
Write-Host ("MEDIATOR_BINARY_SHA256 "+$build.mediator_binary_sha256)
Write-Host ("CHILD_BINARY_SHA256 "+$build.child_binary_sha256)
Write-Host "AUTHORITY_EFFECT=NONE"
