from pathlib import Path
S=(Path(__file__).parents[1]/"src"/"DedicatedMediator.cs").read_text(encoding="utf-8")
def test_bounded_path_observation():
    assert "PathObservationTimeoutMs = 1200" in S
    assert "R9A2_CHILD_PATH_OBSERVATION_TIMEOUT" in S
    assert "Thread.Sleep(25)" in S
def test_instance_anchored_during_retry():
    assert "StartTimeFileTimeWithRetry" in S
    assert "R9A2_CHILD_INSTANCE_CHANGED_DURING_PATH_OBSERVATION" in S
    assert "process_instance_anchored_during_path_retry" in S
def test_drains_start_before_path_retry():
    drain=S.index("Task<byte[]> stdoutTask")
    observe=S.index("ObserveChildIdentity(childPid")
    assert drain < observe
def test_no_fixed_single_300ms_sleep():
    assert "Thread.Sleep(300)" not in S
def test_dotnet_path_is_independent_corroboration():
    assert "DotNetProcessPath" in S
    assert "R9A2_CHILD_DOTNET_PATH_MISMATCH" in S
def test_raw_paths_not_serialized():
    assert '"raw_local_paths_serialized", false' in S
    assert '"executable_name"' in S
