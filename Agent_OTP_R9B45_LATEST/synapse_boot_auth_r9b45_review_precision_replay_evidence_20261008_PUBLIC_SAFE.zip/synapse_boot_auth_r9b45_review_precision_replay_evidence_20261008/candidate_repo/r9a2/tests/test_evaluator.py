from r9a2.evaluator import evaluate,Denied
def pair():
    a="a"*64;b="b"*64
    r={"schema_version":"SYNAPSE-R9A2-DEDICATED-MEDIATOR-CANDIDATE-1",
       "mediator":{"pid":100,"executable_name":"R9A2_DedicatedMediator.exe","executable_sha256":a,"status":"CANDIDATE","authentication_result":"NOT_PERFORMED"},
       "child_instance":{"pid":200,"parent_pid":100,"parent_binding_verified":True,"creation_time_filetime_100ns":1,"creation_time_rechecked_filetime_100ns":1,
         "executable_name":"R9A2_SyntheticChild.exe","executable_sha256":b,"same_directory_binding_verified":True,"wmi_path_observation_attempts":4,
         "wmi_path_observation_elapsed_ms":302,"wmi_path_resolved":True,"dotnet_path_matches_expected":True,"identity":"NOT_PROVED"},
       "child_message":{"payload_handling":"OPAQUE_BYTES_NOT_PARSED","trust":"UNTRUSTED_CHILD_INPUT","payload_content_in_receipt":False,"payload_sha256":"c"*64},
       "resource_bounds":{"drain_mode":"CONCURRENT_BOUNDED","stdout_limit_exceeded":False,"stderr_limit_exceeded":False,"timeout_triggered":False},
       "boundary":{"process_instance_anchored_during_path_retry":True,"mediator_is_authenticated":False,"child_can_choose_principal":False,"child_can_receive_runtime_grant":False,"raw_local_paths_serialized":False},
       "authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"}
    build={"schema_version":"SYNAPSE-R9A2-BUILD-RECEIPT-1","mediator_source_sha256":"d"*64,"child_source_sha256":"e"*64,"mediator_binary_sha256":a,
      "child_binary_sha256":b,"compiler_sha256":"f"*64,"mediator_binary_name":"R9A2_DedicatedMediator.exe","child_binary_name":"R9A2_SyntheticChild.exe",
      "child_identity":"NOT_PROVED","authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}
    return r,build
def test_ready_after_bounded_observation():
    r,b=pair();o=evaluate(r,b);assert o["result"]=="R9A2_DEDICATED_MEDIATOR_OBSERVATION_BOUND_READY"
def test_wmi_unresolved_denied():
    r,b=pair();r["child_instance"]["wmi_path_resolved"]=False
    try:evaluate(r,b)
    except Denied as e: assert e.code=="WMI_PATH_NOT_RESOLVED"
    else:assert False
def test_instance_anchor_required():
    r,b=pair();r["boundary"]["process_instance_anchored_during_path_retry"]=False
    try:evaluate(r,b)
    except Denied as e: assert e.code=="PROCESS_INSTANCE_ANCHOR_REQUIRED"
    else:assert False
def test_creation_mismatch_denied():
    r,b=pair();r["child_instance"]["creation_time_rechecked_filetime_100ns"]=2
    try:evaluate(r,b)
    except Denied as e: assert e.code=="CHILD_INSTANCE_RECHECK_FAILED"
    else:assert False
def test_child_identity_overclaim_denied():
    r,b=pair();r["child_instance"]["identity"]="VERIFIED"
    try:evaluate(r,b)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else:assert False
