# R8B.1 — opaque child mediation rehearsal

R8B.1 changes the trust model from "filter child JSON fields" to:

`opaque child bytes -> mediator-generated provenance`

The child payload deliberately contains nested authority-looking strings. The mediator never parses those bytes.
It records only:
- exact child process binding,
- payload SHA-256,
- payload length,
- sequence,
- mediator-generated trust/provenance labels.

The receipt contains no raw payload and the child remains `NOT_PROVED`.

No mediator authentication or runtime authority occurs in R8B.1.
