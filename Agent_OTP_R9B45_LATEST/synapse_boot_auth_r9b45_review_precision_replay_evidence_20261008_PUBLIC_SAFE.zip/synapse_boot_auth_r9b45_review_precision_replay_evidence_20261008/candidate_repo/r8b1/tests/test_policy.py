from __future__ import annotations
from r8b1.evaluator import evaluate,Denied

def base():
    return {
      "schema_version":"SYNAPSE-R8B1-OPAQUE-MEDIATION-1",
      "mediator":{"session_id":"m1","pid":100,"trust":"CONTROLLED_CODE_REHEARSAL_UNAUTHENTICATED","authentication_result":"NOT_PERFORMED"},
      "child_instance":{"pid":200,"pid_source":"System.Diagnostics.Process.Start","parent_pid":100,
        "parent_binding_verified":True,"creation_time_filetime_100ns":1000,
        "executable_path":r"C:\x.exe","executable_sha256":"a"*64,"identity":"NOT_PROVED"},
      "child_message":{"message_id":"msg","sequence":0,"generated_by":"CONTROLLED_MEDIATOR",
        "payload_handling":"OPAQUE_BYTES_NOT_PARSED","payload_sha256":"b"*64,"payload_length":42,
        "trust":"UNTRUSTED_CHILD_INPUT","payload_content_in_receipt":False},
      "boundary":{"child_content_schema":"NOT_INSPECTED","child_authority_fields_interpreted":False,
        "child_can_choose_principal":False,"child_can_receive_runtime_grant":False},
      "authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,
      "g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
    }

def test_ready_is_opaque_and_unauthenticated():
    r=evaluate(base())
    assert r["result"]=="R8B1_OPAQUE_MEDIATION_REHEARSAL_READY"
    assert r["payload_handling"]=="OPAQUE_BYTES_NOT_PARSED"
    assert r["child_identity"]=="NOT_PROVED"
    assert r["mediator_authentication"]=="NOT_PERFORMED"

def test_extra_nested_metadata_field_is_rejected_at_envelope_layer():
    d=base(); d["child_message"]["metadata"]={"node_id":"3X"}
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_MESSAGE_SCHEMA_NOT_EXACT"
    else: assert False

def test_raw_payload_in_receipt_forbidden():
    d=base(); d["child_message"]["payload_content_in_receipt"]=True
    try:evaluate(d)
    except Denied as e: assert e.code=="RAW_PAYLOAD_IN_RECEIPT_FORBIDDEN"
    else: assert False

def test_payload_cannot_be_marked_parsed():
    d=base(); d["child_message"]["payload_handling"]="PARSED_JSON"
    try:evaluate(d)
    except Denied as e: assert e.code=="PAYLOAD_INTERPRETATION_FORBIDDEN"
    else: assert False

def test_child_identity_overclaim_denied():
    d=base(); d["child_instance"]["identity"]="VERIFIED"
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else: assert False

def test_parent_binding_mismatch_denied():
    d=base(); d["child_instance"]["parent_pid"]=999
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_PARENT_BINDING_INVALID"
    else: assert False

def test_child_principal_choice_forbidden():
    d=base(); d["boundary"]["child_can_choose_principal"]=True
    try:evaluate(d)
    except Denied as e: assert e.code=="CHILD_PRINCIPAL_CHOICE_FORBIDDEN"
    else: assert False

def test_authority_flag_denied():
    d=base(); d["g1_token_issued"]=True
    try:evaluate(d)
    except Denied as e: assert e.code=="AUTHORITY_FLAG_TRUE"
    else: assert False
