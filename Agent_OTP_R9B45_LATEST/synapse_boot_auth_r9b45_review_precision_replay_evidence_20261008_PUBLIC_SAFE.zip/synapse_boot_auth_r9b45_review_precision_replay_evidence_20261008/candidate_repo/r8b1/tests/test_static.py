from pathlib import Path
S=(Path(__file__).parents[1]/"windows"/"run_r8b1_opaque_mediation.ps1").read_text(encoding="utf-8")
def test_child_payload_contains_attack_like_nested_fields_but_is_not_parsed():
    assert 'UNTRUSTED_CHILD_CLAIM' in S
    assert 'UNTRUSTED_CHILD_TOKEN' in S
    assert 'OPAQUE_BYTES_NOT_PARSED' in S
    assert 'child_authority_fields_interpreted = $false' in S
def test_receipt_excludes_raw_payload():
    assert 'payload_content_in_receipt = $false' in S
def test_stdout_read_as_bytes():
    assert 'StandardOutput.BaseStream.CopyTo' in S
def test_no_authority():
    assert 'authorization_status = "NOT_AUTHORIZED"' in S
    assert 'authority_effect = "NONE"' in S

def test_powershell51_compatible_crypto_api_only():
    assert 'ToHexString' not in S
    assert '::HashData(' not in S
    assert 'SHA256]::Create()' in S
    assert 'ComputeHash(' in S
    assert '[BitConverter]::ToString' in S
