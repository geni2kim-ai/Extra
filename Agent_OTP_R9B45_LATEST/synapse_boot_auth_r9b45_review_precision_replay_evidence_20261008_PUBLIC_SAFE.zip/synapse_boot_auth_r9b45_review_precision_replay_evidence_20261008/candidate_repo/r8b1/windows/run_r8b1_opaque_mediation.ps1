param(
    [Parameter(Mandatory=$true)]
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

$mediatorSessionId = "r8b1-mediator-" + [guid]::NewGuid().ToString("N")
$mediatorPid = $PID
$targetExe = (Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$targetHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash.ToLowerInvariant()

# Deliberately includes nested authority-looking text. The mediator MUST NOT parse or trust it.
$payloadText = '{"meta":{"node_id":"UNTRUSTED_CHILD_CLAIM","token":"UNTRUSTED_CHILD_TOKEN"},"data":"hello"}'
$payloadBytesExpected = [Text.Encoding]::UTF8.GetBytes($payloadText)
$sha256Expected = [System.Security.Cryptography.SHA256]::Create()
try {
    $payloadExpectedDigest = $sha256Expected.ComputeHash($payloadBytesExpected)
    $payloadExpectedSha = ([BitConverter]::ToString($payloadExpectedDigest)).Replace("-","").ToLowerInvariant()
}
finally {
    $sha256Expected.Dispose()
}

$payloadB64 = [Convert]::ToBase64String($payloadBytesExpected)
$childCommand = @"
`$b=[Convert]::FromBase64String('$payloadB64');
`$s=[Console]::OpenStandardOutput();
`$s.Write(`$b,0,`$b.Length);
`$s.Flush()
"@
$encodedChild = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($childCommand))

$psi = New-Object System.Diagnostics.ProcessStartInfo
$psi.FileName = $targetExe
$psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -EncodedCommand " + $encodedChild
$psi.UseShellExecute = $false
$psi.CreateNoWindow = $true
$psi.RedirectStandardOutput = $true
$psi.RedirectStandardError = $true

$child = New-Object System.Diagnostics.Process
$child.StartInfo = $psi
$started = $false

try {
    $started = $child.Start()
    if (-not $started) { throw "R8B1_CHILD_START_FAILED" }

    $childPid = [int]$child.Id
    $proc1 = Get-CimInstance Win32_Process -Filter ("ProcessId=" + $childPid)
    if (-not $proc1) { throw "R8B1_CHILD_PROCESS_NOT_OBSERVED" }

    $observedParentPid = [int]$proc1.ParentProcessId
    if ($observedParentPid -ne $mediatorPid) { throw "R8B1_CHILD_PARENT_PID_MISMATCH" }

    $path1 = [string]$proc1.ExecutablePath
    if (-not $path1 -or -not $path1.Equals($targetExe,[StringComparison]::OrdinalIgnoreCase)) {
        throw "R8B1_CHILD_PATH_MISMATCH"
    }
    $ctime1 = $proc1.CreationDate
    if (-not ($ctime1 -is [datetime])) { throw "R8B1_CHILD_CREATION_TIME_INVALID" }
    $ctimeUtc1 = ([datetime]$ctime1).ToUniversalTime()

    $observedExeHash = (Get-FileHash -LiteralPath $path1 -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($observedExeHash -ne $targetHash) { throw "R8B1_CHILD_EXE_HASH_MISMATCH" }

    # Read exact stdout bytes. Do not parse payload content.
    $ms = New-Object System.IO.MemoryStream
    $child.StandardOutput.BaseStream.CopyTo($ms)
    $payloadBytes = $ms.ToArray()
    $ms.Dispose()

    $stderrText = $child.StandardError.ReadToEnd()
    $child.WaitForExit()
    if ($child.ExitCode -ne 0) { throw "R8B1_CHILD_EXIT_NONZERO" }
    if (-not [string]::IsNullOrEmpty($stderrText)) { throw "R8B1_CHILD_STDERR_NONEMPTY" }

    $sha256Observed = [System.Security.Cryptography.SHA256]::Create()
    try {
        $payloadDigest = $sha256Observed.ComputeHash($payloadBytes)
        $payloadSha = ([BitConverter]::ToString($payloadDigest)).Replace("-","").ToLowerInvariant()
    }
    finally {
        $sha256Observed.Dispose()
    }
    if ($payloadSha -ne $payloadExpectedSha) { throw "R8B1_PAYLOAD_HASH_MISMATCH" }

    # Process instance was already bound while alive. Receipt carries only mediator-generated metadata.
    $report = [ordered]@{
        schema_version = "SYNAPSE-R8B1-OPAQUE-MEDIATION-1"
        collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
        mediator = [ordered]@{
            session_id = $mediatorSessionId
            pid = $mediatorPid
            trust = "CONTROLLED_CODE_REHEARSAL_UNAUTHENTICATED"
            authentication_result = "NOT_PERFORMED"
        }
        child_instance = [ordered]@{
            pid = $childPid
            pid_source = "System.Diagnostics.Process.Start"
            parent_pid = $observedParentPid
            parent_binding_verified = ($observedParentPid -eq $mediatorPid)
            creation_time_filetime_100ns = $ctimeUtc1.ToFileTimeUtc()
            executable_path = $path1
            executable_sha256 = $observedExeHash
            identity = "NOT_PROVED"
        }
        child_message = [ordered]@{
            message_id = "msg-" + [guid]::NewGuid().ToString("N")
            sequence = 0
            generated_by = "CONTROLLED_MEDIATOR"
            payload_handling = "OPAQUE_BYTES_NOT_PARSED"
            payload_sha256 = $payloadSha
            payload_length = $payloadBytes.Length
            trust = "UNTRUSTED_CHILD_INPUT"
            payload_content_in_receipt = $false
        }
        boundary = [ordered]@{
            child_content_schema = "NOT_INSPECTED"
            child_authority_fields_interpreted = $false
            child_can_choose_principal = $false
            child_can_receive_runtime_grant = $false
        }
        authorization_status = "NOT_AUTHORIZED"
        runtime_grant_issued = $false
        g1_token_issued = $false
        f2_unlocked = $false
        authority_effect = "NONE"
    }

    $report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
    $sha = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
    Write-Host "R8B1_OPAQUE_MEDIATION_RECEIPT_READY"
    Write-Host ("SHA256 " + $sha)
    Write-Host "AUTHORITY_EFFECT=NONE"
}
finally {
    if ($started -and $child -and -not $child.HasExited) {
        try { $child.Kill(); $child.WaitForExit(5000) | Out-Null } catch {}
    }
    if ($child) { $child.Dispose() }
}
