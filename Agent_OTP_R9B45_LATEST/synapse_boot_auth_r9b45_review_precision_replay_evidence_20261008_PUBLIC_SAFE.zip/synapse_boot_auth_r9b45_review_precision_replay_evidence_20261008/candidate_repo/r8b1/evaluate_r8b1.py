#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from r8b1.evaluator import evaluate,Denied
def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument("input"); ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args(); doc=json.loads(Path(ns.input).read_text(encoding="utf-8-sig"))
    try: result=evaluate(doc); code=0
    except Denied as e:
        result={"result":"R8B1_DENIED","code":e.code,"authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}; code=2
    Path(ns.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2,ensure_ascii=False)); return code
if __name__=="__main__": raise SystemExit(main())
