from __future__ import annotations
from typing import Any
import re

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

ALLOWED_MESSAGE_KEYS = {
    "message_id","sequence","generated_by","payload_handling",
    "payload_sha256","payload_length","trust","payload_content_in_receipt"
}
ALLOWED_CHILD_KEYS = {
    "pid","pid_source","parent_pid","parent_binding_verified",
    "creation_time_filetime_100ns","executable_path","executable_sha256","identity"
}

def evaluate(doc:dict[str,Any])->dict[str,Any]:
    if doc.get("schema_version")!="SYNAPSE-R8B1-OPAQUE-MEDIATION-1":
        raise Denied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect")!="NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status")!="NOT_AUTHORIZED":
        raise Denied("AUTHORIZATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if doc.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")

    mediator=doc.get("mediator") or {}
    if mediator.get("trust")!="CONTROLLED_CODE_REHEARSAL_UNAUTHENTICATED":
        raise Denied("MEDIATOR_TRUST_INVALID")
    if mediator.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("MEDIATOR_AUTH_PRECLAIMED")
    mpid=mediator.get("pid")
    if not isinstance(mpid,int) or mpid<=0:
        raise Denied("MEDIATOR_PID_INVALID")

    child=doc.get("child_instance") or {}
    if set(child) != ALLOWED_CHILD_KEYS:
        raise Denied("CHILD_INSTANCE_SCHEMA_NOT_EXACT")
    if child.get("identity")!="NOT_PROVED":
        raise Denied("CHILD_IDENTITY_OVERCLAIM")
    if child.get("pid_source")!="System.Diagnostics.Process.Start":
        raise Denied("CHILD_PID_SOURCE_INVALID")
    if child.get("parent_pid")!=mpid or child.get("parent_binding_verified") is not True:
        raise Denied("CHILD_PARENT_BINDING_INVALID")
    if not isinstance(child.get("pid"),int) or child["pid"]<=0:
        raise Denied("CHILD_PID_INVALID")
    if not isinstance(child.get("creation_time_filetime_100ns"),int) or child["creation_time_filetime_100ns"]<=0:
        raise Denied("CHILD_CREATION_TIME_INVALID")
    h=child.get("executable_sha256")
    if not isinstance(h,str) or not re.fullmatch(r"[0-9a-f]{64}",h):
        raise Denied("CHILD_SHA_INVALID")

    msg=doc.get("child_message") or {}
    if set(msg) != ALLOWED_MESSAGE_KEYS:
        raise Denied("CHILD_MESSAGE_SCHEMA_NOT_EXACT")
    if msg.get("generated_by")!="CONTROLLED_MEDIATOR":
        raise Denied("MESSAGE_PROVENANCE_INVALID")
    if msg.get("payload_handling")!="OPAQUE_BYTES_NOT_PARSED":
        raise Denied("PAYLOAD_INTERPRETATION_FORBIDDEN")
    if msg.get("trust")!="UNTRUSTED_CHILD_INPUT":
        raise Denied("CHILD_MESSAGE_TRUST_INVALID")
    if msg.get("payload_content_in_receipt") is not False:
        raise Denied("RAW_PAYLOAD_IN_RECEIPT_FORBIDDEN")
    if not isinstance(msg.get("sequence"),int) or msg["sequence"]<0:
        raise Denied("MESSAGE_SEQUENCE_INVALID")
    ph=msg.get("payload_sha256")
    if not isinstance(ph,str) or not re.fullmatch(r"[0-9a-f]{64}",ph):
        raise Denied("PAYLOAD_SHA_INVALID")
    if not isinstance(msg.get("payload_length"),int) or msg["payload_length"]<0:
        raise Denied("PAYLOAD_LENGTH_INVALID")

    boundary=doc.get("boundary") or {}
    if boundary.get("child_content_schema")!="NOT_INSPECTED":
        raise Denied("CHILD_CONTENT_SCHEMA_OVERCLAIM")
    if boundary.get("child_authority_fields_interpreted") is not False:
        raise Denied("CHILD_AUTHORITY_INTERPRETATION_FORBIDDEN")
    if boundary.get("child_can_choose_principal") is not False:
        raise Denied("CHILD_PRINCIPAL_CHOICE_FORBIDDEN")
    if boundary.get("child_can_receive_runtime_grant") is not False:
        raise Denied("CHILD_RUNTIME_GRANT_FORBIDDEN")

    return {
      "result":"R8B1_OPAQUE_MEDIATION_REHEARSAL_READY",
      "mediator_authentication":"NOT_PERFORMED",
      "child_identity":"NOT_PROVED",
      "child_message_trust":"UNTRUSTED_CHILD_INPUT",
      "payload_handling":"OPAQUE_BYTES_NOT_PARSED",
      "next_action":"R9_DEDICATED_MEDIATOR_BINARY_REQUIRED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
    }
