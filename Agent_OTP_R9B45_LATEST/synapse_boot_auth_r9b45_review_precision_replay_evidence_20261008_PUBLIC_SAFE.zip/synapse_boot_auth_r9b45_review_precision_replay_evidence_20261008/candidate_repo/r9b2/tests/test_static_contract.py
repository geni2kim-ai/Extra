from pathlib import Path
ROOT=Path(__file__).parents[1]
P=(ROOT/"windows"/"provision_r9b2_registry.ps1").read_text(encoding="utf-8")
M=(ROOT/"windows"/"run_r9b2_measurement.ps1").read_text(encoding="utf-8")
def test_provisioning_is_explicit_separate_script():
    assert "EXPLICIT_OPERATOR_REHEARSAL" in P
    assert "PREPROVISIONED_REHEARSAL_ONLY" in P
def test_measurement_consumes_registry_and_pin():
    assert "[string]$RegistryPath" in M
    assert "[string]$RegistryPinPath" in M
    assert "R9B2_REGISTRY_PIN_MISMATCH" in M
def test_measurement_does_not_self_enroll_current_user():
    assert "WindowsIdentity]::GetCurrent" not in M
    assert "derived_workload_id=" not in M
def test_measurement_does_not_write_registry_or_pin():
    assert 'Set-Content -LiteralPath $registryFile' not in M
    assert 'Set-Content -LiteralPath $pinFile' not in M
def test_pipe_acl_sid_comes_from_pinned_registry():
    assert '$allowedSid=[string]$entry.allowed_user_sid' in M
    assert '" -AllowedClientSid "+$allowedSid' in M
