from r9b2.evaluator import evaluate,Denied
def data():
    sha="a"*64; regsha="b"*64
    c={"schema_version":"SYNAPSE-R6-NAMED-PIPE-CAPTURE-1","pipe":{"remote_clients_rejected":True,"explicit_acl":True,"allowed_client_sid":"S-1-5-21-123"},
      "client":{"pid":1,"pid_source":"GetNamedPipeClientProcessId","process_creation_time_100ns":1,"process_creation_time_rechecked_100ns":1,
        "process_path":r"C:\x\R9B1_DedicatedMediator.exe","process_path_rechecked":r"c:\X\R9B1_DedicatedMediator.exe",
        "process_sha256":sha,"process_active_after_capture":True},
      "token":{"user_sid":"S-1-5-21-123","token_source":"ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)","impersonation_succeeded":True},
      "evidence_source":"OpenProcess+GetProcessTimes+QueryFullProcessImageName","caller_claims":{"claimed_node_id":None,"claimed_workload_id":None},
      "authentication_result":"CAPTURE_ONLY","authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"}
    b={"schema_version":"SYNAPSE-R9B1-BUILD-RECEIPT-1","mediator_binary_sha256":sha,"mediator_binary_name":"R9B1_DedicatedMediator.exe",
       "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}
    r={"schema_version":"SYNAPSE-R9B2-PREPROVISIONED-VERIFIER-REGISTRY-1","registry_id":"r1","registry_trust":"PREPROVISIONED_REHEARSAL_ONLY",
       "entries":[{"derived_workload_id":"W1","mediator_binary_sha256":sha,"allowed_user_sid":"S-1-5-21-123"}],"authority_effect":"NONE"}
    p={"schema_version":"SYNAPSE-R9B2-REGISTRY-PIN-1","registry_sha256":regsha,"registry_id":"r1","pin_mode":"EXACT_FILE_SHA256",
       "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}
    return c,b,r,p,regsha
def test_ready_but_not_authenticated():
    c,b,r,p,s=data();o=evaluate(c,b,r,p,s)
    assert o["result"]=="R9B2_PREPROVISIONED_WORKLOAD_MEASUREMENT_READY"
    assert o["authentication_result"]=="MEASURED_NOT_AUTHENTICATED"
    assert o["registry_created_by_measurement_runner"] is False
def test_pin_mismatch_denied():
    c,b,r,p,s=data();p["registry_sha256"]="c"*64
    try:evaluate(c,b,r,p,s)
    except Denied as e:assert e.code=="REGISTRY_PIN_MISMATCH"
    else:assert False
def test_registry_id_mismatch_denied():
    c,b,r,p,s=data();p["registry_id"]="other"
    try:evaluate(c,b,r,p,s)
    except Denied as e:assert e.code=="REGISTRY_ID_MISMATCH"
    else:assert False
def test_duplicate_registry_match_denied():
    c,b,r,p,s=data();r["entries"].append(dict(r["entries"][0]))
    try:evaluate(c,b,r,p,s)
    except Denied as e:assert e.code=="REGISTRY_MATCH_NOT_UNIQUE"
    else:assert False
def test_sid_mismatch_denied():
    c,b,r,p,s=data();c["token"]["user_sid"]="S-1-5-21-999"
    try:evaluate(c,b,r,p,s)
    except Denied as e:assert e.code=="PIPE_ALLOWED_SID_MISMATCH"
    else:assert False
def test_node_claim_forbidden():
    c,b,r,p,s=data();c["caller_claims"]["claimed_node_id"]="3X"
    try:evaluate(c,b,r,p,s)
    except Denied as e:assert e.code=="CLIENT_IDENTITY_CLAIMS_MUST_BE_ABSENT"
    else:assert False
