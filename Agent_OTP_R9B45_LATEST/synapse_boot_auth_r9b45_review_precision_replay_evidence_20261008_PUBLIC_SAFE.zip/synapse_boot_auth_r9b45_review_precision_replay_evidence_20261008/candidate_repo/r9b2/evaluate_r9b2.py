#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from r9b2.evaluator import evaluate,Denied

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("capture")
    ap.add_argument("--build-receipt",required=True)
    ap.add_argument("--registry",required=True)
    ap.add_argument("--registry-pin",required=True)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    cp=Path(ns.capture);bp=Path(ns.build_receipt);rp=Path(ns.registry);pp=Path(ns.registry_pin)
    c=json.loads(cp.read_text(encoding="utf-8-sig"));b=json.loads(bp.read_text(encoding="utf-8-sig"))
    r=json.loads(rp.read_text(encoding="utf-8-sig"));p=json.loads(pp.read_text(encoding="utf-8-sig"))
    try:
        out=evaluate(c,b,r,p,sha(rp));code=0
        out["evidence_bindings"]={"raw_capture_sha256":sha(cp),"build_receipt_sha256":sha(bp),
          "registry_sha256":sha(rp),"registry_pin_sha256":sha(pp)}
    except Denied as e:
        out={"result":"R9B2_DENIED","code":e.code,"authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"};code=2
    Path(ns.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps(out,indent=2,ensure_ascii=False));return code
if __name__=="__main__":raise SystemExit(main())
