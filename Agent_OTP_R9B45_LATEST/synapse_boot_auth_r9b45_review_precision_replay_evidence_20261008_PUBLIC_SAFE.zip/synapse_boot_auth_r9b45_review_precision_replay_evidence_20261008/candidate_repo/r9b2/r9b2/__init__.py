"""R9B.2 pre-provisioned pinned registry measurement."""
