#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("raw_registry");ap.add_argument("-o","--output",required=True);ap.add_argument("--lineage",required=True)
    ns=ap.parse_args();raw=Path(ns.raw_registry);out=Path(ns.output);lin=Path(ns.lineage)
    d=json.loads(raw.read_text(encoding="utf-8-sig"))
    for e in d.get("entries",[]):
        if isinstance(e,dict) and "allowed_user_sid" in e:e["allowed_user_sid"]="SID_MASKED"
    out.write_text(json.dumps(d,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    lin.write_text(json.dumps({"schema_version":"SYNAPSE-R9B2-REGISTRY-MASKING-LINEAGE-1",
      "raw_registry_sha256":sha(raw),"masked_registry_sha256":sha(out),"masked_fields":["entries[].allowed_user_sid"],
      "authority_effect":"NONE"},indent=2)+"\n",encoding="utf-8")
    return 0
if __name__=="__main__":raise SystemExit(main())
