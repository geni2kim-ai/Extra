param(
    [Parameter(Mandatory=$true)][string]$BuildReceipt,
    [Parameter(Mandatory=$true)][string]$AllowedUserSid,
    [Parameter(Mandatory=$true)][string]$DerivedWorkloadId,
    [Parameter(Mandatory=$true)][string]$OutputRegistry,
    [Parameter(Mandatory=$true)][string]$OutputPin
)
$ErrorActionPreference="Stop"

$buildPath=[IO.Path]::GetFullPath($BuildReceipt)
$registryPath=[IO.Path]::GetFullPath($OutputRegistry)
$pinPath=[IO.Path]::GetFullPath($OutputPin)

if(-not(Test-Path -LiteralPath $buildPath -PathType Leaf)){throw "R9B2_BUILD_RECEIPT_NOT_FOUND"}
if($AllowedUserSid -notmatch '^S-[0-9-]+$'){throw "R9B2_ALLOWED_SID_INVALID"}
if([string]::IsNullOrWhiteSpace($DerivedWorkloadId) -or $DerivedWorkloadId.Length -gt 80){
  throw "R9B2_WORKLOAD_ID_INVALID"
}

$build=Get-Content -LiteralPath $buildPath -Raw|ConvertFrom-Json
if($build.schema_version -ne "SYNAPSE-R9B1-BUILD-RECEIPT-1"){throw "R9B2_BUILD_SCHEMA_INVALID"}
if($build.authentication_result -ne "NOT_PERFORMED" -or $build.authorization_status -ne "NOT_AUTHORIZED" -or $build.authority_effect -ne "NONE"){
  throw "R9B2_BUILD_AUTHORITY_OVERCLAIM"
}
if($build.mediator_binary_sha256 -notmatch '^[0-9a-f]{64}$'){throw "R9B2_MEDIATOR_SHA_INVALID"}

$registry=[ordered]@{
 schema_version="SYNAPSE-R9B2-PREPROVISIONED-VERIFIER-REGISTRY-1"
 registry_id=("r9b2-registry-"+[guid]::NewGuid().ToString("N"))
 provisioning_mode="EXPLICIT_OPERATOR_REHEARSAL"
 registry_trust="PREPROVISIONED_REHEARSAL_ONLY"
 entries=@([ordered]@{
   derived_workload_id=$DerivedWorkloadId
   mediator_binary_sha256=$build.mediator_binary_sha256
   allowed_user_sid=$AllowedUserSid
 })
 authority_effect="NONE"
}
$registry|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $registryPath -Encoding UTF8
$registrySha=(Get-FileHash -LiteralPath $registryPath -Algorithm SHA256).Hash.ToLowerInvariant()

$pin=[ordered]@{
 schema_version="SYNAPSE-R9B2-REGISTRY-PIN-1"
 registry_sha256=$registrySha
 registry_id=$registry.registry_id
 pin_mode="EXACT_FILE_SHA256"
 authentication_result="NOT_PERFORMED"
 authorization_status="NOT_AUTHORIZED"
 authority_effect="NONE"
}
$pin|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $pinPath -Encoding UTF8

Write-Host "R9B2_REGISTRY_PROVISIONED"
Write-Host ("REGISTRY_SHA256 "+$registrySha)
Write-Host "AUTHORITY_EFFECT=NONE"
