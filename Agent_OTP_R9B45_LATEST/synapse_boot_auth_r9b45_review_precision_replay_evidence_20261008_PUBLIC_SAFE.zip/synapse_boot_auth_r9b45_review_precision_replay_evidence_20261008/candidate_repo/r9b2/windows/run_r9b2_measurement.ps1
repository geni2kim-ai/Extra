param(
    [Parameter(Mandatory=$true)][string]$MediatorExe,
    [Parameter(Mandatory=$true)][string]$BuildReceipt,
    [Parameter(Mandatory=$true)][string]$RegistryPath,
    [Parameter(Mandatory=$true)][string]$RegistryPinPath,
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference="Stop"

$exe=[IO.Path]::GetFullPath($MediatorExe)
$buildPath=[IO.Path]::GetFullPath($BuildReceipt)
$registryFile=[IO.Path]::GetFullPath($RegistryPath)
$pinFile=[IO.Path]::GetFullPath($RegistryPinPath)
$out=[IO.Path]::GetFullPath($OutputDirectory)

foreach($p in @($exe,$buildPath,$registryFile,$pinFile)){
  if(-not(Test-Path -LiteralPath $p -PathType Leaf)){throw ("R9B2_REQUIRED_FILE_MISSING "+$p)}
}
New-Item -ItemType Directory -Force -Path $out|Out-Null

$repoRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$serverScript=Join-Path $repoRoot "r6\windows\invoke_r6_capture_server.ps1"
if(-not(Test-Path -LiteralPath $serverScript -PathType Leaf)){throw "R9B2_R6_SERVER_NOT_FOUND"}

$build=Get-Content -LiteralPath $buildPath -Raw|ConvertFrom-Json
$registry=Get-Content -LiteralPath $registryFile -Raw|ConvertFrom-Json
$pin=Get-Content -LiteralPath $pinFile -Raw|ConvertFrom-Json

if($build.schema_version -ne "SYNAPSE-R9B1-BUILD-RECEIPT-1"){throw "R9B2_BUILD_SCHEMA_INVALID"}
if($registry.schema_version -ne "SYNAPSE-R9B2-PREPROVISIONED-VERIFIER-REGISTRY-1"){throw "R9B2_REGISTRY_SCHEMA_INVALID"}
if($pin.schema_version -ne "SYNAPSE-R9B2-REGISTRY-PIN-1"){throw "R9B2_PIN_SCHEMA_INVALID"}
if($registry.registry_trust -ne "PREPROVISIONED_REHEARSAL_ONLY"){throw "R9B2_REGISTRY_TRUST_INVALID"}
if($pin.pin_mode -ne "EXACT_FILE_SHA256"){throw "R9B2_PIN_MODE_INVALID"}

$actualRegistrySha=(Get-FileHash -LiteralPath $registryFile -Algorithm SHA256).Hash.ToLowerInvariant()
if($pin.registry_sha256 -ne $actualRegistrySha){throw "R9B2_REGISTRY_PIN_MISMATCH"}
if($pin.registry_id -ne $registry.registry_id){throw "R9B2_REGISTRY_ID_MISMATCH"}

$actualMedSha=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
if($build.mediator_binary_sha256 -ne $actualMedSha){throw "R9B2_BUILD_BINARY_SHA_MISMATCH"}

$registryMatches=@($registry.entries|Where-Object {$_.mediator_binary_sha256 -eq $actualMedSha})
if($registryMatches.Count -ne 1){throw "R9B2_REGISTRY_BINARY_MATCH_NOT_UNIQUE"}
$entry=$registryMatches[0]
$allowedSid=[string]$entry.allowed_user_sid
if($allowedSid -notmatch '^S-[0-9-]+$'){throw "R9B2_REGISTRY_ALLOWED_SID_INVALID"}

$pipeName="synapse-r9b2-"+[guid]::NewGuid().ToString("N")
$sessionId="r9b2-local-session-"+[guid]::NewGuid().ToString("N")
$capturePath=Join-Path $out "R9B2_capture.raw.json"
$completionPath=Join-Path $out "R9B2_server_completion.json"

function Q([string]$s){
 if($s.Contains('"')){throw "R9B2_QUOTE_IN_ARGUMENT_FORBIDDEN"}
 return '"'+$s+'"'
}

$psExe=(Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$serverPsi=New-Object Diagnostics.ProcessStartInfo
$serverPsi.FileName=$psExe
$serverPsi.Arguments=(
 "-NoProfile -ExecutionPolicy Bypass -File "+(Q $serverScript)+
 " -PipeName "+$pipeName+
 " -AllowedClientSid "+$allowedSid+
 " -NodeSessionId "+$sessionId+
 " -OutputPath "+(Q $capturePath)+
 " -CompletionPath "+(Q $completionPath)+
 " -MaxRequestBytes 4096"
)
$serverPsi.UseShellExecute=$false
$serverPsi.CreateNoWindow=$true
$serverPsi.RedirectStandardOutput=$true
$serverPsi.RedirectStandardError=$true

$clientPsi=New-Object Diagnostics.ProcessStartInfo
$clientPsi.FileName=$exe
$clientPsi.Arguments="--measure-pipe "+$pipeName
$clientPsi.UseShellExecute=$false
$clientPsi.CreateNoWindow=$true
$clientPsi.RedirectStandardOutput=$true
$clientPsi.RedirectStandardError=$true

$server=New-Object Diagnostics.Process
$client=New-Object Diagnostics.Process
$server.StartInfo=$serverPsi
$client.StartInfo=$clientPsi

try{
 if(-not $server.Start()){throw "R9B2_SERVER_START_FAILED"}
 $serverOutTask=$server.StandardOutput.ReadToEndAsync()
 $serverErrTask=$server.StandardError.ReadToEndAsync()

 if(-not $client.Start()){throw "R9B2_CLIENT_START_FAILED"}
 $clientOutTask=$client.StandardOutput.ReadToEndAsync()
 $clientErrTask=$client.StandardError.ReadToEndAsync()

 if(-not $client.WaitForExit(15000)){
   try{$client.Kill()}catch{}
   throw "R9B2_CLIENT_TIMEOUT"
 }
 $client.WaitForExit()
 if(-not $server.WaitForExit(15000)){
   try{$server.Kill()}catch{}
   throw "R9B2_SERVER_TIMEOUT"
 }
 $server.WaitForExit()

 $serverOut=$serverOutTask.GetAwaiter().GetResult()
 $serverErr=$serverErrTask.GetAwaiter().GetResult()
 $clientOut=$clientOutTask.GetAwaiter().GetResult()
 $clientErr=$clientErrTask.GetAwaiter().GetResult()
 $serverCode=[int]$server.ExitCode
 $clientCode=[int]$client.ExitCode

 [IO.File]::WriteAllText((Join-Path $out "server.stdout.txt"),$serverOut,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText((Join-Path $out "server.stderr.txt"),$serverErr,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText((Join-Path $out "client.stdout.txt"),$clientOut,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText((Join-Path $out "client.stderr.txt"),$clientErr,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText((Join-Path $out "server.exitcode.txt"),([string]$serverCode+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText((Join-Path $out "client.exitcode.txt"),([string]$clientCode+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false)))

 if($serverCode -ne 0){throw ("R9B2_SERVER_EXIT_NONZERO "+$serverCode)}
 if($clientCode -ne 0){throw ("R9B2_CLIENT_EXIT_NONZERO "+$clientCode)}
 if(-not(Test-Path -LiteralPath $capturePath -PathType Leaf)){throw "R9B2_CAPTURE_MISSING"}
 if(-not(Test-Path -LiteralPath $completionPath -PathType Leaf)){throw "R9B2_COMPLETION_MISSING"}

 $captureSha=(Get-FileHash -LiteralPath $capturePath -Algorithm SHA256).Hash.ToLowerInvariant()
 $completion=Get-Content -LiteralPath $completionPath -Raw|ConvertFrom-Json
 if($completion.capture_sha256 -ne $captureSha){throw "R9B2_COMPLETION_CAPTURE_SHA_MISMATCH"}
 if($completion.authorization_status -ne "NOT_AUTHORIZED" -or $completion.authority_effect -ne "NONE"){
   throw "R9B2_COMPLETION_AUTHORITY_OVERCLAIM"
 }

 $summary=[ordered]@{
   schema_version="SYNAPSE-R9B2-MEASUREMENT-HARNESS-1"
   status="CAPTURE_READY"
   registry_sha256=$actualRegistrySha
   registry_id=$registry.registry_id
   registry_trust=$registry.registry_trust
   registry_created_by_measurement_runner=$false
   capture_sha256=$captureSha
   mediator_binary_sha256=$actualMedSha
   server_exit_code=$serverCode
   client_exit_code=$clientCode
   authentication_result="NOT_PERFORMED"
   authorization_status="NOT_AUTHORIZED"
   authority_effect="NONE"
 }
 $summary|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $out "measurement_harness_summary.json") -Encoding UTF8
 Write-Host "R9B2_MEASUREMENT_CAPTURE_READY"
 Write-Host "AUTHORITY_EFFECT=NONE"
}
finally{
 if($client){$client.Dispose()}
 if($server){$server.Dispose()}
}
