# R9B.2 — pre-provisioned and SHA-pinned verifier registry

R9B.1 proved the local Named Pipe measurement chain, but its local registry was generated at measurement time
from the same mediator binary and current SID.

R9B.2 separates trust bootstrap from measurement.

## Provisioning

A separate operator step creates a rehearsal-only registry from:
- an already-created build receipt,
- an explicit allowed Windows SID,
- an explicit derived workload label.

It also creates an exact SHA-256 pin for the registry.

## Measurement

The measurement runner:
- accepts registry and pin as immutable inputs,
- verifies exact registry SHA and registry ID,
- never creates or rewrites them,
- configures the pipe ACL from the pinned registry SID,
- measures the dedicated mediator through the existing R6 process/token evidence path.

Even after PASS, the ceiling remains:

`MEASURED_NOT_AUTHENTICATED`

because a pinned local registry is still not a protected/non-exportable installation credential.
