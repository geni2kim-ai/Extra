#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from synapse_r6.model import Selector, NodeSession
from synapse_r6.policy import evaluate_capture, Denied

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("capture")
    ap.add_argument("selector")
    ap.add_argument("node_session")
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    c=json.loads(Path(ns.capture).read_text(encoding="utf-8-sig"))
    s=json.loads(Path(ns.selector).read_text(encoding="utf-8-sig"))
    n=json.loads(Path(ns.node_session).read_text(encoding="utf-8-sig"))
    selector=Selector(
      workload_id=s["workload_id"],
      stable_node_id=s["stable_node_id"],
      allowed_user_sids=frozenset(s["allowed_user_sids"]),
      allowed_service_sids=frozenset(s.get("allowed_service_sids",[])),
      require_service_sid=bool(s.get("require_service_sid",False)),
      executable_path=s["executable_path"],
      executable_sha256=s["executable_sha256"],
      status=s.get("status","ACTIVE"),
    )
    session=NodeSession(
      node_session_id=n["node_session_id"],
      stable_node_id=n["stable_node_id"],
      boot_instance_id=n["boot_instance_id"],
      status=n.get("status","ACTIVE"),
    )
    try:
        result=evaluate_capture(c,selector,session)
        code=0
    except Denied as exc:
        result={
          "result":"DENIED",
          "code":exc.code,
          "authorization_status":"NOT_AUTHORIZED",
          "authority_effect":"NONE",
        }
        code=2
    Path(ns.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return code

if __name__=="__main__":
    raise SystemExit(main())
