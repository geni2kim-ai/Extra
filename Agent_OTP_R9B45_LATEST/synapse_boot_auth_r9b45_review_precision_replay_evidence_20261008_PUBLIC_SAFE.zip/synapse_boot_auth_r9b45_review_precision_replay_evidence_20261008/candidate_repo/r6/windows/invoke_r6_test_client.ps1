param(
    [Parameter(Mandatory=$true)]
    [string]$PipeName,

    [string]$ClaimedNodeId = "R6-SYNTHETIC-NODE",

    [string]$ClaimedWorkloadId = "R6-SYNTHETIC-CLIENT",

    [int]$ConnectTimeoutMs = 5000
)

$ErrorActionPreference = "Stop"

$client = New-Object System.IO.Pipes.NamedPipeClientStream(
    ".",
    $PipeName,
    [System.IO.Pipes.PipeDirection]::Out,
    [System.IO.Pipes.PipeOptions]::None
)

try {
    $client.Connect($ConnectTimeoutMs)
    $payload = [ordered]@{
        claimed_node_id = $ClaimedNodeId
        claimed_workload_id = $ClaimedWorkloadId
    } | ConvertTo-Json -Compress

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
    $client.Write($bytes, 0, $bytes.Length)
    $client.Flush()
} finally {
    $client.Dispose()
}
