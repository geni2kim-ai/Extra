param(
    [Parameter(Mandatory=$true)]
    [string]$PipeName,

    [Parameter(Mandatory=$true)]
    [string]$AllowedClientSid,

    [Parameter(Mandatory=$true)]
    [string]$NodeSessionId,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath,

    [Parameter(Mandatory=$true)]
    [string]$CompletionPath,

    [Parameter(Mandatory=$true)]
    [string]$ExpectedCaptureSourceSha256,

    [int]$MaxRequestBytes = 4096
)

$ErrorActionPreference = "Stop"

if ($PipeName -notmatch '^[A-Za-z0-9._-]{1,80}$') { throw "INVALID_PIPE_NAME" }
if ($AllowedClientSid -cnotmatch '\AS-[0-9]+(?:-[0-9]+){2,}\z') { throw "INVALID_ALLOWED_CLIENT_SID" }
if ([string]::IsNullOrWhiteSpace($NodeSessionId)) { throw "INVALID_NODE_SESSION_ID" }
if ($NodeSessionId.Length -gt 256) { throw "NODE_SESSION_ID_TOO_LONG" }

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
$serverSid = $identity.User.Value

if ($ExpectedCaptureSourceSha256 -cnotmatch '\A[0-9a-f]{64}\z') { throw "INVALID_EXPECTED_CAPTURE_SOURCE_SHA256" }
$captureSourcePath = Join-Path $PSScriptRoot "R6NamedPipeCapture.cs"
$sourceBytes = [IO.File]::ReadAllBytes($captureSourcePath)
$shaObj = [Security.Cryptography.SHA256]::Create()
try {
    $sourceHashBytes = $shaObj.ComputeHash($sourceBytes)
} finally {
    $shaObj.Dispose()
}
$actualCaptureSourceSha256 = ($sourceHashBytes | ForEach-Object { $_.ToString("x2") }) -join ""
if ($actualCaptureSourceSha256 -cne $ExpectedCaptureSourceSha256) { throw "CAPTURE_SOURCE_SHA256_MISMATCH" }

if (-not ("SynapseR6.R6PipeCapture" -as [type])) {
    $source = [Text.Encoding]::UTF8.GetString($sourceBytes)
    Add-Type -TypeDefinition $source -Language CSharp
}

$result = [SynapseR6.R6PipeCapture]::Capture(
    $PipeName,
    $AllowedClientSid,
    $serverSid,
    $MaxRequestBytes
)

$claims = $null
try {
    $claims = $result.RequestUtf8 | ConvertFrom-Json
} catch {
    throw "CLIENT_REQUEST_JSON_INVALID"
}

$report = [ordered]@{
    schema_version = "SYNAPSE-R6-NAMED-PIPE-CAPTURE-1"
    captured_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    pipe = [ordered]@{
        name = $result.PipeName
        server_instance_id = $result.PipeServerInstanceId
        remote_clients_rejected = [bool]$result.RemoteClientsRejected
        explicit_acl = [bool]$result.ExplicitPipeAcl
        allowed_client_sid = $AllowedClientSid
        server_sid = $serverSid
    }
    client = [ordered]@{
        pid = [int]$result.ClientPid
        pid_rechecked = [int]$result.ClientPidRechecked
        pipe_client_pid_rechecked = [bool]$result.PipeClientPidRechecked
        pid_source = $result.ClientPidSource
        process_creation_time_100ns = [int64]$result.ProcessCreationTime100ns
        process_creation_time_rechecked_100ns = [int64]$result.ProcessCreationTimeRechecked100ns
        process_path = $result.ProcessPath
        process_path_rechecked = $result.ProcessPathRechecked
        process_sha256 = $result.ProcessSha256
        process_sha256_semantics = $result.ProcessSha256Semantics
        loaded_image_hash_verified = [bool]$result.LoadedImageHashVerified
        process_active_after_capture = [bool]$result.ProcessActiveAfterCapture
    }
    token = [ordered]@{
        user_sid = $result.TokenUserSid
        service_sids = @($result.TokenServiceSids)
        token_source = $result.TokenSource
        impersonation_succeeded = [bool]$result.ImpersonationSucceeded
    }
    evidence_source = $result.ProcessEvidenceSource
    captured_node_session_id = $NodeSessionId
    caller_claims = [ordered]@{
        claimed_node_id = $claims.claimed_node_id
        claimed_workload_id = $claims.claimed_workload_id
        measurement_nonce = $claims.measurement_nonce
    }
    authentication_result = "CAPTURE_ONLY"
    authorization_status = "NOT_AUTHORIZED"
    runtime_grant_issued = $false
    g1_token_issued = $false
    f2_unlocked = $false
    capture_source_sha256 = $actualCaptureSourceSha256
    authority_effect = "NONE"
}

$report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
$sha = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()

$completion = [ordered]@{
    schema_version = "SYNAPSE-R6-SERVER-COMPLETION-1"
    status = "SERVER_CAPTURE_COMPLETE"
    completed_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    pipe_name = $result.PipeName
    server_instance_id = $result.PipeServerInstanceId
    node_session_id = $NodeSessionId
    capture_sha256 = $sha
    measurement_nonce = $claims.measurement_nonce
    capture_source_sha256 = $actualCaptureSourceSha256
    authorization_status = "NOT_AUTHORIZED"
    authority_effect = "NONE"
}
$completion | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $CompletionPath -Encoding UTF8

Write-Host "WROTE_CAPTURE"
Write-Host ("SHA256 " + $sha)
Write-Host "AUTHORITY_EFFECT=NONE"
