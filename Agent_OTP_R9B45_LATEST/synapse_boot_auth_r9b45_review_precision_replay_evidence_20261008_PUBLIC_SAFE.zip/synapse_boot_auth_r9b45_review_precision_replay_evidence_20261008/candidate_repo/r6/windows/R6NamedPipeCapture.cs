using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace SynapseR6
{
    public sealed class CaptureResult
    {
        public string PipeName { get; set; }
        public string PipeServerInstanceId { get; set; }
        public bool RemoteClientsRejected { get; set; }
        public bool ExplicitPipeAcl { get; set; }
        public uint ClientPid { get; set; }
        public uint ClientPidRechecked { get; set; }
        public bool PipeClientPidRechecked { get; set; }
        public string ClientPidSource { get; set; }
        public long ProcessCreationTime100ns { get; set; }
        public long ProcessCreationTimeRechecked100ns { get; set; }
        public string ProcessPath { get; set; }
        public string ProcessPathRechecked { get; set; }
        public string ProcessSha256 { get; set; }
        public string ProcessSha256Semantics { get; set; }
        public bool LoadedImageHashVerified { get; set; }
        public bool ProcessActiveAfterCapture { get; set; }
        public string TokenUserSid { get; set; }
        public string[] TokenServiceSids { get; set; }
        public string TokenSource { get; set; }
        public bool ImpersonationSucceeded { get; set; }
        public string ProcessEvidenceSource { get; set; }
        public string RequestUtf8 { get; set; }
    }

    internal static class Native
    {
        internal const uint PIPE_ACCESS_DUPLEX = 0x00000003;
        internal const uint FILE_FLAG_FIRST_PIPE_INSTANCE = 0x00080000;
        internal const uint PIPE_REJECT_REMOTE_CLIENTS = 0x00000008;
        internal const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
        internal const uint STILL_ACTIVE = 259;
        internal const int ERROR_PIPE_CONNECTED = 535;
        internal const uint SDDL_REVISION_1 = 1;

        [StructLayout(LayoutKind.Sequential)]
        internal struct SECURITY_ATTRIBUTES
        {
            internal int nLength;
            internal IntPtr lpSecurityDescriptor;
            internal int bInheritHandle;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct FILETIME
        {
            internal uint dwLowDateTime;
            internal uint dwHighDateTime;
        }

        [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(
            string StringSecurityDescriptor,
            uint StringSDRevision,
            out IntPtr SecurityDescriptor,
            out uint SecurityDescriptorSize
        );

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern IntPtr CreateNamedPipe(
            string lpName,
            uint dwOpenMode,
            uint dwPipeMode,
            uint nMaxInstances,
            uint nOutBufferSize,
            uint nInBufferSize,
            uint nDefaultTimeOut,
            ref SECURITY_ATTRIBUTES lpSecurityAttributes
        );

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ConnectNamedPipe(SafeFileHandle hNamedPipe, IntPtr lpOverlapped);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool DisconnectNamedPipe(SafeFileHandle hNamedPipe);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetNamedPipeClientProcessId(SafeFileHandle Pipe, out uint ClientProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool ReadFile(
            SafeFileHandle hFile,
            [Out] byte[] lpBuffer,
            uint nNumberOfBytesToRead,
            out uint lpNumberOfBytesRead,
            IntPtr lpOverlapped
        );

        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool ImpersonateNamedPipeClient(SafeFileHandle hNamedPipe);

        [DllImport("advapi32.dll", SetLastError = true)]
        internal static extern bool RevertToSelf();

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetProcessTimes(
            SafeFileHandle hProcess,
            out FILETIME lpCreationTime,
            out FILETIME lpExitTime,
            out FILETIME lpKernelTime,
            out FILETIME lpUserTime
        );

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        internal static extern bool QueryFullProcessImageName(
            SafeFileHandle hProcess,
            uint dwFlags,
            StringBuilder lpExeName,
            ref uint lpdwSize
        );

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern bool GetExitCodeProcess(SafeFileHandle hProcess, out uint lpExitCode);

        [DllImport("kernel32.dll")]
        internal static extern IntPtr LocalFree(IntPtr hMem);
    }

    public static class R6PipeCapture
    {
        private static void Win32(bool ok, string code)
        {
            if (!ok)
                throw new Win32Exception(Marshal.GetLastWin32Error(), code);
        }

        private static long FileTimeToLong(Native.FILETIME ft)
        {
            return unchecked((long)(((ulong)ft.dwHighDateTime << 32) | (ulong)ft.dwLowDateTime));
        }

        private static string QueryPath(SafeFileHandle process)
        {
            uint size = 32768;
            var sb = new StringBuilder((int)size);
            Win32(Native.QueryFullProcessImageName(process, 0, sb, ref size), "QUERY_PROCESS_IMAGE_FAILED");
            return sb.ToString();
        }

        private static long QueryCreationTime(SafeFileHandle process)
        {
            Native.FILETIME c, e, k, u;
            Win32(Native.GetProcessTimes(process, out c, out e, out k, out u), "GET_PROCESS_TIMES_FAILED");
            return FileTimeToLong(c);
        }

        private static string Sha256File(string path)
        {
            using (var sha = SHA256.Create())
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read,
                FileShare.ReadWrite | FileShare.Delete))
            {
                byte[] digest = sha.ComputeHash(fs);
                var sb = new StringBuilder(digest.Length * 2);
                foreach (byte b in digest) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        private static bool IsSidSafe(string sid)
        {
            if (String.IsNullOrWhiteSpace(sid)) return false;
            if (!sid.StartsWith("S-", StringComparison.Ordinal)) return false;
            foreach (char ch in sid)
            {
                if (!(Char.IsDigit(ch) || ch == 'S' || ch == '-')) return false;
            }
            return true;
        }

        public static CaptureResult Capture(
            string pipeName,
            string allowedClientSid,
            string serverSid,
            int maxRequestBytes
        )
        {
            if (String.IsNullOrWhiteSpace(pipeName) || pipeName.Length > 80)
                throw new ArgumentException("INVALID_PIPE_NAME");
            foreach (char c in pipeName)
                if (!(Char.IsLetterOrDigit(c) || c == '.' || c == '_' || c == '-'))
                    throw new ArgumentException("INVALID_PIPE_NAME");

            if (!IsSidSafe(allowedClientSid) || !IsSidSafe(serverSid))
                throw new ArgumentException("INVALID_SID");
            if (maxRequestBytes < 64 || maxRequestBytes > 16384)
                throw new ArgumentException("INVALID_MAX_REQUEST_BYTES");

            // Deny network-logon clients, then allow LocalSystem, server SID, and the selected client SID.
            string sddl = "D:P(D;;GA;;;NU)(A;;GA;;;SY)(A;;GA;;;" +
                serverSid + ")(A;;GRGW;;;" + allowedClientSid + ")";

            IntPtr sd = IntPtr.Zero;
            uint sdSize = 0;
            Win32(
                Native.ConvertStringSecurityDescriptorToSecurityDescriptor(
                    sddl, Native.SDDL_REVISION_1, out sd, out sdSize),
                "SDDL_CONVERSION_FAILED"
            );

            SafeFileHandle pipe = null;
            try
            {
                var sa = new Native.SECURITY_ATTRIBUTES();
                sa.nLength = Marshal.SizeOf(typeof(Native.SECURITY_ATTRIBUTES));
                sa.lpSecurityDescriptor = sd;
                sa.bInheritHandle = 0;

                string fullName = @"\\.\pipe\" + pipeName;
                IntPtr raw = Native.CreateNamedPipe(
                    fullName,
                    Native.PIPE_ACCESS_DUPLEX | Native.FILE_FLAG_FIRST_PIPE_INSTANCE,
                    Native.PIPE_REJECT_REMOTE_CLIENTS,
                    1,
                    4096,
                    (uint)maxRequestBytes,
                    5000,
                    ref sa
                );

                if (raw == new IntPtr(-1))
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "CREATE_NAMED_PIPE_FAILED");

                pipe = new SafeFileHandle(raw, true);

                bool connected = Native.ConnectNamedPipe(pipe, IntPtr.Zero);
                if (!connected)
                {
                    int err = Marshal.GetLastWin32Error();
                    if (err != Native.ERROR_PIPE_CONNECTED)
                        throw new Win32Exception(err, "CONNECT_NAMED_PIPE_FAILED");
                }

                // Bind the pipe peer PID before request processing, then open a handle to that exact process.
                uint pid = 0;
                Win32(Native.GetNamedPipeClientProcessId(pipe, out pid), "CLIENT_PID_LOOKUP_FAILED");
                if (pid == 0) throw new InvalidOperationException("INVALID_CLIENT_PID");

                IntPtr rawProcess = Native.OpenProcess(Native.PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
                if (rawProcess == IntPtr.Zero)
                    throw new Win32Exception(Marshal.GetLastWin32Error(), "OPEN_CLIENT_PROCESS_FAILED");

                using (var process = new SafeFileHandle(rawProcess, true))
                {
                    long creation1 = QueryCreationTime(process);
                    string path1 = QueryPath(process);

                    byte[] requestBuffer = new byte[maxRequestBytes];
                    uint bytesRead = 0;
                    Win32(
                        Native.ReadFile(pipe, requestBuffer, (uint)requestBuffer.Length, out bytesRead, IntPtr.Zero),
                        "READ_PIPE_REQUEST_FAILED"
                    );
                    if (bytesRead == 0)
                        throw new InvalidOperationException("EMPTY_PIPE_REQUEST");
                    if (bytesRead >= maxRequestBytes)
                        throw new InvalidOperationException("REQUEST_TOO_LARGE_OR_TRUNCATED");

                    bool impersonated = Native.ImpersonateNamedPipeClient(pipe);
                    Win32(impersonated, "CLIENT_IMPERSONATION_FAILED");

                    string userSid;
                    var serviceSids = new List<string>();
                    try
                    {
                        using (WindowsIdentity wi = WindowsIdentity.GetCurrent(true))
                        {
                            if (wi == null || wi.User == null)
                                throw new InvalidOperationException("IMPERSONATED_IDENTITY_MISSING");
                            userSid = wi.User.Value;
                            if (!String.Equals(userSid, allowedClientSid, StringComparison.OrdinalIgnoreCase))
                                throw new UnauthorizedAccessException("IMPERSONATED_SID_MISMATCH");

                            if (wi.Groups != null)
                            {
                                foreach (IdentityReference ir in wi.Groups)
                                {
                                    SecurityIdentifier sid = ir as SecurityIdentifier;
                                    if (sid != null && sid.Value.StartsWith("S-1-5-80-", StringComparison.Ordinal))
                                        serviceSids.Add(sid.Value);
                                }
                            }
                        }
                    }
                    finally
                    {
                        if (!Native.RevertToSelf())
                            throw new Win32Exception(Marshal.GetLastWin32Error(), "REVERT_TO_SELF_FAILED");
                    }

                    // Hash the on-disk executable at the OS-reported image path. This is not a loaded-image hash.
                    string fileHash = Sha256File(path1);
                    long creation2 = QueryCreationTime(process);
                    string path2 = QueryPath(process);

                    if (creation1 != creation2)
                        throw new InvalidOperationException("PROCESS_CREATION_TIME_CHANGED");
                    if (!String.Equals(path1, path2, StringComparison.OrdinalIgnoreCase))
                        throw new InvalidOperationException("PROCESS_PATH_CHANGED");

                    uint pidRechecked = 0;
                    Win32(Native.GetNamedPipeClientProcessId(pipe, out pidRechecked), "CLIENT_PID_RECHECK_FAILED");
                    if (pidRechecked != pid)
                        throw new InvalidOperationException("PIPE_CLIENT_PID_CHANGED");

                    uint exitCode = 0;
                    Win32(Native.GetExitCodeProcess(process, out exitCode), "GET_EXIT_CODE_FAILED");
                    if (exitCode != Native.STILL_ACTIVE)
                        throw new InvalidOperationException("CLIENT_PROCESS_NOT_ACTIVE");

                    return new CaptureResult
                    {
                        PipeName = pipeName,
                        PipeServerInstanceId = Guid.NewGuid().ToString("D"),
                        RemoteClientsRejected = true,
                        ExplicitPipeAcl = true,
                        ClientPid = pid,
                        ClientPidRechecked = pidRechecked,
                        PipeClientPidRechecked = true,
                        ClientPidSource = "GetNamedPipeClientProcessId",
                        ProcessCreationTime100ns = creation1,
                        ProcessCreationTimeRechecked100ns = creation2,
                        ProcessPath = path1,
                        ProcessPathRechecked = path2,
                        ProcessSha256 = fileHash,
                        ProcessSha256Semantics = "ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH",
                        LoadedImageHashVerified = false,
                        ProcessActiveAfterCapture = true,
                        TokenUserSid = userSid,
                        TokenServiceSids = serviceSids.ToArray(),
                        TokenSource = "ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)",
                        ImpersonationSucceeded = true,
                        ProcessEvidenceSource = "PIPE_PID_BEFORE_REQUEST+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK",
                        RequestUtf8 = Encoding.UTF8.GetString(requestBuffer, 0, (int)bytesRead)
                    };
                }
            }
            finally
            {
                if (pipe != null && !pipe.IsInvalid)
                {
                    try { Native.DisconnectNamedPipe(pipe); } catch { }
                    pipe.Dispose();
                }
                if (sd != IntPtr.Zero) Native.LocalFree(sd);
            }
        }
    }
}
