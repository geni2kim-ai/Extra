from __future__ import annotations
from dataclasses import dataclass
from typing import FrozenSet

@dataclass(frozen=True)
class Selector:
    workload_id: str
    stable_node_id: str
    allowed_user_sids: FrozenSet[str]
    allowed_service_sids: FrozenSet[str]
    require_service_sid: bool
    executable_path: str
    executable_sha256: str
    status: str = "ACTIVE"

@dataclass(frozen=True)
class NodeSession:
    node_session_id: str
    stable_node_id: str
    boot_instance_id: str
    status: str = "ACTIVE"
