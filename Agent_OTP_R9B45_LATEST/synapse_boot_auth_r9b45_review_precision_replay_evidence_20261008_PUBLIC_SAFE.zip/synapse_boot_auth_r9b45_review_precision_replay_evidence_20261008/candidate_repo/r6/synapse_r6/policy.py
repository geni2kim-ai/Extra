from __future__ import annotations
import ntpath
from typing import Any
from .model import Selector, NodeSession

class Denied(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code

def norm(path: str) -> str:
    return ntpath.normpath(path.replace("/", "\\")).casefold()

def evaluate_capture(capture: dict[str, Any], selector: Selector, session: NodeSession) -> dict[str, Any]:
    if capture.get("authority_effect") != "NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if capture.get("authorization_status") != "NOT_AUTHORIZED":
        raise Denied("AUTHORIZATION_PRECLAIMED")
    if capture.get("runtime_grant_issued") is not False or capture.get("g1_token_issued") is not False or capture.get("f2_unlocked") is not False:
        raise Denied("AUTHORITY_FLAG_TRUE")

    if session.status != "ACTIVE":
        raise Denied("NODE_SESSION_NOT_ACTIVE")
    if selector.status != "ACTIVE":
        raise Denied("WORKLOAD_NOT_ACTIVE")
    if selector.stable_node_id != session.stable_node_id:
        raise Denied("SELECTOR_NODE_MISMATCH")
    if capture.get("captured_node_session_id") != session.node_session_id:
        raise Denied("NODE_SESSION_BINDING_MISMATCH")

    pipe = capture.get("pipe") or {}
    if pipe.get("remote_clients_rejected") is not True:
        raise Denied("REMOTE_PIPE_NOT_REJECTED")
    if pipe.get("explicit_acl") is not True:
        raise Denied("PIPE_ACL_NOT_EXPLICIT")

    client = capture.get("client") or {}
    if client.get("pid_source") != "GetNamedPipeClientProcessId":
        raise Denied("UNTRUSTED_PID_SOURCE")
    if not isinstance(client.get("pid"), int) or client["pid"] <= 0:
        raise Denied("INVALID_PID")
    c1 = client.get("process_creation_time_100ns")
    c2 = client.get("process_creation_time_rechecked_100ns")
    if not isinstance(c1, int) or c1 <= 0:
        raise Denied("CREATION_TIME_MISSING")
    if c1 != c2:
        raise Denied("PROCESS_CREATION_TIME_RECHECK_MISMATCH")
    if client.get("process_active_after_capture") is not True:
        raise Denied("CLIENT_PROCESS_NOT_ACTIVE")

    if capture.get("evidence_source") != "OpenProcess+GetProcessTimes+QueryFullProcessImageName":
        raise Denied("UNTRUSTED_PROCESS_EVIDENCE_SOURCE")
    if norm(client.get("process_path","")) != norm(client.get("process_path_rechecked","")):
        raise Denied("PROCESS_PATH_RECHECK_MISMATCH")
    if norm(client.get("process_path","")) != norm(selector.executable_path):
        raise Denied("EXECUTABLE_PATH_MISMATCH")
    if str(client.get("process_sha256","")).casefold() != selector.executable_sha256.casefold():
        raise Denied("EXECUTABLE_SHA256_MISMATCH")

    token = capture.get("token") or {}
    if token.get("impersonation_succeeded") is not True:
        raise Denied("IMPERSONATION_NOT_CONFIRMED")
    if token.get("token_source") != "ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)":
        raise Denied("UNTRUSTED_TOKEN_SOURCE")
    user_sid = token.get("user_sid")
    if user_sid not in selector.allowed_user_sids:
        raise Denied("USER_SID_MISMATCH")
    service_sids = frozenset(token.get("service_sids") or [])
    if selector.require_service_sid:
        if not selector.allowed_service_sids:
            raise Denied("POLICY_SERVICE_SID_EMPTY")
        if not (service_sids & selector.allowed_service_sids):
            raise Denied("SERVICE_SID_MISMATCH")

    claims = capture.get("caller_claims") or {}
    cn = claims.get("claimed_node_id")
    cw = claims.get("claimed_workload_id")
    if cn is not None and cn != session.stable_node_id:
        raise Denied("CLAIMED_NODE_MISMATCH")
    if cw is not None and cw != selector.workload_id:
        raise Denied("CLAIMED_WORKLOAD_MISMATCH")

    return {
        "result":"WORKLOAD_PROVED_OFFLINE",
        "authorization_status":"NOT_AUTHORIZED",
        "stable_node_id":session.stable_node_id,
        "node_session_id":session.node_session_id,
        "boot_instance_id":session.boot_instance_id,
        "workload_id":selector.workload_id,
        "workload_instance_id":f"{selector.workload_id}:pid={client['pid']}:ctime={c1}",
        "client_pid":client["pid"],
        "process_creation_time_100ns":c1,
        "process_sha256":client["process_sha256"].casefold(),
        "token_user_sid":user_sid,
        "runtime_grant_issued":False,
        "g1_token_issued":False,
        "f2_unlocked":False,
        "authority_effect":"NONE",
    }
