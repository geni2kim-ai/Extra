"""R6 capture policy. No authority issuance."""
