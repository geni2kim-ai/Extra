# Reference notes

Microsoft Windows documentation underlying R6:

- GetNamedPipeClientProcessId retrieves the client PID for a server-side named-pipe instance.
- CreateNamedPipe supports PIPE_REJECT_REMOTE_CLIENTS and explicit SECURITY_ATTRIBUTES.
- The default named-pipe security descriptor grants read access to Everyone and anonymous users, so R6 does not
  use default security.
- ImpersonateNamedPipeClient changes the server thread to the security context of the last client message.
  Microsoft warns that a failed impersonation must not be ignored because subsequent work would run as the server.
- QueryFullProcessImageName retrieves the executable image path from a process opened with query rights.
- GetProcessTimes provides process creation time.

The package uses those APIs only to produce evidence. Authorization remains disabled.
