from pathlib import Path

SRC=(Path(__file__).parents[1]/"windows"/"R6NamedPipeCapture.cs").read_text(encoding="utf-8")
SERVER=(Path(__file__).parents[1]/"windows"/"invoke_r6_capture_server.ps1").read_text(encoding="utf-8")

def test_required_win32_calls_present():
    for name in [
      "GetNamedPipeClientProcessId","ImpersonateNamedPipeClient","RevertToSelf",
      "OpenProcess","GetProcessTimes","QueryFullProcessImageName","GetExitCodeProcess",
      "ConvertStringSecurityDescriptorToSecurityDescriptor","CreateNamedPipe"
    ]:
        assert name in SRC

def test_remote_reject_and_first_instance_present():
    assert "PIPE_REJECT_REMOTE_CLIENTS" in SRC
    assert "FILE_FLAG_FIRST_PIPE_INSTANCE" in SRC

def test_default_security_not_used():
    assert "lpSecurityDescriptor = sd" in SRC
    assert "D:P(D;;GA;;;NU)" in SRC

def test_impersonation_return_checked():
    assert "Win32(impersonated, \"CLIENT_IMPERSONATION_FAILED\")" in SRC

def test_revert_in_finally():
    assert "finally" in SRC and "RevertToSelf" in SRC

def test_process_recheck_present():
    assert "ProcessCreationTimeRechecked100ns" in SRC
    assert "ProcessPathRechecked" in SRC

def test_server_output_forbids_authority():
    assert 'authorization_status = "NOT_AUTHORIZED"' in SERVER
    assert 'authority_effect = "NONE"' in SERVER


def test_synthetic_harness_binds_to_the_executable_it_actually_spawns():
    harness=(Path(__file__).parents[1]/"run_r6_synthetic_loopback.ps1").read_text(encoding="utf-8")
    assert "Get-Command powershell.exe" in harness
    assert "$expectedPath=$clientExe" in harness
    assert "& $clientExe -NoProfile" in harness
    assert "Get-Process -Id $PID" not in harness

def test_server_launch_uses_encoded_command_not_unquoted_file_argument():
    harness=(Path(__file__).parents[1]/"run_r6_synthetic_loopback.ps1").read_text(encoding="utf-8")
    assert "-EncodedCommand" in harness
    assert "$encodedServerCommand" in harness


def test_r62_server_completion_marker_is_capture_hash_bound():
    server=(Path(__file__).parents[1]/"windows"/"invoke_r6_capture_server.ps1").read_text(encoding="utf-8")
    assert '[string]$CompletionPath' in server
    assert 'status = "SERVER_CAPTURE_COMPLETE"' in server
    assert 'capture_sha256 = $sha' in server
    assert 'node_session_id = $NodeSessionId' in server
    assert 'authorization_status = "NOT_AUTHORIZED"' in server
    assert 'authority_effect = "NONE"' in server

def test_r62_runner_uses_unique_run_directory_and_completion_marker():
    harness=(Path(__file__).parents[1]/"run_r6_synthetic_loopback.ps1").read_text(encoding="utf-8")
    assert '("r6-run-" + $runId)' in harness
    assert 'R6_server_completion.json' in harness
    assert 'R6_SERVER_COMPLETION_HASH_MISMATCH' in harness
    assert 'SERVER_EXIT_CODE_UNAVAILABLE_COMPLETION_MARKER_VERIFIED' in harness

def test_r62_exitcode_is_supplemental_not_silently_ignored():
    harness=(Path(__file__).parents[1]/"run_r6_synthetic_loopback.ps1").read_text(encoding="utf-8")
    assert '$exitCodeAvailable' in harness
    assert '$exitCodeValue -ne 0' in harness
    assert 'completion_marker_verified=$true' in harness
    assert 'R6_SERVER_STDOUT_HASH_MISMATCH' in harness


def test_r63_server_command_is_single_line_encoded_without_here_string_continuations():
    harness=(Path(__file__).parents[1]/"run_r6_synthetic_loopback.ps1").read_text(encoding="utf-8")
    assert '$serverCommand = (' in harness
    assert 'R6_SERVER_COMMAND_NOT_SINGLE_LINE' in harness
    assert '[Text.Encoding]::Unicode.GetBytes($serverCommand)' in harness
    assert '"-EncodedCommand",$encodedServerCommand' in harness
    assert '$serverCommand = @"' not in harness
    server_command_block=harness.split('$serverCommand = (',1)[1].split('if ($serverCommand -match',1)[0]
    assert "`" not in server_command_block

def test_r63_all_server_parameters_are_embedded_in_one_command_expression():
    harness=(Path(__file__).parents[1]/"run_r6_synthetic_loopback.ps1").read_text(encoding="utf-8")
    block=harness.split('$serverCommand = (',1)[1].split('if ($serverCommand -match',1)[0]
    for param in ['-PipeName','-AllowedClientSid','-NodeSessionId','-OutputPath','-CompletionPath']:
        assert param in block
