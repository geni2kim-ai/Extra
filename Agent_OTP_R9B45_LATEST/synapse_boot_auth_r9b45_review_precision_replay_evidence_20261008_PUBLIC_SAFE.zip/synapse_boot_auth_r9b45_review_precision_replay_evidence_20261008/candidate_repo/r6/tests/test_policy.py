from __future__ import annotations
from copy import deepcopy
import pytest
from synapse_r6.model import Selector,NodeSession
from synapse_r6.policy import evaluate_capture,Denied

U="S-1-5-21-1"
def selector():
    return Selector("3X","PC3",frozenset({U}),frozenset(),False,r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe","a"*64)
def session():
    return NodeSession("ns1","PC3","boot1")
def capture():
    return {
      "authority_effect":"NONE","authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,
      "captured_node_session_id":"ns1",
      "pipe":{"remote_clients_rejected":True,"explicit_acl":True},
      "client":{
        "pid":1234,"pid_source":"GetNamedPipeClientProcessId",
        "process_creation_time_100ns":100,
        "process_creation_time_rechecked_100ns":100,
        "process_path":r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
        "process_path_rechecked":r"C:\WINDOWS\system32\WindowsPowerShell\v1.0\POWERSHELL.EXE",
        "process_sha256":"a"*64,
        "process_active_after_capture":True,
      },
      "token":{
        "user_sid":U,"service_sids":[],
        "token_source":"ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)",
        "impersonation_succeeded":True,
      },
      "evidence_source":"OpenProcess+GetProcessTimes+QueryFullProcessImageName",
      "caller_claims":{"claimed_node_id":"PC3","claimed_workload_id":"3X"},
    }

def test_happy_no_authority():
    r=evaluate_capture(capture(),selector(),session())
    assert r["result"]=="WORKLOAD_PROVED_OFFLINE"
    assert r["authorization_status"]=="NOT_AUTHORIZED"
    assert r["authority_effect"]=="NONE"

@pytest.mark.parametrize("mutate,code",[
 (lambda c:c.update(authority_effect="G1"),"AUTHORITY_EFFECT_NOT_NONE"),
 (lambda c:c["pipe"].update(remote_clients_rejected=False),"REMOTE_PIPE_NOT_REJECTED"),
 (lambda c:c["pipe"].update(explicit_acl=False),"PIPE_ACL_NOT_EXPLICIT"),
 (lambda c:c["client"].update(pid_source="request_json"),"UNTRUSTED_PID_SOURCE"),
 (lambda c:c["client"].update(process_creation_time_rechecked_100ns=101),"PROCESS_CREATION_TIME_RECHECK_MISMATCH"),
 (lambda c:c["client"].update(process_active_after_capture=False),"CLIENT_PROCESS_NOT_ACTIVE"),
 (lambda c:c["client"].update(process_path_rechecked=r"C:\evil.exe"),"PROCESS_PATH_RECHECK_MISMATCH"),
 (lambda c:c["client"].update(process_sha256="b"*64),"EXECUTABLE_SHA256_MISMATCH"),
 (lambda c:c["token"].update(impersonation_succeeded=False),"IMPERSONATION_NOT_CONFIRMED"),
 (lambda c:c["token"].update(token_source="request_json"),"UNTRUSTED_TOKEN_SOURCE"),
 (lambda c:c["token"].update(user_sid="S-1-5-21-999"),"USER_SID_MISMATCH"),
 (lambda c:c["caller_claims"].update(claimed_node_id="2G"),"CLAIMED_NODE_MISMATCH"),
 (lambda c:c["caller_claims"].update(claimed_workload_id="3G"),"CLAIMED_WORKLOAD_MISMATCH"),
 (lambda c:c.update(captured_node_session_id="other"),"NODE_SESSION_BINDING_MISMATCH"),
 (lambda c:c.update(evidence_source="request_json"),"UNTRUSTED_PROCESS_EVIDENCE_SOURCE"),
])
def test_denials(mutate,code):
    c=capture(); mutate(c)
    with pytest.raises(Denied,match=code):
        evaluate_capture(c,selector(),session())

def test_service_sid_required():
    s=Selector("3X","PC3",frozenset({U}),frozenset({"S-1-5-80-123"}),True,selector().executable_path,"a"*64)
    with pytest.raises(Denied,match="SERVICE_SID_MISMATCH"):
        evaluate_capture(capture(),s,session())
