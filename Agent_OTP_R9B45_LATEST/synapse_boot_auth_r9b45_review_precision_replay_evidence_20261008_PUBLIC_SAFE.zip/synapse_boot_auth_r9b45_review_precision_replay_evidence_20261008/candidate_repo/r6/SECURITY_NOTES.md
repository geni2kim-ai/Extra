# R6 security notes

## Why this can proceed on YM without TPM

TPM proves a node credential. Named Pipe capture proves which local Windows process is asking the broker for
something. They are separate evidence layers.

YM's measured `TPM present=false` blocks the hardware-backed R4.1 path on that sandbox, but it does not prevent
testing the workload-capture mechanism.

## Still not production-ready

R6 does not yet provide:
- a real cryptographically verified node session,
- production broker service installation,
- service SID isolation for 3G/3X/Support,
- revocation,
- runtime grant issuance,
- G1/F2 integration,
- measured boot.

The synthetic `node_session_id` is only a binding token for the test.

## Full local-admin threat

An attacker with local SYSTEM/admin control may manipulate processes, files, tokens, or the broker host. R6 is
not a proof against full host compromise. A later high-assurance design may require WDAC/AppLocker, service SID
isolation, TPM measured boot/PCR policy, or an external verifier.
