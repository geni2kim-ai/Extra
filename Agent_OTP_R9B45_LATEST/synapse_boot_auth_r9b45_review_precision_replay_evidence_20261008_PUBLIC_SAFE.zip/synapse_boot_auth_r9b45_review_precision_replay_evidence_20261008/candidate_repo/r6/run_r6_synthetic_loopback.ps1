param(
    [string]$PythonExe = "python",
    [string]$WorkingDirectory = ".",
    [int]$ServerTimeoutSeconds = 20
)

$ErrorActionPreference = "Stop"
$wd = (Resolve-Path -LiteralPath $WorkingDirectory).Path
$win = Join-Path $PSScriptRoot "windows"

$identity=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$sid=$identity.User.Value
$stableNode="R6-SYNTHETIC-NODE"
$workloadId="R6-SYNTHETIC-CLIENT"
$nodeSession="r6-synthetic-session-" + [guid]::NewGuid().ToString("N")
$bootInstance="r6-synthetic-boot-" + [guid]::NewGuid().ToString("N")
$pipeName="synapse-r6-" + [guid]::NewGuid().ToString("N")

$clientExe=(Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$expectedPath=$clientExe
$expectedHash=(Get-FileHash -LiteralPath $expectedPath -Algorithm SHA256).Hash.ToLowerInvariant()

$runId=[guid]::NewGuid().ToString("N")
$runDir=Join-Path $wd ("r6-run-" + $runId)
New-Item -ItemType Directory -Path $runDir -ErrorAction Stop | Out-Null

$capture=Join-Path $runDir "R6_capture.json"
$selector=Join-Path $runDir "R6_selector.json"
$session=Join-Path $runDir "R6_node_session.json"
$result=Join-Path $runDir "R6_policy_result.json"
$serverOut=Join-Path $runDir "R6_server_stdout.txt"
$serverErr=Join-Path $runDir "R6_server_stderr.txt"
$completion=Join-Path $runDir "R6_server_completion.json"
$runnerStatus=Join-Path $runDir "R6_runner_status.json"

[ordered]@{
    workload_id=$workloadId
    stable_node_id=$stableNode
    allowed_user_sids=@($sid)
    allowed_service_sids=@()
    require_service_sid=$false
    executable_path=$expectedPath
    executable_sha256=$expectedHash
    status="ACTIVE"
    authority_effect="NONE"
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $selector -Encoding UTF8

[ordered]@{
    node_session_id=$nodeSession
    stable_node_id=$stableNode
    boot_instance_id=$bootInstance
    status="ACTIVE"
    synthetic=$true
    authorization_status="NOT_AUTHORIZED"
    authority_effect="NONE"
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $session -Encoding UTF8

$serverScript=Join-Path $win "invoke_r6_capture_server.ps1"
$clientScript=Join-Path $win "invoke_r6_test_client.ps1"

function Escape-SingleQuotedPowerShell([string]$Value) {
    return $Value.Replace("'", "''")
}

$serverCommand = (
    "& '" + (Escape-SingleQuotedPowerShell $serverScript) + "'" +
    " -PipeName '" + (Escape-SingleQuotedPowerShell $pipeName) + "'" +
    " -AllowedClientSid '" + (Escape-SingleQuotedPowerShell $sid) + "'" +
    " -NodeSessionId '" + (Escape-SingleQuotedPowerShell $nodeSession) + "'" +
    " -OutputPath '" + (Escape-SingleQuotedPowerShell $capture) + "'" +
    " -CompletionPath '" + (Escape-SingleQuotedPowerShell $completion) + "'"
)
if ($serverCommand -match "[`r`n]") {
    throw "R6_SERVER_COMMAND_NOT_SINGLE_LINE"
}
$encodedServerCommand = [Convert]::ToBase64String(
    [Text.Encoding]::Unicode.GetBytes($serverCommand)
)

$server=Start-Process -FilePath $clientExe -ArgumentList @(
  "-NoProfile","-ExecutionPolicy","Bypass","-EncodedCommand",$encodedServerCommand
) -PassThru -RedirectStandardOutput $serverOut -RedirectStandardError $serverErr

Start-Sleep -Milliseconds 800

try {
    & $clientExe -NoProfile -ExecutionPolicy Bypass -File $clientScript `
      -PipeName $pipeName -ClaimedNodeId $stableNode -ClaimedWorkloadId $workloadId

    $sw=[Diagnostics.Stopwatch]::StartNew()
    while (-not $server.HasExited -and $sw.Elapsed.TotalSeconds -lt $ServerTimeoutSeconds) {
        Start-Sleep -Milliseconds 100
        $server.Refresh()
    }
    if (-not $server.HasExited) {
        Stop-Process -Id $server.Id -Force
        throw "R6_SERVER_TIMEOUT"
    }
    $exitCodeAvailable=$false
    $exitCodeValue=$null
    try {
        $server.Refresh()
        $candidateExitCode=$server.ExitCode
        if ($null -ne $candidateExitCode -and "$candidateExitCode" -match '^-?\d+$') {
            $exitCodeAvailable=$true
            $exitCodeValue=[int]$candidateExitCode
        }
    } catch {
        $exitCodeAvailable=$false
    }

    if ($exitCodeAvailable -and $exitCodeValue -ne 0) {
        throw ("R6_SERVER_FAILED exit=" + $exitCodeValue + " stderr=" + (Get-Content $serverErr -Raw))
    }

    if (-not (Test-Path -LiteralPath $capture)) { throw "R6_CAPTURE_NOT_WRITTEN" }
    if (-not (Test-Path -LiteralPath $completion)) { throw "R6_SERVER_COMPLETION_NOT_WRITTEN" }

    $marker=Get-Content -LiteralPath $completion -Raw | ConvertFrom-Json
    if ($marker.status -ne "SERVER_CAPTURE_COMPLETE") { throw "R6_SERVER_COMPLETION_STATUS_INVALID" }
    if ($marker.pipe_name -ne $pipeName) { throw "R6_SERVER_COMPLETION_PIPE_MISMATCH" }
    if ($marker.node_session_id -ne $nodeSession) { throw "R6_SERVER_COMPLETION_SESSION_MISMATCH" }
    if ($marker.authorization_status -ne "NOT_AUTHORIZED" -or $marker.authority_effect -ne "NONE") {
        throw "R6_SERVER_COMPLETION_AUTHORITY_INVALID"
    }

    $actualCaptureHash=(Get-FileHash -LiteralPath $capture -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($marker.capture_sha256 -ne $actualCaptureHash) { throw "R6_SERVER_COMPLETION_HASH_MISMATCH" }

    $serverStdout=Get-Content -LiteralPath $serverOut -Raw
    $stdoutHashMatch=[regex]::Match($serverStdout,'(?mi)^SHA256\s+([0-9a-f]{64})\s*$')
    if (-not $stdoutHashMatch.Success) { throw "R6_SERVER_STDOUT_HASH_MISSING" }
    if ($stdoutHashMatch.Groups[1].Value.ToLowerInvariant() -ne $actualCaptureHash) {
        throw "R6_SERVER_STDOUT_HASH_MISMATCH"
    }
    if ($serverStdout -notmatch '(?m)^AUTHORITY_EFFECT=NONE\s*$') {
        throw "R6_SERVER_STDOUT_AUTHORITY_INVARIANT_MISSING"
    }

    [ordered]@{
        schema_version="SYNAPSE-R6-RUNNER-STATUS-1"
        run_id=$runId
        server_process_has_exited=[bool]$server.HasExited
        server_exit_code_available=[bool]$exitCodeAvailable
        server_exit_code=$exitCodeValue
        completion_marker_verified=$true
        capture_sha256=$actualCaptureHash
        authorization_status="NOT_AUTHORIZED"
        authority_effect="NONE"
    } | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $runnerStatus -Encoding UTF8

    & $PythonExe (Join-Path $PSScriptRoot "evaluate_r6_capture.py") `
      $capture $selector $session -o $result
    if ($LASTEXITCODE -ne 0) { throw "R6_POLICY_DENIED" }

    $r=Get-Content -LiteralPath $result -Raw | ConvertFrom-Json
    if ($r.result -ne "WORKLOAD_PROVED_OFFLINE") { throw "R6_UNEXPECTED_RESULT" }
    if ($r.authorization_status -ne "NOT_AUTHORIZED" -or $r.authority_effect -ne "NONE") {
        throw "R6_AUTHORITY_INVARIANT_FAILED"
    }

    Write-Host "R6_SYNTHETIC_LOOPBACK_PASS"
    Write-Host ("RUN_DIR " + $runDir)
    Write-Host ("CAPTURE " + $capture)
    Write-Host ("RESULT " + $result)
    if (-not $exitCodeAvailable) {
        Write-Host "SERVER_EXIT_CODE_UNAVAILABLE_COMPLETION_MARKER_VERIFIED"
    }
    Write-Host "AUTHORITY_EFFECT=NONE"
} finally {
    if ($server -and -not $server.HasExited) {
        Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
    }
}
