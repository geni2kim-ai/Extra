# R6 — Windows one-shot Named Pipe workload capture

**Status:** candidate / offline authority
**TPM dependency:** none for this adapter rehearsal
**Runtime authority:** none

R6 captures the client process identity from the Windows Named Pipe connection itself.

## Security properties

- `CreateNamedPipe` with an explicit security descriptor
- `PIPE_REJECT_REMOTE_CLIENTS`
- `FILE_FLAG_FIRST_PIPE_INSTANCE`
- DACL denies `NT AUTHORITY\NETWORK`
- explicit allow for selected client SID
- `GetNamedPipeClientProcessId` supplies PID
- process handle uses query-limited access
- process creation time and executable path are read twice around SHA-256 hashing
- client process must remain active
- `ImpersonateNamedPipeClient` must succeed
- impersonated user SID must equal allowed client SID
- service SIDs (`S-1-5-80-*`) are captured when present
- caller claims are preserved only as consistency claims
- output is `NOT_AUTHORIZED`, `authority_effect=NONE`

## Synthetic loopback

On a Windows sandbox:

```powershell
powershell -ExecutionPolicy Bypass -File .\run_r6_synthetic_loopback.ps1 `
  -WorkingDirectory .\r6_evidence
```

The harness:
1. records the expected PowerShell executable path/hash independently,
2. starts a separate one-shot server process,
3. starts a separate client PowerShell process,
4. captures the client's PID/SID/path/hash from the pipe/OS,
5. evaluates the capture against a synthetic selector/session,
6. requires `WORKLOAD_PROVED_OFFLINE` and `NOT_AUTHORIZED`.

A synthetic loopback PASS does **not** identify 3G/3X/Support. It proves only the capture adapter boundary.


## R6.1 portability hardening

The synthetic harness now resolves the exact `powershell.exe` that will be spawned and binds the selector to
that executable's path/SHA-256. It no longer assumes the harness host process is the same executable as the
client. The server launch uses a Base64 `-EncodedCommand` to avoid path/argument splitting when the package is
located under a directory containing spaces.

## R6.2 YM closeout hardening

YM demonstrated a Windows host condition where a `Start-Process -PassThru` process object could report
`HasExited=True` while its `ExitCode` was unavailable. R6.2 does not simply ignore that condition.

The server now emits a completion marker **after** the capture has been written and SHA-256 hashed. The runner
requires:
- a fresh unique run directory,
- the completion marker,
- matching pipe name and node-session id,
- matching capture SHA-256,
- `NOT_AUTHORIZED / NONE`,
- stdout SHA-256 matching the same capture,
- the normal offline policy evaluator PASS.

If a numeric exit code is available, non-zero still fails. If the host does not expose an exit code, the
completion-marker/evidence chain is recorded in `R6_runner_status.json`.

## R6.3 launch-plumbing correction

YM proved that the R6.2 multi-line here-string used for `-EncodedCommand` was not portable: continuation
backticks did not survive as intended and the server script received no mandatory parameters.

R6.3 keeps `-EncodedCommand` for path/quoting robustness but generates the invocation as one logical line with
no continuation backticks or embedded newlines. The runner fails locally if the generated command contains CR/LF.
