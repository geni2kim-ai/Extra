#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path

def key(w: dict) -> tuple:
    return (
      tuple(sorted(w.get("allowed_user_sids",[]))),
      tuple(sorted(w.get("allowed_service_sids",[]))),
      bool(w.get("require_service_sid",False)),
      str(w.get("executable_path","")).replace("/","\\").casefold(),
      str(w.get("executable_sha256","")).casefold(),
    )

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("registry")
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    doc=json.loads(Path(ns.registry).read_text(encoding="utf-8-sig"))
    groups={}
    for w in doc.get("workloads",[]):
        groups.setdefault(key(w),[]).append(w.get("workload_id"))
    collisions=[ids for ids in groups.values() if len(ids)>1]
    result={
      "schema_version":"SYNAPSE-R6-SEPARATION-ASSESSMENT-1",
      "status":"PC3_WORKLOAD_SEPARATION_INSUFFICIENT" if collisions else "WORKLOAD_SELECTORS_DISTINGUISHABLE",
      "collisions":collisions,
      "authorization_status":"NOT_AUTHORIZED",
      "authority_effect":"NONE",
    }
    Path(ns.output).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
    return 2 if collisions else 0
if __name__=="__main__": raise SystemExit(main())
