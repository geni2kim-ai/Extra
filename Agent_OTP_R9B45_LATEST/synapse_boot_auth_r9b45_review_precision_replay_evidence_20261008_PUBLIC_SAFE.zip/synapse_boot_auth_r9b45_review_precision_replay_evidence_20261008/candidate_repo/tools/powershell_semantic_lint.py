#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,re
from pathlib import Path

# Narrow set of automatic/read-only or special variables that are unsafe as
# ordinary function parameter names in this project's PowerShell sources.
AUTOMATIC = {
    "pid","home","host","error","input","matches","myinvocation",
    "psboundparameters","psscriptroot","pscommandpath","args","this",
    "lastexitcode","executioncontext","shellid","stacktrace"
}

FUNC_RE=re.compile(r"(?is)\bfunction\s+([A-Za-z_][\w-]*)\s*\((.*?)\)")
PARAM_RE=re.compile(r"(?is)(?:\[[^\]]+\]\s*)?\$([A-Za-z_][A-Za-z0-9_]*)")
ASSIGN_RE=re.compile(r"(?im)^\s*\$([A-Za-z_][A-Za-z0-9_]*)\s*=")

def scan_file(path:Path)->list[dict]:
    text=path.read_text(encoding="utf-8-sig")
    findings=[]
    for fm in FUNC_RE.finditer(text):
        fname=fm.group(1)
        params=fm.group(2)
        for pm in PARAM_RE.finditer(params):
            name=pm.group(1)
            if name.casefold() in AUTOMATIC:
                findings.append({
                  "code":"POWERSHELL_AUTOMATIC_VARIABLE_COLLISION",
                  "location":"function_parameter",
                  "function":fname,
                  "variable":name,
                  "file":path.as_posix()
                })
    for am in ASSIGN_RE.finditer(text):
        name=am.group(1)
        if name.casefold() in AUTOMATIC:
            line=text.count("\n",0,am.start())+1
            findings.append({
              "code":"POWERSHELL_AUTOMATIC_VARIABLE_COLLISION",
              "location":"assignment",
              "line":line,
              "variable":name,
              "file":path.as_posix()
            })
    return findings

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("paths",nargs="+")
    ap.add_argument("-o","--output")
    ns=ap.parse_args()
    findings=[]
    for raw in ns.paths:
        p=Path(raw)
        if p.is_dir():
            for f in p.rglob("*.ps1"):
                findings.extend(scan_file(f))
        else:
            findings.extend(scan_file(p))
    result={
      "schema_version":"SYNAPSE-POWERSHELL-SEMANTIC-LINT-1",
      "findings":findings,
      "status":"PASS" if not findings else "FAIL",
      "authority_effect":"NONE"
    }
    txt=json.dumps(result,indent=2,ensure_ascii=False)+"\n"
    if ns.output: Path(ns.output).write_text(txt,encoding="utf-8")
    print(txt,end="")
    return 0 if not findings else 2

if __name__=="__main__":
    raise SystemExit(main())
