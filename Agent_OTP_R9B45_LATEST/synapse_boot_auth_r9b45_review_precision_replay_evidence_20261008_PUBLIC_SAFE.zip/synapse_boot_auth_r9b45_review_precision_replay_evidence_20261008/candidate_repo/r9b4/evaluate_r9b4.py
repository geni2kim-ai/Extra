#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os,sys
from datetime import datetime,timezone
from pathlib import Path
from r9b4.common import Denied,load_json_bytes,sha_bytes
from r9b4.evaluator import evaluate
from r9b4.replay import consume

HERE=Path(__file__).resolve().parent

def load(path:Path,label:str):
    b,d=load_json_bytes(path,label);return b,d,sha_bytes(b)
def fsha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()
def write_result(out:Path,result:dict)->None:
    out.parent.mkdir(parents=True,exist_ok=True)
    tmp=out.with_name(out.name+".tmp")
    tmp.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
    os.replace(tmp,out)
def canonical_sha(obj:object)->str:
    return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8")).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("capture")
    for x in ("build-receipt","registry","preflight","run-context","harness-summary","server-completion","cleanup-receipt",
              "mediator-exe","verifier-exe","verifier-source"):ap.add_argument("--"+x,required=True)
    for x in ("registry","mediator","verifier-binary","verifier-source","build-receipt"):
        ap.add_argument("--expected-"+x+"-sha256",required=True)
    ap.add_argument("--replay-ledger-dir")
    ap.add_argument("--offline-artifact-check",action="store_true")
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();out=Path(ns.output)

    started=datetime.now(timezone.utc)
    audit={
      "evaluation_started_at_utc":started.isoformat(),
      "evaluator_cli_sha256":fsha(Path(__file__).resolve()),
      "evaluator_core_sha256":fsha(HERE/"r9b4/evaluator.py"),
      "replay_impl_sha256":fsha(HERE/"r9b4/replay.py"),
      "run_id":None,
      "measurement_nonce":None,
      "input_set_sha256":None,
      "input_bindings":None,
      "authority_effect":"NONE",
    }
    try:
        if out.exists():out.unlink()
    except Exception:pass
    try:
        _,c,csha=load(Path(ns.capture),"CAPTURE")
        _,b,bsha=load(Path(ns.build_receipt),"BUILD")
        _,r,rsha=load(Path(ns.registry),"REGISTRY")
        _,p,psha=load(Path(ns.preflight),"PREFLIGHT")
        _,x,xsha=load(Path(ns.run_context),"RUN_CONTEXT")
        _,h,hsha=load(Path(ns.harness_summary),"HARNESS")
        _,d,dsha=load(Path(ns.server_completion),"COMPLETION")
        _,k,ksha=load(Path(ns.cleanup_receipt),"CLEANUP")
        hashes={
          "capture_sha256":csha,"build_receipt_sha256":bsha,"registry_sha256":rsha,"preflight_sha256":psha,
          "run_context_sha256":xsha,"harness_sha256":hsha,"completion_sha256":dsha,"cleanup_sha256":ksha,
          "mediator_sha256":fsha(Path(ns.mediator_exe)),"verifier_binary_sha256":fsha(Path(ns.verifier_exe)),
          "verifier_source_sha256":fsha(Path(ns.verifier_source)),
          "expected_registry_sha256":ns.expected_registry_sha256,"expected_mediator_sha256":ns.expected_mediator_sha256,
          "expected_verifier_binary_sha256":ns.expected_verifier_binary_sha256,
          "expected_verifier_source_sha256":ns.expected_verifier_source_sha256,
          "expected_build_receipt_sha256":ns.expected_build_receipt_sha256,
        }
        audit["run_id"]=x.get("run_id")
        audit["measurement_nonce"]=x.get("measurement_nonce")
        bindings={
          "evidence":{kk:vv for kk,vv in hashes.items() if not kk.startswith("expected_")},
          "expected_pins":{kk:vv for kk,vv in hashes.items() if kk.startswith("expected_")},
          "run_id":audit["run_id"],"measurement_nonce":audit["measurement_nonce"]
        }
        audit["input_bindings"]=bindings
        audit["input_set_sha256"]=canonical_sha(bindings)

        now=datetime.now(timezone.utc)
        result=evaluate(c,b,r,p,x,h,d,k,hashes,now,not ns.offline_artifact_check)
        result["evidence_bindings"]=bindings["evidence"]
        if ns.offline_artifact_check:
            result["evaluation_mode"]="OFFLINE_ARTIFACT_CHECK_NON_CONSUMING"
            result["replay_semantics"]="NOT_CONSUMED_OFFLINE_MODE"
        else:
            if not ns.replay_ledger_dir:raise Denied("REPLAY_LEDGER_REQUIRED")
            receipt=consume(str(x.get("run_id","")),str(x.get("measurement_nonce","")),Path(ns.replay_ledger_dir))
            result["result"]="R9B4_ONE_TIME_EVALUATION_MEASUREMENT_READY"
            result["evaluation_mode"]="LIVE_FRESHNESS_AND_ONE_TIME_CONSUMPTION"
            result["replay_semantics"]="LOCAL_ONE_TIME_EVALUATION_LEDGER_REHEARSAL"
            result["replay_consumption"]=receipt
        code=0
    except Denied as e:
        result={"result":"R9B4_DENIED","code":e.code,"authorization_status":"NOT_AUTHORIZED",
                "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"};code=2
    except Exception:
        result={"result":"R9B4_DENIED","code":"MALFORMED_OR_UNEXPECTED_INPUT","authorization_status":"NOT_AUTHORIZED",
                "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"};code=2

    audit["evaluation_completed_at_utc"]=datetime.now(timezone.utc).isoformat()
    result["execution_binding"]=audit
    try:write_result(out,result)
    except Exception:
        print(json.dumps({"result":"R9B4_DENIED","code":"OUTPUT_WRITE_FAILED","authority_effect":"NONE"}),file=sys.stderr)
        return 2
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return code

if __name__=="__main__":raise SystemExit(main())
