using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace SynapseR9B4
{
    internal sealed class LimitExceededException : Exception
    {
        internal readonly string Code;
        internal LimitExceededException(string code) : base(code) { Code = code; }
    }

    internal static class NativeMethods
    {
        internal const uint TH32CS_SNAPPROCESS = 0x00000002;
        internal static readonly IntPtr INVALID_HANDLE_VALUE = new IntPtr(-1);

        [StructLayout(LayoutKind.Sequential)]
        internal struct FILETIME
        {
            internal uint dwLowDateTime;
            internal uint dwHighDateTime;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
        internal struct PROCESSENTRY32
        {
            internal uint dwSize;
            internal uint cntUsage;
            internal uint th32ProcessID;
            internal IntPtr th32DefaultHeapID;
            internal uint th32ModuleID;
            internal uint cntThreads;
            internal uint th32ParentProcessID;
            internal int pcPriClassBase;
            internal uint dwFlags;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
            internal string szExeFile;
        }

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern uint GetProcessId(IntPtr Process);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool GetProcessTimes(
            IntPtr hProcess,
            out FILETIME lpCreationTime,
            out FILETIME lpExitTime,
            out FILETIME lpKernelTime,
            out FILETIME lpUserTime);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool QueryFullProcessImageName(
            IntPtr hProcess,
            int dwFlags,
            StringBuilder lpExeName,
            ref int lpdwSize);

        [DllImport("kernel32.dll", SetLastError = true)]
        internal static extern IntPtr CreateToolhelp32Snapshot(uint dwFlags, uint th32ProcessID);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool Process32First(IntPtr hSnapshot, ref PROCESSENTRY32 lppe);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Auto)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool Process32Next(IntPtr hSnapshot, ref PROCESSENTRY32 lppe);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        internal static extern bool CloseHandle(IntPtr hObject);
    }

    internal sealed class NativeObservation
    {
        internal uint HandlePid;
        internal long CreationTime;
        internal string ImagePath;
        internal int ParentPid;
        internal int ParentAttempts;
        internal long ParentElapsedMs;
    }

    internal static class DedicatedMediator
    {
        private const int ExitStdoutLimit = 20;
        private const int ExitStderrLimit = 21;
        private const int ExitTimeout = 22;
        private const int ExitGeneric = 23;
        private const string HelperName = "R9B4_SyntheticChild.exe";
        private const int ParentObservationTimeoutMs = 500;

        private static string Sha256File(string path)
        {
            using (var sha = SHA256.Create())
            using (var s = File.OpenRead(path))
                return Hex(sha.ComputeHash(s));
        }

        private static string Sha256Bytes(byte[] data)
        {
            using (var sha = SHA256.Create())
                return Hex(sha.ComputeHash(data));
        }

        private static string Hex(byte[] data)
        {
            var sb = new StringBuilder(data.Length * 2);
            foreach (byte b in data) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }

        private static async Task<byte[]> ReadBoundedAsync(Stream stream, int maxBytes, string code)
        {
            var buffer = new byte[1024];
            using (var ms = new MemoryStream())
            {
                while (true)
                {
                    int n = await stream.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
                    if (n == 0) break;
                    if (ms.Length + n > maxBytes) throw new LimitExceededException(code);
                    ms.Write(buffer, 0, n);
                }
                return ms.ToArray();
            }
        }

        private static long FileTimeToLong(NativeMethods.FILETIME ft)
        {
            return ((long)ft.dwHighDateTime << 32) | (long)ft.dwLowDateTime;
        }

        private static long CreationTimeFromHandle(IntPtr handle)
        {
            NativeMethods.FILETIME creation, exit, kernel, user;
            if (!NativeMethods.GetProcessTimes(handle, out creation, out exit, out kernel, out user))
                throw new InvalidOperationException("R9B4_CHILD_GET_PROCESS_TIMES_FAILED");
            long value = FileTimeToLong(creation);
            if (value <= 0) throw new InvalidOperationException("R9B4_CHILD_CREATION_TIME_INVALID");
            return value;
        }

        private static string ImagePathFromHandle(IntPtr handle)
        {
            int size = 32768;
            var sb = new StringBuilder(size);
            if (!NativeMethods.QueryFullProcessImageName(handle, 0, sb, ref size))
                throw new InvalidOperationException("R9B4_CHILD_QUERY_IMAGE_PATH_FAILED");
            string path = sb.ToString();
            if (String.IsNullOrWhiteSpace(path))
                throw new InvalidOperationException("R9B4_CHILD_IMAGE_PATH_EMPTY");
            return path;
        }

        private static int ParentPidFromToolhelp(uint childPid, IntPtr processHandle, long anchorCreation, out int attempts, out long elapsedMs)
        {
            var sw = Stopwatch.StartNew();
            attempts = 0;

            while (sw.ElapsedMilliseconds < ParentObservationTimeoutMs)
            {
                attempts++;

                uint handlePid = NativeMethods.GetProcessId(processHandle);
                if (handlePid != childPid)
                    throw new InvalidOperationException("R9B4_CHILD_HANDLE_PID_CHANGED");
                if (CreationTimeFromHandle(processHandle) != anchorCreation)
                    throw new InvalidOperationException("R9B4_CHILD_INSTANCE_CHANGED_DURING_PARENT_OBSERVATION");

                IntPtr snapshot = NativeMethods.CreateToolhelp32Snapshot(NativeMethods.TH32CS_SNAPPROCESS, 0);
                if (snapshot != NativeMethods.INVALID_HANDLE_VALUE)
                {
                    try
                    {
                        var entry = new NativeMethods.PROCESSENTRY32();
                        entry.dwSize = (uint)Marshal.SizeOf(typeof(NativeMethods.PROCESSENTRY32));
                        bool ok = NativeMethods.Process32First(snapshot, ref entry);
                        while (ok)
                        {
                            if (entry.th32ProcessID == childPid)
                            {
                                elapsedMs = sw.ElapsedMilliseconds;
                                return (int)entry.th32ParentProcessID;
                            }
                            ok = NativeMethods.Process32Next(snapshot, ref entry);
                        }
                    }
                    finally
                    {
                        NativeMethods.CloseHandle(snapshot);
                    }
                }

                Thread.Sleep(10);
            }

            elapsedMs = sw.ElapsedMilliseconds;
            throw new InvalidOperationException("R9B4_CHILD_PARENT_SNAPSHOT_TIMEOUT");
        }

        private static NativeObservation ObserveNative(Process child, int expectedParentPid, string expectedPath)
        {
            IntPtr handle = child.Handle;
            uint handlePid = NativeMethods.GetProcessId(handle);
            if (handlePid == 0 || handlePid != (uint)child.Id)
                throw new InvalidOperationException("R9B4_CHILD_HANDLE_PID_MISMATCH");

            long creation1 = CreationTimeFromHandle(handle);
            string imagePath = ImagePathFromHandle(handle);
            if (!String.Equals(imagePath, expectedPath, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("R9B4_CHILD_PATH_MISMATCH");

            int attempts;
            long elapsed;
            int parentPid = ParentPidFromToolhelp(handlePid, handle, creation1, out attempts, out elapsed);
            if (parentPid != expectedParentPid)
                throw new InvalidOperationException("R9B4_CHILD_PARENT_PID_MISMATCH");

            uint handlePid2 = NativeMethods.GetProcessId(handle);
            long creation2 = CreationTimeFromHandle(handle);
            string imagePath2 = ImagePathFromHandle(handle);

            if (handlePid2 != handlePid)
                throw new InvalidOperationException("R9B4_CHILD_HANDLE_PID_RECHECK_FAILED");
            if (creation2 != creation1)
                throw new InvalidOperationException("R9B4_CHILD_INSTANCE_RECHECK_FAILED");
            if (!String.Equals(imagePath2, imagePath, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("R9B4_CHILD_PATH_RECHECK_FAILED");

            return new NativeObservation {
                HandlePid = handlePid,
                CreationTime = creation1,
                ImagePath = imagePath,
                ParentPid = parentPid,
                ParentAttempts = attempts,
                ParentElapsedMs = elapsed
            };
        }

        private static void KillQuiet(Process p)
        {
            try { if (!p.HasExited) p.Kill(); } catch { }
            try { p.WaitForExit(2000); } catch { }
        }

        private static int Main(string[] args)
        {
            try { return MainCore(args); }
            catch (Exception ex)
            {
                Console.Error.WriteLine("R9B4_GENERIC_FAILURE " + ex.GetType().Name + " " + ex.Message);
                return ExitGeneric;
            }
        }

        private static int MeasurePipe(string pipeName, string measurementNonce)
        {
            if (String.IsNullOrWhiteSpace(pipeName) || pipeName.Length > 80)
                throw new ArgumentException("R9B4_PIPE_NAME_INVALID");
            foreach (char c in pipeName)
                if (!(Char.IsLetterOrDigit(c) || c == '.' || c == '_' || c == '-'))
                    throw new ArgumentException("R9B4_PIPE_NAME_INVALID");
            if (String.IsNullOrWhiteSpace(measurementNonce) || measurementNonce.Length != 32)
                throw new ArgumentException("R9B4_MEASUREMENT_NONCE_INVALID");
            foreach (char c in measurementNonce)
                if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f')))
                    throw new ArgumentException("R9B4_MEASUREMENT_NONCE_INVALID");

            using (var pipe = new NamedPipeClientStream(
                ".",
                pipeName,
                PipeDirection.InOut,
                PipeOptions.None,
                TokenImpersonationLevel.Impersonation))
            {
                pipe.Connect(5000);
                string body = "{\"measurement_nonce\":\"" + measurementNonce + "\"}";
                byte[] request = Encoding.UTF8.GetBytes(body);
                int len = request.Length;
                byte[] header = new byte[] {
                    (byte)((len >> 24) & 0xff),
                    (byte)((len >> 16) & 0xff),
                    (byte)((len >> 8) & 0xff),
                    (byte)(len & 0xff)
                };
                pipe.Write(header, 0, header.Length);
                pipe.Write(request, 0, request.Length);
                pipe.Flush();

                byte[] one = new byte[1];
                while (true)
                {
                    int n = pipe.Read(one, 0, 1);
                    if (n == 0) break;
                }
            }

            Console.WriteLine("R9B4_PIPE_MEASUREMENT_CLIENT_COMPLETE");
            Console.WriteLine("AUTHORITY_EFFECT=NONE");
            return 0;
        }

        private static int MainCore(string[] args)
        {
            if (args.Length == 3 && args[0] == "--measure-pipe")
                return MeasurePipe(args[1], args[2]);

            string output = null;
            string mode = "normal";
            int stdoutLimit = 4096;
            int stderrLimit = 4096;
            int timeoutMs = 5000;

            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--output" && i + 1 < args.Length) output = args[++i];
                else if (args[i] == "--mode" && i + 1 < args.Length) mode = args[++i];
                else if (args[i] == "--stdout-limit" && i + 1 < args.Length) stdoutLimit = Int32.Parse(args[++i]);
                else if (args[i] == "--stderr-limit" && i + 1 < args.Length) stderrLimit = Int32.Parse(args[++i]);
                else if (args[i] == "--timeout-ms" && i + 1 < args.Length) timeoutMs = Int32.Parse(args[++i]);
                else throw new ArgumentException("R9B4_ARGUMENT_INVALID");
            }

            if (String.IsNullOrWhiteSpace(output)) throw new ArgumentException("R9B4_OUTPUT_REQUIRED");
            if (stdoutLimit < 1 || stdoutLimit > 65536) throw new ArgumentException("R9B4_STDOUT_LIMIT_INVALID");
            if (stderrLimit < 1 || stderrLimit > 16384) throw new ArgumentException("R9B4_STDERR_LIMIT_INVALID");
            if (timeoutMs < 1 || timeoutMs > 30000) throw new ArgumentException("R9B4_TIMEOUT_INVALID");
            if (mode != "normal" && mode != "stdout-overflow" && mode != "stderr-overflow" && mode != "timeout")
                throw new ArgumentException("R9B4_MODE_INVALID");

            var self = Process.GetCurrentProcess();
            int mediatorPid = self.Id;
            string mediatorExe = self.MainModule.FileName;
            string mediatorSha = Sha256File(mediatorExe);
            string mediatorDir = Path.GetDirectoryName(mediatorExe);
            string helperExe = Path.Combine(mediatorDir, HelperName);
            if (!File.Exists(helperExe))
                throw new FileNotFoundException("R9B4_HELPER_EXE_NOT_FOUND");

            string helperExpectedSha = Sha256File(helperExe);
            string mediatorSession = "r9a3-mediator-" + Guid.NewGuid().ToString("N");

            var psi = new ProcessStartInfo();
            psi.FileName = helperExe;
            psi.Arguments = mode;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;

            using (var child = new Process())
            {
                child.StartInfo = psi;
                if (!child.Start())
                    throw new InvalidOperationException("R9B4_CHILD_START_FAILED");

                Task<byte[]> stdoutTask = ReadBoundedAsync(
                    child.StandardOutput.BaseStream, stdoutLimit, "R9B4_CHILD_STDOUT_LIMIT_EXCEEDED");
                Task<byte[]> stderrTask = ReadBoundedAsync(
                    child.StandardError.BaseStream, stderrLimit, "R9B4_CHILD_STDERR_LIMIT_EXCEEDED");

                NativeObservation obs;
                try
                {
                    obs = ObserveNative(child, mediatorPid, helperExe);
                }
                catch
                {
                    KillQuiet(child);
                    throw;
                }

                string observedSha = Sha256File(obs.ImagePath);
                if (observedSha != helperExpectedSha)
                {
                    KillQuiet(child);
                    throw new InvalidOperationException("R9B4_CHILD_SHA_MISMATCH");
                }

                var execWatch = Stopwatch.StartNew();
                while (!child.HasExited && !stdoutTask.IsFaulted && !stderrTask.IsFaulted &&
                       execWatch.ElapsedMilliseconds < timeoutMs)
                    Thread.Sleep(10);

                bool timedOut = !child.HasExited && execWatch.ElapsedMilliseconds >= timeoutMs;
                if (timedOut || stdoutTask.IsFaulted || stderrTask.IsFaulted)
                    KillQuiet(child);
                if (!child.HasExited)
                    child.WaitForExit();

                try { Task.WaitAll(new Task[] { stdoutTask, stderrTask }, 2000); }
                catch (AggregateException) { }

                if (stdoutTask.IsFaulted)
                {
                    var ex = stdoutTask.Exception.Flatten().InnerException as LimitExceededException;
                    if (ex != null && ex.Code == "R9B4_CHILD_STDOUT_LIMIT_EXCEEDED")
                    {
                        Console.Error.WriteLine(ex.Code);
                        return ExitStdoutLimit;
                    }
                    throw stdoutTask.Exception.Flatten().InnerException;
                }

                if (stderrTask.IsFaulted)
                {
                    var ex = stderrTask.Exception.Flatten().InnerException as LimitExceededException;
                    if (ex != null && ex.Code == "R9B4_CHILD_STDERR_LIMIT_EXCEEDED")
                    {
                        Console.Error.WriteLine(ex.Code);
                        return ExitStderrLimit;
                    }
                    throw stderrTask.Exception.Flatten().InnerException;
                }

                if (timedOut)
                {
                    Console.Error.WriteLine("R9B4_CHILD_EXECUTION_TIMEOUT");
                    return ExitTimeout;
                }

                byte[] stdoutBytes = stdoutTask.Result;
                byte[] stderrBytes = stderrTask.Result;

                if (mode != "normal")
                    throw new InvalidOperationException("R9B4_NEGATIVE_MODE_DID_NOT_TRIGGER");

                string expectedPayload =
                    "{\"meta\":{\"node_id\":\"UNTRUSTED_CHILD_CLAIM\",\"token\":\"UNTRUSTED_CHILD_TOKEN\"},\"data\":\"hello\"}";
                string expectedPayloadSha = Sha256Bytes(Encoding.UTF8.GetBytes(expectedPayload));
                string observedPayloadSha = Sha256Bytes(stdoutBytes);
                if (observedPayloadSha != expectedPayloadSha)
                    throw new InvalidOperationException("R9B4_PAYLOAD_HASH_MISMATCH");
                if (stderrBytes.Length != 0)
                    throw new InvalidOperationException("R9B4_CHILD_STDERR_NONEMPTY");
                if (child.ExitCode != 0)
                    throw new InvalidOperationException("R9B4_CHILD_EXIT_NONZERO");

                var receipt = new Dictionary<string, object>();
                receipt["schema_version"] = "SYNAPSE-R9B3-NATIVE-PIPE-MEDIATOR-CANDIDATE-1";
                receipt["collected_at_utc"] = DateTime.UtcNow.ToString("o");

                receipt["mediator"] = new Dictionary<string, object> {
                    {"session_id", mediatorSession},
                    {"pid", mediatorPid},
                    {"executable_name", Path.GetFileName(mediatorExe)},
                    {"executable_sha256", mediatorSha},
                    {"workload_identity_mode", "DEDICATED_EXECUTABLE_CANDIDATE"},
                    {"authentication_result", "NOT_PERFORMED"},
                    {"status", "CANDIDATE"}
                };

                receipt["child_instance"] = new Dictionary<string, object> {
                    {"pid", child.Id},
                    {"pid_source", "System.Diagnostics.Process.Start"},
                    {"handle_pid", (long)obs.HandlePid},
                    {"handle_pid_matches_start_pid", obs.HandlePid == (uint)child.Id},
                    {"creation_time_filetime_100ns", obs.CreationTime},
                    {"creation_time_rechecked_filetime_100ns", CreationTimeFromHandle(child.Handle)},
                    {"creation_time_source", "GET_PROCESS_TIMES"},
                    {"executable_name", Path.GetFileName(obs.ImagePath)},
                    {"executable_sha256", observedSha},
                    {"path_source", "QUERY_FULL_PROCESS_IMAGE_NAME"},
                    {"parent_pid", obs.ParentPid},
                    {"parent_pid_source", "TOOLHELP32_SNAPSHOT"},
                    {"parent_binding_verified", obs.ParentPid == mediatorPid},
                    {"parent_observation_attempts", obs.ParentAttempts},
                    {"parent_observation_elapsed_ms", obs.ParentElapsedMs},
                    {"same_directory_binding_verified", true},
                    {"identity", "NOT_PROVED"}
                };

                receipt["child_message"] = new Dictionary<string, object> {
                    {"sequence", 0},
                    {"generated_by", "DEDICATED_MEDIATOR_CANDIDATE"},
                    {"payload_handling", "OPAQUE_BYTES_NOT_PARSED"},
                    {"payload_sha256", observedPayloadSha},
                    {"payload_length", stdoutBytes.Length},
                    {"trust", "UNTRUSTED_CHILD_INPUT"},
                    {"payload_content_in_receipt", false}
                };

                receipt["resource_bounds"] = new Dictionary<string, object> {
                    {"stdout_limit_bytes", stdoutLimit},
                    {"stderr_limit_bytes", stderrLimit},
                    {"timeout_ms", timeoutMs},
                    {"stdout_bytes", stdoutBytes.Length},
                    {"stderr_bytes", stderrBytes.Length},
                    {"stdout_limit_exceeded", false},
                    {"stderr_limit_exceeded", false},
                    {"timeout_triggered", false},
                    {"drain_mode", "CONCURRENT_BOUNDED"}
                };

                receipt["boundary"] = new Dictionary<string, object> {
                    {"process_observation_mode", "NATIVE_HANDLE_BOUND"},
                    {"wmi_used_for_runtime_evidence", false},
                    {"dotnet_process_properties_used_for_child_identity", false},
                    {"child_content_schema", "NOT_INSPECTED"},
                    {"child_can_choose_principal", false},
                    {"child_can_receive_runtime_grant", false},
                    {"mediator_is_authenticated", false},
                    {"raw_local_paths_serialized", false}
                };

                receipt["authorization_status"] = "NOT_AUTHORIZED";
                receipt["runtime_grant_issued"] = false;
                receipt["g1_token_issued"] = false;
                receipt["f2_unlocked"] = false;
                receipt["authority_effect"] = "NONE";

                var serializer = new JavaScriptSerializer();
                File.WriteAllText(output, serializer.Serialize(receipt), new UTF8Encoding(false));
                Console.WriteLine("R9B4_SYNTHETIC_MATRIX_RECEIPT_READY");
                Console.WriteLine("AUTHORITY_EFFECT=NONE");
                return 0;
            }
        }
    }
}
