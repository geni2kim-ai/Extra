using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Web.Script.Serialization;
using Microsoft.Win32.SafeHandles;

namespace SynapseR9B4
{
    internal static class Native
    {
        internal const uint PIPE_ACCESS_DUPLEX = 0x00000003;
        internal const uint FILE_FLAG_FIRST_PIPE_INSTANCE = 0x00080000;
        internal const uint PIPE_REJECT_REMOTE_CLIENTS = 0x00000008;
        internal const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;
        internal const uint STILL_ACTIVE = 259;
        internal const int ERROR_PIPE_CONNECTED = 535;
        internal const uint SDDL_REVISION_1 = 1;

        [StructLayout(LayoutKind.Sequential)]
        internal struct SECURITY_ATTRIBUTES {
            internal int nLength;
            internal IntPtr lpSecurityDescriptor;
            internal int bInheritHandle;
        }
        [StructLayout(LayoutKind.Sequential)]
        internal struct FILETIME { internal uint Low; internal uint High; }

        [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        internal static extern bool ConvertStringSecurityDescriptorToSecurityDescriptor(
            string sddl, uint revision, out IntPtr sd, out uint size);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern IntPtr LocalFree(IntPtr hMem);
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        internal static extern IntPtr CreateNamedPipe(
            string lpName,uint dwOpenMode,uint dwPipeMode,uint nMaxInstances,
            uint nOutBufferSize,uint nInBufferSize,uint nDefaultTimeOut,ref SECURITY_ATTRIBUTES lpSecurityAttributes);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern bool ConnectNamedPipe(SafeFileHandle hNamedPipe,IntPtr lpOverlapped);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern bool DisconnectNamedPipe(SafeFileHandle hNamedPipe);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern bool GetNamedPipeClientProcessId(SafeFileHandle Pipe,out uint ClientProcessId);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern IntPtr OpenProcess(uint access,bool inherit,uint pid);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern bool GetProcessTimes(SafeFileHandle process,out FILETIME c,out FILETIME e,out FILETIME k,out FILETIME u);
        [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        internal static extern bool QueryFullProcessImageName(SafeFileHandle process,uint flags,StringBuilder name,ref uint size);
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern bool GetExitCodeProcess(SafeFileHandle process,out uint code);
        [DllImport("advapi32.dll", SetLastError=true)]
        internal static extern bool ImpersonateNamedPipeClient(SafeFileHandle pipe);
        [DllImport("advapi32.dll", SetLastError=true)]
        internal static extern bool RevertToSelf();
        [DllImport("kernel32.dll", SetLastError=true)]
        internal static extern bool ReadFile(SafeFileHandle h,byte[] buffer,uint count,out uint read,IntPtr overlapped);
    }

    internal sealed class CaptureResult
    {
        internal string PipeName;
        internal string ServerInstanceId;
        internal uint ClientPid;
        internal uint ClientPidRechecked;
        internal long CreationTime;
        internal long CreationTimeRechecked;
        internal string ProcessPath;
        internal string ProcessPathRechecked;
        internal string ProcessSha256;
        internal string UserSid;
        internal string[] ServiceSids;
        internal string RequestUtf8;
    }

    internal static class VerifierServer
    {
        private static void Win32(bool ok,string code) {
            if(!ok) throw new Win32Exception(Marshal.GetLastWin32Error(),code);
        }
        private static long Ft(Native.FILETIME x) {
            return ((long)x.High << 32) | x.Low;
        }
        private static long Creation(SafeFileHandle p) {
            Native.FILETIME c,e,k,u;
            Win32(Native.GetProcessTimes(p,out c,out e,out k,out u),"GET_PROCESS_TIMES_FAILED");
            return Ft(c);
        }
        private static string QueryPath(SafeFileHandle p) {
            uint size=32768; var sb=new StringBuilder((int)size);
            Win32(Native.QueryFullProcessImageName(p,0,sb,ref size),"QUERY_IMAGE_PATH_FAILED");
            if(sb.Length==0) throw new InvalidOperationException("EMPTY_PROCESS_PATH");
            return sb.ToString();
        }
        private static string ShaFile(string p) {
            using(var sha=SHA256.Create())
            using(var fs=new FileStream(p,FileMode.Open,FileAccess.Read,FileShare.ReadWrite|FileShare.Delete)) {
                byte[] d=sha.ComputeHash(fs); var sb=new StringBuilder(d.Length*2);
                foreach(byte b in d) sb.Append(b.ToString("x2")); return sb.ToString();
            }
        }
        private static string ShaText(string s) {
            using(var sha=SHA256.Create()) {
                byte[] d=sha.ComputeHash(Encoding.UTF8.GetBytes(s)); var sb=new StringBuilder(d.Length*2);
                foreach(byte b in d) sb.Append(b.ToString("x2")); return sb.ToString();
            }
        }
        private static void ReadExact(SafeFileHandle pipe,byte[] buffer,int offset,int count,string code) {
            int done=0;
            while(done<count) {
                byte[] tmp=new byte[count-done]; uint n=0;
                Win32(Native.ReadFile(pipe,tmp,(uint)tmp.Length,out n,IntPtr.Zero),code);
                if(n==0) throw new EndOfStreamException(code+"_EOF");
                Buffer.BlockCopy(tmp,0,buffer,offset+done,(int)n);
                done += (int)n;
            }
        }
        private static int FrameLength(byte[] h) {
            return (h[0]<<24)|(h[1]<<16)|(h[2]<<8)|h[3];
        }
        private static bool SidSafe(string sid) {
            if(String.IsNullOrWhiteSpace(sid)||!sid.StartsWith("S-",StringComparison.Ordinal)) return false;
            foreach(char c in sid) if(!(Char.IsDigit(c)||c=='S'||c=='-')) return false;
            return true;
        }

        private static CaptureResult Capture(string pipeName,string allowedSid,int maxBytes) {
            string serverSid=WindowsIdentity.GetCurrent().User.Value;
            string sddl="D:P(D;;GA;;;NU)(A;;GA;;;SY)(A;;GA;;;"+serverSid+")(A;;GRGW;;;"+allowedSid+")";
            IntPtr sd=IntPtr.Zero; uint sdSize=0;
            Win32(Native.ConvertStringSecurityDescriptorToSecurityDescriptor(sddl,Native.SDDL_REVISION_1,out sd,out sdSize),"SDDL_CONVERSION_FAILED");
            SafeFileHandle pipe=null;
            try {
                var sa=new Native.SECURITY_ATTRIBUTES();
                sa.nLength=Marshal.SizeOf(typeof(Native.SECURITY_ATTRIBUTES)); sa.lpSecurityDescriptor=sd; sa.bInheritHandle=0;
                IntPtr raw=Native.CreateNamedPipe(@"\\.\pipe\"+pipeName,
                    Native.PIPE_ACCESS_DUPLEX|Native.FILE_FLAG_FIRST_PIPE_INSTANCE,
                    Native.PIPE_REJECT_REMOTE_CLIENTS,1,4096,(uint)(maxBytes+4),5000,ref sa);
                if(raw==new IntPtr(-1)) throw new Win32Exception(Marshal.GetLastWin32Error(),"CREATE_NAMED_PIPE_FAILED");
                pipe=new SafeFileHandle(raw,true);
                bool connected=Native.ConnectNamedPipe(pipe,IntPtr.Zero);
                if(!connected) {
                    int err=Marshal.GetLastWin32Error();
                    if(err!=Native.ERROR_PIPE_CONNECTED) throw new Win32Exception(err,"CONNECT_NAMED_PIPE_FAILED");
                }

                uint pid=0;
                Win32(Native.GetNamedPipeClientProcessId(pipe,out pid),"CLIENT_PID_LOOKUP_FAILED");
                IntPtr rawProc=Native.OpenProcess(Native.PROCESS_QUERY_LIMITED_INFORMATION,false,pid);
                if(rawProc==IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error(),"OPEN_CLIENT_PROCESS_FAILED");
                using(var proc=new SafeFileHandle(rawProc,true)) {
                    long creation1=Creation(proc); string path1=QueryPath(proc);

                    byte[] header=new byte[4]; ReadExact(pipe,header,0,4,"READ_FRAME_HEADER_FAILED");
                    int payloadLen=FrameLength(header);
                    if(payloadLen<2||payloadLen>maxBytes) throw new InvalidOperationException("INVALID_FRAME_LENGTH");
                    byte[] payload=new byte[payloadLen]; ReadExact(pipe,payload,0,payloadLen,"READ_FRAME_BODY_FAILED");
                    string request=Encoding.UTF8.GetString(payload);

                    Win32(Native.ImpersonateNamedPipeClient(pipe),"CLIENT_IMPERSONATION_FAILED");
                    string userSid; var service=new List<string>();
                    try {
                        using(WindowsIdentity wi=WindowsIdentity.GetCurrent(true)) {
                            userSid=wi.User.Value;
                            if(!String.Equals(userSid,allowedSid,StringComparison.OrdinalIgnoreCase))
                                throw new UnauthorizedAccessException("IMPERSONATED_SID_MISMATCH");
                            if(wi.Groups!=null) foreach(IdentityReference ir in wi.Groups) {
                                SecurityIdentifier sid=ir as SecurityIdentifier;
                                if(sid!=null && sid.Value.StartsWith("S-1-5-80-",StringComparison.Ordinal)) service.Add(sid.Value);
                            }
                        }
                    } finally {
                        Win32(Native.RevertToSelf(),"REVERT_TO_SELF_FAILED");
                    }

                    string fileHash=ShaFile(path1);
                    long creation2=Creation(proc); string path2=QueryPath(proc);
                    if(creation1!=creation2) throw new InvalidOperationException("PROCESS_CREATION_TIME_CHANGED");
                    if(!String.Equals(path1,path2,StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("PROCESS_PATH_CHANGED");
                    uint pid2=0; Win32(Native.GetNamedPipeClientProcessId(pipe,out pid2),"CLIENT_PID_RECHECK_FAILED");
                    if(pid2!=pid) throw new InvalidOperationException("PIPE_CLIENT_PID_CHANGED");
                    uint exit=0; Win32(Native.GetExitCodeProcess(proc,out exit),"GET_EXIT_CODE_FAILED");
                    if(exit!=Native.STILL_ACTIVE) throw new InvalidOperationException("CLIENT_PROCESS_NOT_ACTIVE");
                    return new CaptureResult {
                        PipeName=pipeName,ServerInstanceId=Guid.NewGuid().ToString("D"),ClientPid=pid,ClientPidRechecked=pid2,
                        CreationTime=creation1,CreationTimeRechecked=creation2,ProcessPath=path1,ProcessPathRechecked=path2,
                        ProcessSha256=fileHash,UserSid=userSid,ServiceSids=service.ToArray(),RequestUtf8=request
                    };
                }
            } finally {
                if(pipe!=null && !pipe.IsInvalid) { try{Native.DisconnectNamedPipe(pipe);}catch{} pipe.Dispose(); }
                if(sd!=IntPtr.Zero) Native.LocalFree(sd);
            }
        }

        private static int Main(string[] args) {
            try {
                var map=new Dictionary<string,string>(StringComparer.Ordinal);
                for(int i=0;i<args.Length;i+=2) {
                    if(i+1>=args.Length || !args[i].StartsWith("--",StringComparison.Ordinal))
                        throw new ArgumentException("R9B4_SERVER_ARGUMENT_INVALID");
                    map[args[i]]=args[i+1];
                }
                string[] required={"--pipe","--allowed-sid","--run-id","--session-id","--nonce","--output","--completion",
                    "--preflight-sha256","--run-context-sha256","--build-receipt-sha256","--verifier-source-sha256"};
                foreach(string k in required) if(!map.ContainsKey(k)) throw new ArgumentException("R9B4_SERVER_ARGUMENT_MISSING");
                string pipeName=map["--pipe"], allowedSid=map["--allowed-sid"], runId=map["--run-id"],
                    session=map["--session-id"], nonce=map["--nonce"], output=map["--output"], completion=map["--completion"];
                if(!SidSafe(allowedSid)) throw new ArgumentException("R9B4_ALLOWED_SID_INVALID");
                if(runId.Length!=32||nonce.Length!=32) throw new ArgumentException("R9B4_RUN_TOKEN_INVALID");

                var cap=Capture(pipeName,allowedSid,4096);
                var serializer=new JavaScriptSerializer();
                var claims=serializer.DeserializeObject(cap.RequestUtf8) as Dictionary<string,object>;
                if(claims==null || !claims.ContainsKey("measurement_nonce") || Convert.ToString(claims["measurement_nonce"])!=nonce)
                    throw new InvalidOperationException("R9B4_NONCE_REQUEST_MISMATCH");

                string selfPath;
                int selfPid;
                using(Process selfProcess=Process.GetCurrentProcess()) {
                    selfPath=selfProcess.MainModule.FileName;
                    selfPid=selfProcess.Id;
                }
                string selfSha=ShaFile(selfPath);
                string capturedAt=DateTime.UtcNow.ToString("o");

                var capture=new Dictionary<string,object> {
                    {"schema_version","SYNAPSE-R9B4-NAMED-PIPE-CAPTURE-1"},
                    {"captured_at_utc",capturedAt},
                    {"run_id",runId},
                    {"pipe",new Dictionary<string,object> {
                        {"name",cap.PipeName},{"server_instance_id",cap.ServerInstanceId},{"allowed_client_sid",allowedSid},
                        {"security_configuration_basis","PINNED_VERIFIER_SERVER_BINARY"}
                    }},
                    {"client",new Dictionary<string,object> {
                        {"pid",(long)cap.ClientPid},{"pid_rechecked",(long)cap.ClientPidRechecked},
                        {"pid_source","GetNamedPipeClientProcessId"},{"process_creation_time_100ns",cap.CreationTime},
                        {"process_creation_time_rechecked_100ns",cap.CreationTimeRechecked},
                        {"process_path",cap.ProcessPath},{"process_path_rechecked",cap.ProcessPathRechecked},
                        {"process_sha256",cap.ProcessSha256},{"process_sha256_semantics","ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH"},
                        {"loaded_image_hash_verified",false},{"process_active_after_capture",true}
                    }},
                    {"token",new Dictionary<string,object> {
                        {"user_sid",cap.UserSid},{"service_sids",cap.ServiceSids},
                        {"token_source","ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)"},
                        {"impersonation_succeeded",true}
                    }},
                    {"verifier",new Dictionary<string,object> {
                        {"pid",selfPid},
                        {"binary_name",Path.GetFileName(selfPath)},{"binary_sha256",selfSha},
                        {"binary_sha256_semantics","ON_DISK_EXECUTABLE_SELF_PATH"},
                        {"source_sha256",map["--verifier-source-sha256"]}
                    }},
                    {"preflight_sha256",map["--preflight-sha256"]},
                    {"run_context_sha256",map["--run-context-sha256"]},
                    {"build_receipt_sha256",map["--build-receipt-sha256"]},
                    {"evidence_source","PIPE_PID_BEFORE_FRAME+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK"},
                    {"captured_node_session_id",session},
                    {"caller_claims",new Dictionary<string,object> {
                        {"claimed_node_id",null},{"claimed_workload_id",null},{"measurement_nonce",nonce}
                    }},
                    {"authentication_result","CAPTURE_ONLY"},{"authorization_status","NOT_AUTHORIZED"},
                    {"runtime_grant_issued",false},{"g1_token_issued",false},{"f2_unlocked",false},{"authority_effect","NONE"}
                };
                File.WriteAllText(output,serializer.Serialize(capture),new UTF8Encoding(false));
                string captureSha=ShaFile(output);
                var done=new Dictionary<string,object> {
                    {"schema_version","SYNAPSE-R9B4-SERVER-COMPLETION-1"},{"status","SERVER_CAPTURE_COMPLETE"},
                    {"completed_at_utc",DateTime.UtcNow.ToString("o")},{"run_id",runId},{"pipe_name",pipeName},
                    {"server_instance_id",cap.ServerInstanceId},{"node_session_id",session},{"measurement_nonce",nonce},
                    {"capture_sha256",captureSha},{"verifier_pid",selfPid},{"verifier_binary_sha256",selfSha},
                    {"verifier_source_sha256",map["--verifier-source-sha256"]},{"preflight_sha256",map["--preflight-sha256"]},
                    {"run_context_sha256",map["--run-context-sha256"]},{"build_receipt_sha256",map["--build-receipt-sha256"]},
                    {"authentication_result","CAPTURE_ONLY"},{"authorization_status","NOT_AUTHORIZED"},
                    {"runtime_grant_issued",false},{"g1_token_issued",false},{"f2_unlocked",false},{"authority_effect","NONE"}
                };
                File.WriteAllText(completion,serializer.Serialize(done),new UTF8Encoding(false));
                Console.WriteLine("R9B4_VERIFIER_CAPTURE_COMPLETE");
                Console.WriteLine("AUTHORITY_EFFECT=NONE");
                return 0;
            } catch(Exception ex) {
                Console.Error.WriteLine("R9B4_VERIFIER_FAILURE "+ex.GetType().Name+" "+ex.Message);
                return 31;
            }
        }
    }
}
