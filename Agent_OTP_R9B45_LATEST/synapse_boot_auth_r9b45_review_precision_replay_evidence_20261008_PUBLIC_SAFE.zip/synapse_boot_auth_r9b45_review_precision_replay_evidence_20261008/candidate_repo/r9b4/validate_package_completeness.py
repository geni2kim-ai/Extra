#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,re
from pathlib import Path

REQUIRED=[
 "r9b4/src/VerifierServer.cs","r9b4/src/DedicatedMediator.cs","r9b4/src/SyntheticChild.cs",
 "r9b4/evaluate_r9b4.py","r9b4/preflight.py","r9b4/verify_review_safe_set.py","r9b4/provision_registry.py",
 "r9b4/windows/build_r9b4.ps1","r9b4/windows/run_r9b4_measurement.ps1","r9b4/windows/R9B4Cleanup.psm1",
 "r9b4/windows/run_r9b41_forced_timeout_probe.ps1","r9b4/windows/run_r9b41_cleanup_tree_semantics_probe.ps1",
 "r9b4/distribution/make_review_safe_bundle.py","r9b4/r9b4/evaluator.py","r9b4/r9b4/replay.py","r9b4/tests/test_producer_evaluator_contract.py","r9b4/validate_cleanup_evidence.py","r9b4/build_evidence_provenance.py","r9b4/tests/test_r9b45_evidence_precision.py",
 "handoff/YM_R9B41_WORK_PACKET.md"
]

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--candidate-root",default=".");ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();root=Path(ns.candidate_root).resolve();missing=[x for x in REQUIRED if not (root/x).is_file()]
    hashes_path=root/"r9b4/EXPECTED_ISSUED_SOURCE_HASHES.json"
    hash_missing=[];hash_mismatch=[]
    if hashes_path.is_file():
        doc=json.loads(hashes_path.read_text(encoding="utf-8"))
        for rel,digest in doc.get("files",{}).items():
            p=root/rel
            if not p.is_file():hash_missing.append(rel)
            elif sha(p)!=digest:hash_mismatch.append(rel)
    else:hash_missing.append("r9b4/EXPECTED_ISSUED_SOURCE_HASHES.json")
    packet=root/"handoff/YM_R9B41_WORK_PACKET.md";broken_refs=[]
    if packet.is_file():
        txt=packet.read_text(encoding="utf-8")
        for raw in sorted(set(re.findall(r"\.\\(r9b4\\[A-Za-z0-9_.\\-]+)",txt))):
            rel=raw.replace("\\","/")
            # Generated output files are outside r9b4; r9b4 references must exist in package.
            if not (root/rel).exists():broken_refs.append(rel)
    status="PASS" if not(missing or hash_missing or hash_mismatch or broken_refs) else "FAIL"
    out={"schema_version":"SYNAPSE-R9B41-PACKAGE-COMPLETENESS-1","status":status,
         "required_file_count":len(REQUIRED),"missing_required_files":missing,
         "issued_hash_missing_files":hash_missing,"issued_hash_mismatches":hash_mismatch,
         "broken_handoff_package_references":broken_refs,"authority_effect":"NONE"}
    Path(ns.output).write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8",newline="\n")
    print(json.dumps(out,indent=2))
    return 0 if status=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
