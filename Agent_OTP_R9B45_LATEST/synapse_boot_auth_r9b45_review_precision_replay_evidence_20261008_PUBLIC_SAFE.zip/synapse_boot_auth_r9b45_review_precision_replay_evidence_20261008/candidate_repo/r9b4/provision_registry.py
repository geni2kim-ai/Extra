#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from r9b4.common import Denied,load_json_bytes,require_sid,require_workload,sha_bytes

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--build-receipt",required=True)
    ap.add_argument("--mediator-exe",required=True)
    ap.add_argument("--allowed-user-sid",required=True)
    ap.add_argument("--derived-workload-id",required=True)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();out=Path(ns.output)
    try:
        if out.exists(): raise Denied("REGISTRY_OUTPUT_ALREADY_EXISTS")
        _,build=load_json_bytes(Path(ns.build_receipt),"BUILD")
        med=Path(ns.mediator_exe).read_bytes();msha=sha_bytes(med)
        if build.get("schema_version")!="SYNAPSE-R9B4-BUILD-RECEIPT-1":raise Denied("BUILD_SCHEMA_INVALID")
        if build.get("mediator_binary_sha256")!=msha:raise Denied("BUILD_MEDIATOR_SHA_MISMATCH")
        if build.get("authentication_result")!="NOT_PERFORMED":raise Denied("BUILD_AUTHENTICATION_PRECLAIMED")
        if build.get("authorization_status")!="NOT_AUTHORIZED":raise Denied("BUILD_AUTHORIZATION_PRECLAIMED")
        if build.get("authority_effect")!="NONE":raise Denied("BUILD_AUTHORITY_EFFECT_NOT_NONE")
        sid=require_sid(ns.allowed_user_sid,"ALLOWED_SID_INVALID")
        wid=require_workload(ns.derived_workload_id,"WORKLOAD_ID_INVALID")
        doc={
          "schema_version":"SYNAPSE-R9B4-PREPROVISIONED-VERIFIER-REGISTRY-1",
          "registry_trust":"PREPROVISIONED_REHEARSAL_ONLY",
          "entries":[{"derived_workload_id":wid,"mediator_binary_sha256":msha,"allowed_user_sid":sid}],
          "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
          "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
        }
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(doc,indent=2)+"\n",encoding="utf-8",newline="\n")
        print(json.dumps({"status":"R9B4_REGISTRY_PROVISIONED","registry_sha256":sha_bytes(out.read_bytes()),"authority_effect":"NONE"}))
        return 0
    except Denied as e:
        print(json.dumps({"status":"DENIED","code":e.code,"authority_effect":"NONE"}));return 2
    except Exception:
        print(json.dumps({"status":"DENIED","code":"UNEXPECTED_PROVISION_ERROR","authority_effect":"NONE"}));return 2

if __name__=="__main__":raise SystemExit(main())
