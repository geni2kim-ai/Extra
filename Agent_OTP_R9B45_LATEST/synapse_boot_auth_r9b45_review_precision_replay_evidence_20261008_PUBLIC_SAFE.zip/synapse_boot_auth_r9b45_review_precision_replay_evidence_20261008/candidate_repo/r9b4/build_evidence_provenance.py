#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
from typing import Any

def sha_bytes(b:bytes)->str:return hashlib.sha256(b).hexdigest()
def load(path:Path)->dict[str,Any]:
    obj=json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(obj,dict):raise ValueError("TOP_LEVEL_NOT_OBJECT")
    return obj
def crlf_bytes(b:bytes)->bytes:
    text=b.decode("utf-8-sig")
    return text.replace("\r\n","\n").replace("\n","\r\n").encode("utf-8")

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--source-zip-sha256",required=True)
    ap.add_argument("--source-anchor-commit",required=True)
    ap.add_argument("--source-anchor-path",required=True)
    ap.add_argument("--runtime-root",required=True)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();root=Path(ns.runtime_root)
    timeout=load(root/"evidence/probes/R9B42_timeout_probe/harness_failure.json")
    wrong=load(root/"evidence/probes/R9B4_wrongsid/harness_failure.json")
    recorded={
      "evidence/probes/R9B42_timeout_probe/cleanup_receipt.json":timeout.get("cleanup_receipt_sha256"),
      "evidence/probes/R9B4_wrongsid/cleanup_receipt.json":wrong.get("cleanup_receipt_sha256"),
      "evidence/probes/R9B4_wrongsid/server.stderr.txt":wrong.get("server_stderr_sha256"),
    }
    files={}
    for p in sorted(root.rglob("*")):
        if not p.is_file():continue
        rel=p.relative_to(root).as_posix()
        b=p.read_bytes();pack=sha_bytes(b)
        item={
          "packaged_human_supplement_sha256":pack,
          "copied_from_packaged_ym_return_zip_byte_for_byte":True,
          "runtime_byte_identity_claimed":False if rel in recorded else None
        }
        if rel in recorded and recorded[rel]:
            rec=recorded[rel];item["harness_recorded_runtime_sha256"]=rec
            try:
                crlf=sha_bytes(crlf_bytes(b))
                item["crlf_reconstructed_sha256"]=crlf
                item["normalization_relation"]="PACKAGED_LF_TO_CRLF_RECONSTRUCTION_MATCHES_HARNESS" if crlf==rec else "NO_CONFIRMED_NORMALIZATION_RELATION"
            except Exception:
                item["normalization_relation"]="NON_UTF8_OR_RECONSTRUCTION_UNAVAILABLE"
        files[rel]=item
    out={
      "schema_version":"SYNAPSE-R9B45-EVIDENCE-PROVENANCE-1",
      "source_packaged_ym_return_zip_sha256":ns.source_zip_sha256,
      "source_anchor":{"commit":ns.source_anchor_commit,"path":ns.source_anchor_path,
                       "semantics":"DIGEST_ONLY_PRODUCER_OWNED_IMMUTABLE_PUBLICATION"},
      "provenance_statement":"Files are byte-identical to the packaged YM return ZIP entries. Runtime byte identity is not claimed where the Windows harness digest differs.",
      "files":files,"authority_effect":"NONE"
    }
    Path(ns.output).write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8",newline="\n")
    print(json.dumps({"status":"PASS","file_count":len(files),"authority_effect":"NONE"}));return 0
if __name__=="__main__":raise SystemExit(main())
