#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from datetime import datetime,timezone
from pathlib import Path
from r9b4.common import load_json_bytes,sha_bytes
from r9b4.evaluator import evaluate

def load(path:Path,label:str):
    b,d=load_json_bytes(path,label);return d,sha_bytes(b)
def fsha(path:Path)->str:return hashlib.sha256(path.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("review_dir");ap.add_argument("-o","--output",required=True);ns=ap.parse_args()
    d=Path(ns.review_dir);bind=json.loads((d/"REVIEW_SAFE_BINDINGS.json").read_text(encoding="utf-8"))
    cap,csha=load(d/"capture.review.json","CAPTURE");reg,rsha=load(d/"registry.review.json","REGISTRY")
    pf,psha=load(d/"preflight.review.json","PREFLIGHT");ctx,xsha=load(d/"run_context.review.json","RUN_CONTEXT")
    h,hsha=load(d/"harness.review.json","HARNESS");comp,dsha=load(d/"completion.review.json","COMPLETION")
    cleanup,ksha=load(d/"cleanup.review.json","CLEANUP");build,bsha=load(d/"build.review.json","BUILD")
    ex=bind["expected_sha256_for_offline_review"]
    hashes={"capture_sha256":csha,"registry_sha256":rsha,"preflight_sha256":psha,"run_context_sha256":xsha,
      "harness_sha256":hsha,"completion_sha256":dsha,"cleanup_sha256":ksha,"build_receipt_sha256":bsha,
      "mediator_sha256":fsha(d/"R9B4_DedicatedMediator.exe"),"verifier_binary_sha256":fsha(d/"R9B4_VerifierServer.exe"),
      "verifier_source_sha256":fsha(d/"VerifierServer.cs"),
      "expected_registry_sha256":ex["registry"],"expected_mediator_sha256":ex["mediator"],
      "expected_verifier_binary_sha256":ex["verifier_binary"],"expected_verifier_source_sha256":ex["verifier_source"],
      "expected_build_receipt_sha256":ex["build_receipt"]}
    try:
        out=evaluate(cap,build,reg,pf,ctx,h,comp,cleanup,hashes,datetime.now(timezone.utc),False)
        out["review_safe_binding_semantics"]=bind["binding_semantics"];code=0
    except Exception as exc:
        out={"result":"R9B4_REVIEW_SAFE_DENIED","code":getattr(exc,"code","UNEXPECTED_REVIEW_SAFE_ERROR"),"authority_effect":"NONE"};code=2
    Path(ns.output).write_text(json.dumps(out,indent=2,ensure_ascii=False)+"\n",encoding="utf-8",newline="\n")
    print(json.dumps(out,indent=2,ensure_ascii=False));return code

if __name__=="__main__":raise SystemExit(main())
