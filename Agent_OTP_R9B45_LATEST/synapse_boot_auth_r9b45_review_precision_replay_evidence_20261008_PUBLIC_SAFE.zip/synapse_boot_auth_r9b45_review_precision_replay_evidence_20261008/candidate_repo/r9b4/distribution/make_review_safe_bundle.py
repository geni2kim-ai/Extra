#!/usr/bin/env python3
from __future__ import annotations
import argparse,copy,hashlib,json,re,shutil
from pathlib import Path
from typing import Any

MASK_SID="S-1-5-21-900000000-900000000-900000000-9001"
MASK_ROOT=r"C:\REVIEW_SAFE"
SID_RE=re.compile(r"\AS-\d-\d+(?:-\d+){1,15}\Z",re.IGNORECASE)
WIN_PATH_RE=re.compile(r"\A[A-Za-z]:\\")
HEX64_RE=re.compile(r"\A[0-9a-f]{64}\Z")

def sha_bytes(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def load(path:Path)->dict[str,Any]:
    obj=json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(obj,dict):raise ValueError("TOP_LEVEL_NOT_OBJECT")
    return obj
def dump(path:Path,obj:dict[str,Any])->bytes:
    data=(json.dumps(obj,indent=2,ensure_ascii=False)+"\n").encode("utf-8")
    path.write_bytes(data);return data
def basename_win(s:str)->str:return s.replace("/","\\").split("\\")[-1]

def transform_value(v:Any)->Any:
    if isinstance(v,dict):return {k:transform_value(val) for k,val in v.items()}
    if isinstance(v,list):return [transform_value(val) for val in v]
    if isinstance(v,str):
        if SID_RE.fullmatch(v):return MASK_SID
        if WIN_PATH_RE.match(v):return MASK_ROOT+"\\"+basename_win(v)
    return v

def inventory_diff(before:Any,after:Any,pointer:str="")->list[dict[str,Any]]:
    out:list[dict[str,Any]]=[]
    if isinstance(before,dict) and isinstance(after,dict):
        for k in sorted(set(before)|set(after)):
            p=pointer+"/"+str(k).replace("~","~0").replace("/","~1")
            if k not in before:out.append({"json_pointer":p,"class":"FIELD_ADDED"})
            elif k not in after:out.append({"json_pointer":p,"class":"FIELD_REMOVED"})
            else:out.extend(inventory_diff(before[k],after[k],p))
        return out
    if isinstance(before,list) and isinstance(after,list):
        for i in range(max(len(before),len(after))):
            p=pointer+"/"+str(i)
            if i>=len(before):out.append({"json_pointer":p,"class":"LIST_ITEM_ADDED"})
            elif i>=len(after):out.append({"json_pointer":p,"class":"LIST_ITEM_REMOVED"})
            else:out.extend(inventory_diff(before[i],after[i],p))
        return out
    if before==after:return out
    entry:dict[str,Any]={"json_pointer":pointer}
    if isinstance(before,str) and isinstance(after,str) and SID_RE.fullmatch(before) and after==MASK_SID:
        entry["class"]="PRIVACY_TRANSFORM";entry["transform"]="SID_MASK";entry["original_value_disclosed"]=False;entry["review_value"]=after
    elif isinstance(before,str) and isinstance(after,str) and WIN_PATH_RE.match(before) and after.startswith(MASK_ROOT+"\\"):
        entry["class"]="PRIVACY_TRANSFORM";entry["transform"]="WINDOWS_PATH_BASENAME_MASK";entry["original_value_disclosed"]=False;entry["review_value"]=after
    elif isinstance(before,str) and isinstance(after,str) and HEX64_RE.fullmatch(before) and HEX64_RE.fullmatch(after):
        entry["class"]="DERIVED_REBINDING";entry["original_sha256_binding"]=before;entry["review_sha256_binding"]=after
    else:
        entry["class"]="VALUE_CHANGED";entry["original_value_disclosed"]=False
    out.append(entry);return out

def scan_review_json(directory:Path)->list[dict[str,str]]:
    findings=[]
    for p in sorted(directory.glob("*.json")):
        text=p.read_text(encoding="utf-8-sig")
        for m in re.finditer(r"S-\d-\d+(?:-\d+){1,15}",text,re.IGNORECASE):
            if m.group(0)!=MASK_SID:findings.append({"file":p.name,"class":"UNEXPECTED_SID"})
        if re.search(r"(?i)[A-Z]:\\Users\\|AppData\\",text):
            findings.append({"file":p.name,"class":"LOCAL_USER_PATH"})
    return findings

def main()->int:
    ap=argparse.ArgumentParser()
    for x in ("capture","registry","preflight","run-context","harness-summary","server-completion","cleanup-receipt","build-receipt","result"):
        ap.add_argument("--"+x,required=True)
    ap.add_argument("--mediator-exe",required=True);ap.add_argument("--verifier-exe",required=True);ap.add_argument("--verifier-source",required=True)
    ap.add_argument("--output-directory",required=True)
    ns=ap.parse_args();out=Path(ns.output_directory)
    if out.exists():raise SystemExit("OUTPUT_ALREADY_EXISTS")
    out.mkdir(parents=True)

    paths={"capture":Path(ns.capture),"registry":Path(ns.registry),"preflight":Path(ns.preflight),
      "run_context":Path(ns.run_context),"harness":Path(ns.harness_summary),"completion":Path(ns.server_completion),
      "cleanup":Path(ns.cleanup_receipt),"build":Path(ns.build_receipt),"result":Path(ns.result)}
    originals={k:p.read_bytes() for k,p in paths.items()}
    docs={k:load(p) for k,p in paths.items()}

    # Apply privacy transform recursively to every review JSON document first.
    reg=transform_value(copy.deepcopy(docs["registry"]))
    reg_b=dump(out/"registry.review.json",reg);reg_sha=sha_bytes(reg_b)

    pre=transform_value(copy.deepcopy(docs["preflight"]))
    pre["registry_sha256"]=reg_sha
    pre_b=dump(out/"preflight.review.json",pre);pre_sha=sha_bytes(pre_b)

    ctx=transform_value(copy.deepcopy(docs["run_context"]))
    ctx["registry_sha256"]=reg_sha;ctx["preflight_sha256"]=pre_sha
    ctx_b=dump(out/"run_context.review.json",ctx);ctx_sha=sha_bytes(ctx_b)

    cap=transform_value(copy.deepcopy(docs["capture"]))
    cap["preflight_sha256"]=pre_sha;cap["run_context_sha256"]=ctx_sha
    cap_b=dump(out/"capture.review.json",cap);cap_sha=sha_bytes(cap_b)

    comp=transform_value(copy.deepcopy(docs["completion"]))
    comp["capture_sha256"]=cap_sha;comp["preflight_sha256"]=pre_sha;comp["run_context_sha256"]=ctx_sha
    comp_b=dump(out/"completion.review.json",comp);comp_sha=sha_bytes(comp_b)

    # cleanup/build are retained byte-for-byte to preserve their original evidence digests.
    shutil.copy2(paths["cleanup"],out/"cleanup.review.json");cleanup_sha=sha_bytes((out/"cleanup.review.json").read_bytes())
    shutil.copy2(paths["build"],out/"build.review.json");build_sha=sha_bytes((out/"build.review.json").read_bytes())

    h=transform_value(copy.deepcopy(docs["harness"]))
    h["registry_sha256"]=reg_sha;h["capture_sha256"]=cap_sha;h["preflight_sha256"]=pre_sha
    h["run_context_sha256"]=ctx_sha;h["completion_sha256"]=comp_sha;h["cleanup_sha256"]=cleanup_sha
    h["build_receipt_sha256"]=build_sha;h["post_run_registry_sha256"]=reg_sha
    h_b=dump(out/"harness.review.json",h);h_sha=sha_bytes(h_b)

    final_docs={"registry":reg,"preflight":pre,"run_context":ctx,"capture":cap,"completion":comp,"harness":h,
                "cleanup":docs["cleanup"],"build":docs["build"]}
    complete_inventory=[]
    for name in ("registry","preflight","run_context","capture","completion","harness","cleanup","build"):
        for change in inventory_diff(docs[name],final_docs[name],"/"+name):
            complete_inventory.append(change)
    complete_inventory=sorted(complete_inventory,key=lambda x:x["json_pointer"])

    for src,name in ((Path(ns.mediator_exe),"R9B4_DedicatedMediator.exe"),
                     (Path(ns.verifier_exe),"R9B4_VerifierServer.exe"),
                     (Path(ns.verifier_source),"VerifierServer.cs")):
        shutil.copy2(src,out/name)

    bindings={
      "schema_version":"SYNAPSE-R9B45-REVIEW-SAFE-BINDINGS-1",
      "binding_semantics":"PRIVACY_TRANSFORMED_REBOUND_REVIEW_SET_NOT_ORIGINAL_RUNTIME_BYTES",
      "files":{
        "capture.review.json":cap_sha,"registry.review.json":reg_sha,"preflight.review.json":pre_sha,
        "run_context.review.json":ctx_sha,"harness.review.json":h_sha,"completion.review.json":comp_sha,
        "cleanup.review.json":cleanup_sha,"build.review.json":build_sha,
        "R9B4_DedicatedMediator.exe":sha_bytes(Path(ns.mediator_exe).read_bytes()),
        "R9B4_VerifierServer.exe":sha_bytes(Path(ns.verifier_exe).read_bytes()),
        "VerifierServer.cs":sha_bytes(Path(ns.verifier_source).read_bytes())
      },
      "expected_sha256_for_offline_review":{
        "registry":reg_sha,"mediator":sha_bytes(Path(ns.mediator_exe).read_bytes()),
        "verifier_binary":sha_bytes(Path(ns.verifier_exe).read_bytes()),
        "verifier_source":sha_bytes(Path(ns.verifier_source).read_bytes()),"build_receipt":build_sha
      },
      "authority_effect":"NONE"
    }
    dump(out/"REVIEW_SAFE_BINDINGS.json",bindings)

    receipt={
      "schema_version":"SYNAPSE-R9B45-TRANSFORMATION-RECEIPT-1",
      "source_artifact_sha256":{k:sha_bytes(v) for k,v in originals.items()},
      "changed_fields":complete_inventory,
      "change_inventory_generation":"AUTOMATIC_RECURSIVE_BEFORE_VS_FINAL_REVIEW_JSON_DIFF",
      "per_field_preimage_hashes_included":False,
      "raw_values_embedded":False,
      "post_transform_sha256":bindings["files"],
      "authority_effect":"NONE"
    }
    dump(out/"TRANSFORMATION_RECEIPT.json",receipt)
    dump(out/"COMPLETE_CHANGE_INVENTORY.json",{
      "schema_version":"SYNAPSE-R9B45-COMPLETE-CHANGE-INVENTORY-1",
      "generation":"AUTOMATIC_RECURSIVE_BEFORE_VS_FINAL_REVIEW_JSON_DIFF",
      "count":len(complete_inventory),"changes":complete_inventory,"authority_effect":"NONE"})

    findings=scan_review_json(out)
    dump(out/"PRIVACY_SCAN.json",{
      "schema_version":"SYNAPSE-R9B45-REVIEW-SAFE-PRIVACY-SCAN-1",
      "status":"PASS" if not findings else "FAIL","findings":findings,"authority_effect":"NONE"})
    if findings:raise SystemExit("REVIEW_SAFE_PRIVACY_SCAN_FAILED")

    (out/"OUT_OF_BAND_ANCHOR_REQUIRED.txt").write_text(
      "Publish the final review ZIP SHA-256 through a separate immutable channel before reviewer access.\n",
      encoding="utf-8",newline="\n")
    print(json.dumps({"status":"R9B45_REVIEW_SAFE_SET_READY","changed_field_count":len(complete_inventory),"authority_effect":"NONE"}))
    return 0

if __name__=="__main__":raise SystemExit(main())
