param(
 [Parameter(Mandatory=$true)][string]$MediatorExe,
 [Parameter(Mandatory=$true)][string]$VerifierExe,
 [Parameter(Mandatory=$true)][string]$VerifierSource,
 [Parameter(Mandatory=$true)][string]$BuildReceipt,
 [Parameter(Mandatory=$true)][string]$RegistryPath,
 [Parameter(Mandatory=$true)][string]$ExpectedRegistrySha256,
 [Parameter(Mandatory=$true)][string]$ExpectedMediatorSha256,
 [Parameter(Mandatory=$true)][string]$ExpectedVerifierBinarySha256,
 [Parameter(Mandatory=$true)][string]$ExpectedVerifierSourceSha256,
 [Parameter(Mandatory=$true)][string]$ExpectedBuildReceiptSha256,
 [Parameter(Mandatory=$true)][string]$OutputDirectory,
 [string]$PythonExe="python"
)
$ErrorActionPreference="Stop"
function RF([string]$p){return (Resolve-Path -LiteralPath $p -ErrorAction Stop).ProviderPath}
function RO([string]$p){return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)}
function Q([string]$v){return '"'+$v.Replace('"','\"')+'"'}

$harness=RF (Join-Path $PSScriptRoot "run_r9b4_measurement.ps1")
$out=RO $OutputDirectory
if(Test-Path -LiteralPath $out){Remove-Item -LiteralPath $out -Recurse -Force}
$ps=(Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$argLine=(
 "-NoProfile -File "+(Q $harness)+
 " -MediatorExe "+(Q (RF $MediatorExe))+
 " -VerifierExe "+(Q (RF $VerifierExe))+
 " -VerifierSource "+(Q (RF $VerifierSource))+
 " -BuildReceipt "+(Q (RF $BuildReceipt))+
 " -RegistryPath "+(Q (RF $RegistryPath))+
 " -ExpectedRegistrySha256 "+$ExpectedRegistrySha256+
 " -ExpectedMediatorSha256 "+$ExpectedMediatorSha256+
 " -ExpectedVerifierBinarySha256 "+$ExpectedVerifierBinarySha256+
 " -ExpectedVerifierSourceSha256 "+$ExpectedVerifierSourceSha256+
 " -ExpectedBuildReceiptSha256 "+$ExpectedBuildReceiptSha256+
 " -OutputDirectory "+(Q $out)+
 " -PythonExe "+(Q $PythonExe)+
 " -ServerTimeoutMs 1000 -ClientTimeoutMs 1000 -TestSuppressClientStart"
)
$psi=New-Object Diagnostics.ProcessStartInfo
$psi.FileName=$ps;$psi.Arguments=$argLine;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
$proc=New-Object Diagnostics.Process;$proc.StartInfo=$psi
if(-not $proc.Start()){throw "R9B41_TIMEOUT_PROBE_START_FAILED"}
$ot=$proc.StandardOutput.ReadToEndAsync();$et=$proc.StandardError.ReadToEndAsync()
if(-not $proc.WaitForExit(20000)){try{$proc.Kill()}catch{};throw "R9B41_TIMEOUT_PROBE_HARNESS_HUNG"}
$proc.WaitForExit();$exit=[int]$proc.ExitCode;$stdout=$ot.GetAwaiter().GetResult();$stderr=$et.GetAwaiter().GetResult();$proc.Dispose()

[IO.Directory]::CreateDirectory($out)|Out-Null
[IO.File]::WriteAllText((Join-Path $out "probe_harness.stdout.txt"),$stdout,(New-Object Text.UTF8Encoding($false)))
[IO.File]::WriteAllText((Join-Path $out "probe_harness.stderr.txt"),$stderr,(New-Object Text.UTF8Encoding($false)))
[IO.File]::WriteAllText((Join-Path $out "probe_harness.exitcode.txt"),([string]$exit+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false)))

if($exit -ne 2){throw ("R9B41_TIMEOUT_PROBE_EXPECTED_EXIT_2_ACTUAL_"+$exit)}
$failure=Get-Content -LiteralPath (Join-Path $out "harness_failure.json") -Raw|ConvertFrom-Json
$cleanup=Get-Content -LiteralPath (Join-Path $out "cleanup_receipt.json") -Raw|ConvertFrom-Json
if($failure.code -ne "R9B4_SERVER_TIMEOUT"){throw ("R9B41_TIMEOUT_PROBE_WRONG_FAILURE_"+$failure.code)}
if($failure.server_started -ne $true -or $failure.client_started -ne $false){throw "R9B41_TIMEOUT_PROBE_START_STATE_INVALID"}
if($cleanup.status -ne "PROCESSES_TERMINATED"){throw "R9B41_TIMEOUT_PROBE_CLEANUP_STATUS_INVALID"}
$s=$cleanup.server
if($s.same_instance_existed_before -ne $true){throw "R9B41_TIMEOUT_PROBE_SERVER_NOT_ALIVE_BEFORE_CLEANUP"}
if($s.tree_kill_invoked -ne $true -or $s.tree_kill_method -ne "TASKKILL_PID_TREE_FORCE"){throw "R9B41_TIMEOUT_PROBE_TREE_KILL_NOT_OBSERVED"}
if($s.taskkill_exit_code -ne 0){throw "R9B41_TIMEOUT_PROBE_TASKKILL_FAILED"}
if($s.wait_for_exit_succeeded -ne $true){throw "R9B41_TIMEOUT_PROBE_WAIT_FAILED"}
if($s.same_instance_exists_after -ne $false){throw "R9B41_TIMEOUT_PROBE_RESIDUAL_SERVER"}
$receipt=[ordered]@{
 schema_version="SYNAPSE-R9B41-FORCED-TIMEOUT-PROBE-1"
 status="PASS";actual_harness_timeout_branch="R9B4_SERVER_TIMEOUT"
 server_pid=$s.pid;server_start_time_utc=$s.expected_start_time_utc
 same_instance_existed_before=$s.same_instance_existed_before
 tree_kill_invoked=$s.tree_kill_invoked;tree_kill_method=$s.tree_kill_method;taskkill_exit_code=$s.taskkill_exit_code
 wait_for_exit_succeeded=$s.wait_for_exit_succeeded;same_instance_exists_after=$s.same_instance_exists_after
 client_started=$false;authority_effect="NONE"
}
$receipt|ConvertTo-Json -Depth 10|Set-Content -LiteralPath (Join-Path $out "forced_timeout_probe_receipt.json") -Encoding UTF8
Write-Host "R9B41_FORCED_TIMEOUT_CLEANUP_PASS"
