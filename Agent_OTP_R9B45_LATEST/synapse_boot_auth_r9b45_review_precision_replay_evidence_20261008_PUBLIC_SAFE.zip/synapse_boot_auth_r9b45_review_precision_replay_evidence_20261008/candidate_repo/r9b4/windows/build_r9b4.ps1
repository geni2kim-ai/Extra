param(
 [Parameter(Mandatory=$true)][string]$MediatorSource,
 [Parameter(Mandatory=$true)][string]$ChildSource,
 [Parameter(Mandatory=$true)][string]$VerifierSource,
 [Parameter(Mandatory=$true)][string]$MediatorExe,
 [Parameter(Mandatory=$true)][string]$ChildExe,
 [Parameter(Mandatory=$true)][string]$VerifierExe,
 [Parameter(Mandatory=$true)][string]$BuildReceipt
)
$ErrorActionPreference="Stop"
function RF([string]$p){return (Resolve-Path -LiteralPath $p -ErrorAction Stop).ProviderPath}
function RO([string]$p){return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)}
$candidates=@((Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"),(Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe"))
$csc=$candidates|Where-Object {Test-Path -LiteralPath $_ -PathType Leaf}|Select-Object -First 1
if(-not $csc){throw "R9B4_CSC_NOT_FOUND"}
$ms=RF $MediatorSource;$cs=RF $ChildSource;$vs=RF $VerifierSource
$me=RO $MediatorExe;$ce=RO $ChildExe;$ve=RO $VerifierExe;$br=RO $BuildReceipt
& $csc /nologo /target:exe /optimize+ /platform:anycpu ("/out:"+$ce) $cs
if($LASTEXITCODE -ne 0){throw "R9B4_CHILD_BUILD_FAILED"}
& $csc /nologo /target:exe /optimize+ /platform:anycpu ("/out:"+$me) /reference:System.Web.Extensions.dll $ms
if($LASTEXITCODE -ne 0){throw "R9B4_MEDIATOR_BUILD_FAILED"}
& $csc /nologo /target:exe /optimize+ /platform:anycpu ("/out:"+$ve) /reference:System.Web.Extensions.dll $vs
if($LASTEXITCODE -ne 0){throw "R9B4_VERIFIER_BUILD_FAILED"}
$doc=[ordered]@{
 schema_version="SYNAPSE-R9B4-BUILD-RECEIPT-1";status="CANDIDATE"
 mediator_source_sha256=(Get-FileHash -LiteralPath $ms -Algorithm SHA256).Hash.ToLowerInvariant()
 child_source_sha256=(Get-FileHash -LiteralPath $cs -Algorithm SHA256).Hash.ToLowerInvariant()
 verifier_source_sha256=(Get-FileHash -LiteralPath $vs -Algorithm SHA256).Hash.ToLowerInvariant()
 mediator_binary_sha256=(Get-FileHash -LiteralPath $me -Algorithm SHA256).Hash.ToLowerInvariant()
 child_binary_sha256=(Get-FileHash -LiteralPath $ce -Algorithm SHA256).Hash.ToLowerInvariant()
 verifier_binary_sha256=(Get-FileHash -LiteralPath $ve -Algorithm SHA256).Hash.ToLowerInvariant()
 mediator_binary_name=[IO.Path]::GetFileName($me);child_binary_name=[IO.Path]::GetFileName($ce);verifier_binary_name=[IO.Path]::GetFileName($ve)
 compiler_sha256=(Get-FileHash -LiteralPath $csc -Algorithm SHA256).Hash.ToLowerInvariant()
 compiler_kind="DOTNET_FRAMEWORK_CSC";deterministic_build_verified=$false
 authentication_result="NOT_PERFORMED";authorization_status="NOT_AUTHORIZED";authority_effect="NONE"
}
[IO.File]::WriteAllText($br,($doc|ConvertTo-Json -Depth 8),(New-Object Text.UTF8Encoding($false)))
Write-Host "R9B4_BUILD_CANDIDATE_READY";Write-Host "AUTHORITY_EFFECT=NONE"
