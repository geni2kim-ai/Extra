param(
 [Parameter(Mandatory=$true)][string]$MediatorExe,
 [Parameter(Mandatory=$true)][string]$VerifierExe,
 [Parameter(Mandatory=$true)][string]$VerifierSource,
 [Parameter(Mandatory=$true)][string]$BuildReceipt,
 [Parameter(Mandatory=$true)][string]$RegistryPath,
 [Parameter(Mandatory=$true)][string]$ExpectedRegistrySha256,
 [Parameter(Mandatory=$true)][string]$ExpectedMediatorSha256,
 [Parameter(Mandatory=$true)][string]$ExpectedVerifierBinarySha256,
 [Parameter(Mandatory=$true)][string]$ExpectedVerifierSourceSha256,
 [Parameter(Mandatory=$true)][string]$ExpectedBuildReceiptSha256,
 [Parameter(Mandatory=$true)][string]$OutputDirectory,
 [string]$PythonExe="python",
 [int]$ServerTimeoutMs=15000,
 [int]$ClientTimeoutMs=15000,
 [switch]$TestSuppressClientStart
)
$ErrorActionPreference="Stop"

function RF([string]$p){return (Resolve-Path -LiteralPath $p -ErrorAction Stop).ProviderPath}
function RO([string]$p){return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)}
function Q([string]$v){if($v.Contains('"')){throw "R9B4_QUOTE_IN_ARGUMENT_FORBIDDEN"};return '"'+$v+'"'}
function W([string]$p,[string]$s){[IO.File]::WriteAllText($p,$s,(New-Object Text.UTF8Encoding($false)))}
function Exit-Code-Or-Null($Process,[bool]$Started){
  if(-not $Started -or $null -eq $Process){return $null}
  try{if($Process.HasExited){return [int]$Process.ExitCode}}catch{}
  return $null
}
function Hash([string]$p){return (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash.ToLowerInvariant()}

$cleanupModule=RF (Join-Path $PSScriptRoot "R9B4Cleanup.psm1")
Import-Module $cleanupModule -Force

$mediator=RF $MediatorExe;$verifier=RF $VerifierExe;$verifierSource=RF $VerifierSource
$build=RF $BuildReceipt;$registry=RF $RegistryPath;$out=RO $OutputDirectory
[IO.Directory]::CreateDirectory($out)|Out-Null
$preflightScript=RF (Join-Path (Split-Path $PSScriptRoot -Parent) "preflight.py")
$preflightPath=Join-Path $out "R9B4_preflight.raw.json"
$preflightExecPath=Join-Path $out "preflight_execution.json"
$failurePath=Join-Path $out "harness_failure.json"

$preArgs=(
 (Q $preflightScript)+" --build-receipt "+(Q $build)+" --mediator-exe "+(Q $mediator)+" --registry "+(Q $registry)+
 " --verifier-exe "+(Q $verifier)+" --verifier-source "+(Q $verifierSource)+
 " --expected-registry-sha256 "+$ExpectedRegistrySha256+" --expected-mediator-sha256 "+$ExpectedMediatorSha256+
 " --expected-verifier-binary-sha256 "+$ExpectedVerifierBinarySha256+
 " --expected-verifier-source-sha256 "+$ExpectedVerifierSourceSha256+
 " --expected-build-receipt-sha256 "+$ExpectedBuildReceiptSha256+" -o "+(Q $preflightPath)
)
$psi=New-Object Diagnostics.ProcessStartInfo
$psi.FileName=$PythonExe;$psi.Arguments=$preArgs;$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true
$pp=New-Object Diagnostics.Process;$pp.StartInfo=$psi
if(-not $pp.Start()){throw "R9B4_PREFLIGHT_PROCESS_START_FAILED"}
$pot=$pp.StandardOutput.ReadToEndAsync();$pet=$pp.StandardError.ReadToEndAsync()
if(-not $pp.WaitForExit(15000)){try{$pp.Kill()}catch{};throw "R9B4_PREFLIGHT_PROCESS_TIMEOUT"}
$pp.WaitForExit();$preExit=[int]$pp.ExitCode;$preOut=$pot.GetAwaiter().GetResult();$preErr=$pet.GetAwaiter().GetResult();$pp.Dispose()
W (Join-Path $out "preflight.stdout.txt") $preOut;W (Join-Path $out "preflight.stderr.txt") $preErr
$preExec=[ordered]@{
 schema_version="SYNAPSE-R9B4-PREFLIGHT-EXECUTION-1";exit_code=$preExit;server_started=$false;client_started=$false
 stdout_sha256=Hash (Join-Path $out "preflight.stdout.txt");stderr_sha256=Hash (Join-Path $out "preflight.stderr.txt");authority_effect="NONE"
}
W $preflightExecPath (($preExec|ConvertTo-Json -Depth 6)+[Environment]::NewLine)
if($preExit -ne 0){
  $f=[ordered]@{schema_version="SYNAPSE-R9B4-HARNESS-FAILURE-1";code="R9B4_PREFLIGHT_DENIED";server_started=$false;client_started=$false
    preflight_exit_code=$preExit;cleanup_required=$false;authority_effect="NONE"}
  W $failurePath (($f|ConvertTo-Json -Depth 8)+[Environment]::NewLine)
  exit 2
}
$pf=Get-Content -LiteralPath $preflightPath -Raw|ConvertFrom-Json
if($pf.status -ne "PREFLIGHT_PASS"){throw "R9B4_PREFLIGHT_STATUS_INVALID"}

$preflightSha=Hash $preflightPath;$buildSha=Hash $build
$runId=[guid]::NewGuid().ToString("N");$nonce=[guid]::NewGuid().ToString("N")
$pipeName="synapse-r9b4-"+$runId;$sessionId="r9b4-session-"+$runId
$issued=[DateTime]::UtcNow;$expires=$issued.AddMinutes(3)
$ctxPath=Join-Path $out "R9B4_run_context.json"
$ctx=[ordered]@{
 schema_version="SYNAPSE-R9B4-RUN-CONTEXT-1";run_id=$runId;measurement_nonce=$nonce;pipe_name=$pipeName;node_session_id=$sessionId
 issued_at_utc=$issued.ToString("o");expires_at_utc=$expires.ToString("o")
 registry_sha256=$pf.registry_sha256;mediator_binary_sha256=$pf.mediator_binary_sha256
 verifier_binary_sha256=$pf.verifier_binary_sha256;verifier_source_sha256=$pf.verifier_source_sha256
 build_receipt_sha256=$buildSha;preflight_sha256=$preflightSha
 authentication_result="NOT_PERFORMED";authorization_status="NOT_AUTHORIZED";runtime_grant_issued=$false;g1_token_issued=$false;f2_unlocked=$false;authority_effect="NONE"
}
W $ctxPath (($ctx|ConvertTo-Json -Depth 8)+[Environment]::NewLine)
$ctxSha=Hash $ctxPath

$capturePath=Join-Path $out "R9B4_capture.raw.json";$completionPath=Join-Path $out "R9B4_server_completion.json"
$cleanupPath=Join-Path $out "cleanup_receipt.json";$summaryPath=Join-Path $out "measurement_harness_summary.json"
$serverOutPath=Join-Path $out "server.stdout.txt";$serverErrPath=Join-Path $out "server.stderr.txt"
$clientOutPath=Join-Path $out "client.stdout.txt";$clientErrPath=Join-Path $out "client.stderr.txt"
$serverExitPath=Join-Path $out "server.exitcode.txt";$clientExitPath=Join-Path $out "client.exitcode.txt"

$serverPsi=New-Object Diagnostics.ProcessStartInfo
$serverPsi.FileName=$verifier
$serverPsi.Arguments=(
 "--pipe "+$pipeName+" --allowed-sid "+$pf.allowed_user_sid+" --run-id "+$runId+" --session-id "+$sessionId+
 " --nonce "+$nonce+" --output "+(Q $capturePath)+" --completion "+(Q $completionPath)+
 " --preflight-sha256 "+$preflightSha+" --run-context-sha256 "+$ctxSha+" --build-receipt-sha256 "+$buildSha+
 " --verifier-source-sha256 "+$pf.verifier_source_sha256
)
$serverPsi.UseShellExecute=$false;$serverPsi.CreateNoWindow=$true;$serverPsi.RedirectStandardOutput=$true;$serverPsi.RedirectStandardError=$true
$clientPsi=New-Object Diagnostics.ProcessStartInfo
$clientPsi.FileName=$mediator;$clientPsi.Arguments="--measure-pipe "+$pipeName+" "+$nonce
$clientPsi.UseShellExecute=$false;$clientPsi.CreateNoWindow=$true;$clientPsi.RedirectStandardOutput=$true;$clientPsi.RedirectStandardError=$true

$server=New-Object Diagnostics.Process;$client=New-Object Diagnostics.Process
$server.StartInfo=$serverPsi;$client.StartInfo=$clientPsi
$serverStarted=$false;$clientStarted=$false;$serverStartTime=$null;$clientStartTime=$null
$serverOT=$null;$serverET=$null;$clientOT=$null;$clientET=$null
$failureCode=$null;$failureType=$null;$startedAt=[DateTime]::UtcNow
$serverPid=$null;$clientPid=$null;$captureSha=$null;$completionSha=$null
$cleanupStarted=$null;$cleanupCompleted=$null;$serverCleanup=$null;$clientCleanup=$null

try{
  $serverStarted=$server.Start();if(-not $serverStarted){throw "R9B4_SERVER_START_FAILED"}
  $serverPid=[int]$server.Id;$serverStartTime=$server.StartTime.ToUniversalTime().ToString("o")
  $serverOT=$server.StandardOutput.ReadToEndAsync();$serverET=$server.StandardError.ReadToEndAsync()

  if($TestSuppressClientStart){
    if(-not $server.WaitForExit($ServerTimeoutMs)){throw "R9B4_SERVER_TIMEOUT"}
    throw "R9B4_SERVER_EXITED_DURING_TIMEOUT_PROBE"
  }

  $clientStarted=$client.Start();if(-not $clientStarted){throw "R9B4_CLIENT_START_FAILED"}
  $clientPid=[int]$client.Id;$clientStartTime=$client.StartTime.ToUniversalTime().ToString("o")
  $clientOT=$client.StandardOutput.ReadToEndAsync();$clientET=$client.StandardError.ReadToEndAsync()

  if(-not $client.WaitForExit($ClientTimeoutMs)){throw "R9B4_CLIENT_TIMEOUT"};$client.WaitForExit()
  if(-not $server.WaitForExit($ServerTimeoutMs)){throw "R9B4_SERVER_TIMEOUT"};$server.WaitForExit()
  if([int]$client.ExitCode -ne 0){throw ("R9B4_CLIENT_EXIT_NONZERO_"+[int]$client.ExitCode)}
  if([int]$server.ExitCode -ne 0){throw ("R9B4_SERVER_EXIT_NONZERO_"+[int]$server.ExitCode)}
  if(-not(Test-Path -LiteralPath $capturePath -PathType Leaf)){throw "R9B4_CAPTURE_MISSING"}
  if(-not(Test-Path -LiteralPath $completionPath -PathType Leaf)){throw "R9B4_COMPLETION_MISSING"}
  $captureSha=Hash $capturePath;$completionSha=Hash $completionPath
}catch{
  $failureType=$_.Exception.GetType().Name;$message=[string]$_.Exception.Message
  if($message -cmatch '\AR9B4_[A-Z0-9_]+\z'){$failureCode=$message}else{$failureCode="R9B4_UNEXPECTED_HARNESS_ERROR"}
}finally{
  $cleanupStarted=[DateTime]::UtcNow
  if($clientStarted){$clientCleanup=Stop-R9B4ProcessTreeBounded -Process $client -Started $true -Role "client" -ExpectedStartTimeUtc $clientStartTime}
  else{$clientCleanup=[ordered]@{role="client";pid=$null;expected_start_time_utc=$null;same_instance_existed_before=$false;child_snapshot_status="NOT_RUN";child_pids_before=@();tree_kill_invoked=$false;tree_kill_method="NONE";taskkill_exit_code=$null;wait_for_exit_succeeded=$false;same_instance_exists_after=$false;pid_present_after=$false;pid_reused_after=$false;child_pids_remaining_after=@()}}
  if($serverStarted){$serverCleanup=Stop-R9B4ProcessTreeBounded -Process $server -Started $true -Role "server" -ExpectedStartTimeUtc $serverStartTime}
  else{$serverCleanup=[ordered]@{role="server";pid=$null;expected_start_time_utc=$null;same_instance_existed_before=$false;child_snapshot_status="NOT_RUN";child_pids_before=@();tree_kill_invoked=$false;tree_kill_method="NONE";taskkill_exit_code=$null;wait_for_exit_succeeded=$false;same_instance_exists_after=$false;pid_present_after=$false;pid_reused_after=$false;child_pids_remaining_after=@()}}
  $cleanupCompleted=[DateTime]::UtcNow

  $serverOut="";$serverErr="";$clientOut="";$clientErr=""
  try{if($serverOT){$serverOut=$serverOT.GetAwaiter().GetResult()}}catch{}
  try{if($serverET){$serverErr=$serverET.GetAwaiter().GetResult()}}catch{}
  try{if($clientOT){$clientOut=$clientOT.GetAwaiter().GetResult()}}catch{}
  try{if($clientET){$clientErr=$clientET.GetAwaiter().GetResult()}}catch{}
  W $serverOutPath $serverOut;W $serverErrPath $serverErr;W $clientOutPath $clientOut;W $clientErrPath $clientErr

  $serverExit=Exit-Code-Or-Null $server $serverStarted;$clientExit=Exit-Code-Or-Null $client $clientStarted
  if($null -eq $serverExit){W $serverExitPath ("NOT_AVAILABLE"+[Environment]::NewLine)}else{W $serverExitPath ([string]$serverExit+[Environment]::NewLine)}
  if($null -eq $clientExit){W $clientExitPath ("NOT_AVAILABLE"+[Environment]::NewLine)}else{W $clientExitPath ([string]$clientExit+[Environment]::NewLine)}

  $cleanupStatus="PROCESSES_TERMINATED"
  if($serverCleanup.same_instance_exists_after -or $clientCleanup.same_instance_exists_after){$cleanupStatus="RESIDUAL_PROCESS"}
  $cleanup=[ordered]@{
    schema_version="SYNAPSE-R9B4-CLEANUP-RECEIPT-1";status=$cleanupStatus;run_id=$runId
    started_at_utc=$cleanupStarted.ToString("o");completed_at_utc=$cleanupCompleted.ToString("o")
    server=$serverCleanup;client=$clientCleanup
    authentication_result="NOT_PERFORMED";authorization_status="NOT_AUTHORIZED";runtime_grant_issued=$false;g1_token_issued=$false;f2_unlocked=$false;authority_effect="NONE"
  }
  W $cleanupPath (($cleanup|ConvertTo-Json -Depth 12)+[Environment]::NewLine)
}

if($failureCode){
  $f=[ordered]@{
    schema_version="SYNAPSE-R9B4-HARNESS-FAILURE-1";code=$failureCode;failure_type=$failureType
    server_started=$serverStarted;client_started=$clientStarted;server_pid=$serverPid;client_pid=$clientPid
    server_start_time_utc=$serverStartTime;client_start_time_utc=$clientStartTime
    cleanup_receipt_sha256=Hash $cleanupPath
    server_stdout_sha256=Hash $serverOutPath;server_stderr_sha256=Hash $serverErrPath
    client_stdout_sha256=Hash $clientOutPath;client_stderr_sha256=Hash $clientErrPath
    authority_effect="NONE"
  }
  W $failurePath (($f|ConvertTo-Json -Depth 12)+[Environment]::NewLine)
  $client.Dispose();$server.Dispose()
  exit 2
}

$cleanupSha=Hash $cleanupPath
$postRegistry=Hash $registry;$postMediator=Hash $mediator;$postVerifier=Hash $verifier;$postSource=Hash $verifierSource;$postBuild=Hash $build
$postVerified=($postRegistry -ceq $ExpectedRegistrySha256 -and $postMediator -ceq $ExpectedMediatorSha256 -and
 $postVerifier -ceq $ExpectedVerifierBinarySha256 -and $postSource -ceq $ExpectedVerifierSourceSha256 -and
 $postBuild -ceq $ExpectedBuildReceiptSha256)
if(-not $postVerified){$client.Dispose();$server.Dispose();throw "R9B4_POST_RUN_SHA_MISMATCH"}

$completedAt=[DateTime]::UtcNow
$summary=[ordered]@{
 schema_version="SYNAPSE-R9B4-MEASUREMENT-HARNESS-1";status="CAPTURE_READY"
 run_id=$runId;measurement_nonce=$nonce;pipe_name=$pipeName;node_session_id=$sessionId
 started_at_utc=$startedAt.ToString("o");completed_at_utc=$completedAt.ToString("o")
 server_pid=$serverPid;client_pid=$clientPid;server_start_time_utc=$serverStartTime;client_start_time_utc=$clientStartTime
 run_context_sha256=$ctxSha;preflight_sha256=$preflightSha;build_receipt_sha256=$buildSha
 registry_sha256=$pf.registry_sha256;mediator_binary_sha256=$pf.mediator_binary_sha256
 verifier_binary_sha256=$pf.verifier_binary_sha256;verifier_source_sha256=$pf.verifier_source_sha256
 capture_sha256=$captureSha;completion_sha256=$completionSha;cleanup_sha256=$cleanupSha
 registry_input_unchanged=($postRegistry -ceq $pf.registry_sha256);post_run_hashes_verified=$postVerified
 post_run_registry_sha256=$postRegistry;post_run_mediator_sha256=$postMediator
 post_run_verifier_binary_sha256=$postVerifier;post_run_verifier_source_sha256=$postSource;post_run_build_receipt_sha256=$postBuild
 server_exit_code=[int]$server.ExitCode;client_exit_code=[int]$client.ExitCode
 authentication_result="NOT_PERFORMED";authorization_status="NOT_AUTHORIZED";runtime_grant_issued=$false;g1_token_issued=$false;f2_unlocked=$false;authority_effect="NONE"
}
W $summaryPath (($summary|ConvertTo-Json -Depth 12)+[Environment]::NewLine)
$client.Dispose();$server.Dispose()
Write-Host "R9B4_MEASUREMENT_CAPTURE_READY";Write-Host "AUTHORITY_EFFECT=NONE"
