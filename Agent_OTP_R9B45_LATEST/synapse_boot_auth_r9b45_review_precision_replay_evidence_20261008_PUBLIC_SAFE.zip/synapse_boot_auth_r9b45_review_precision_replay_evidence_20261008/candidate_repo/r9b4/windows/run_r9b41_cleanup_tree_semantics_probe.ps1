param(
 [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference="Stop"
function RF([string]$p){return (Resolve-Path -LiteralPath $p -ErrorAction Stop).ProviderPath}
function RO([string]$p){return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($p)}
$module=RF (Join-Path $PSScriptRoot "R9B4Cleanup.psm1")
Import-Module $module -Force
$out=RO $OutputDirectory
if(Test-Path -LiteralPath $out){Remove-Item -LiteralPath $out -Recurse -Force}
[IO.Directory]::CreateDirectory($out)|Out-Null
$script=Join-Path $out "parent_with_child.ps1"
@'
$child=Start-Process ping.exe -ArgumentList "127.0.0.1 -n 30" -PassThru -WindowStyle Hidden
while($true){Start-Sleep -Seconds 1}
'@ | Set-Content -LiteralPath $script -Encoding ASCII
$ps=(Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$parent=New-Object Diagnostics.Process
$psi=New-Object Diagnostics.ProcessStartInfo
$psi.FileName=$ps;$psi.Arguments=("-NoProfile -File `""+$script+"`"");$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
$parent.StartInfo=$psi
if(-not $parent.Start()){throw "R9B41_TREE_PROBE_PARENT_START_FAILED"}
$start=$parent.StartTime.ToUniversalTime().ToString("o")
Start-Sleep -Milliseconds 1200
$r=Stop-R9B4ProcessTreeBounded -Process $parent -Started $true -Role "tree_probe_parent" -ExpectedStartTimeUtc $start -WaitMilliseconds 3000
$parent.Dispose()
if($r.same_instance_existed_before -ne $true){throw "R9B41_TREE_PROBE_PARENT_NOT_ALIVE"}
if($r.child_snapshot_status -ne "AVAILABLE"){throw "R9B41_TREE_PROBE_CHILD_SNAPSHOT_UNAVAILABLE"}
if(@($r.child_pids_before).Count -lt 1){throw "R9B41_TREE_PROBE_NO_CHILD_OBSERVED"}
if($r.tree_kill_invoked -ne $true -or $r.taskkill_exit_code -ne 0){throw "R9B41_TREE_PROBE_TREE_KILL_FAILED"}
if($r.same_instance_exists_after -ne $false){throw "R9B41_TREE_PROBE_PARENT_REMAINS"}
if(@($r.child_pids_remaining_after).Count -ne 0){throw "R9B41_TREE_PROBE_CHILD_REMAINS"}
$receipt=[ordered]@{
 schema_version="SYNAPSE-R9B41-CLEANUP-TREE-SEMANTICS-PROBE-1";status="PASS"
 parent=$r;authority_effect="NONE"
}
$receipt|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $out "cleanup_tree_probe_receipt.json") -Encoding UTF8
Write-Host "R9B41_CLEANUP_TREE_SEMANTICS_PASS"
