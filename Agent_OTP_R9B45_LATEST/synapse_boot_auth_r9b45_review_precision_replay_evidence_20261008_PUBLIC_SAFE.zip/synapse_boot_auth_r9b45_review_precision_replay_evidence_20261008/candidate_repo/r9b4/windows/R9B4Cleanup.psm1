Set-StrictMode -Version 2.0

function Get-R9B4ProcessStartTimeUtc {
    param([Parameter(Mandatory=$true)][int]$ProcessId)
    try {
        $proc=[Diagnostics.Process]::GetProcessById($ProcessId)
        try { return $proc.StartTime.ToUniversalTime().ToString("o") }
        finally { $proc.Dispose() }
    } catch { return $null }
}

function Test-R9B4SameProcessInstance {
    param(
        [Parameter(Mandatory=$true)][int]$ProcessId,
        [Parameter(Mandatory=$true)][string]$ExpectedStartTimeUtc
    )
    $actual=Get-R9B4ProcessStartTimeUtc -ProcessId $ProcessId
    if($null -eq $actual){ return $false }
    return $actual -ceq $ExpectedStartTimeUtc
}

function Get-R9B4DescendantPids {
    param([Parameter(Mandatory=$true)][int]$RootProcessId)
    try {
        $all=@(Get-CimInstance Win32_Process -ErrorAction Stop | Select-Object ProcessId,ParentProcessId)
        $found=New-Object 'System.Collections.Generic.List[int]'
        $frontier=New-Object 'System.Collections.Generic.List[int]'
        $frontier.Add($RootProcessId)
        for($i=0;$i -lt $frontier.Count;$i++){
            $parent=$frontier[$i]
            foreach($row in $all){
                if([int]$row.ParentProcessId -eq $parent){
                    $child=[int]$row.ProcessId
                    if(-not $found.Contains($child)){
                        $found.Add($child);$frontier.Add($child)
                    }
                }
            }
        }
        return [ordered]@{status="AVAILABLE";pids=@($found)}
    } catch {
        return [ordered]@{status="UNAVAILABLE";pids=@()}
    }
}

function Stop-R9B4ProcessTreeBounded {
    param(
        [Parameter(Mandatory=$true)]$Process,
        [Parameter(Mandatory=$true)][bool]$Started,
        [Parameter(Mandatory=$true)][string]$Role,
        [Parameter(Mandatory=$true)][string]$ExpectedStartTimeUtc,
        [int]$WaitMilliseconds=2000
    )
    $result=[ordered]@{
        role=$Role;pid=$null;expected_start_time_utc=$ExpectedStartTimeUtc
        same_instance_existed_before=$false
        child_snapshot_status="NOT_RUN";child_pids_before=@()
        tree_kill_invoked=$false;tree_kill_method="NONE";taskkill_exit_code=$null
        wait_for_exit_succeeded=$false
        same_instance_exists_after=$false
        pid_present_after=$false;pid_reused_after=$false
        child_pids_remaining_after=@()
    }
    if(-not $Started -or $null -eq $Process){ return $result }
    $processId=[int]$Process.Id;$result.pid=$processId
    $result.same_instance_existed_before=Test-R9B4SameProcessInstance -ProcessId $processId -ExpectedStartTimeUtc $ExpectedStartTimeUtc
    $children=Get-R9B4DescendantPids -RootProcessId $processId
    $result.child_snapshot_status=$children.status;$result.child_pids_before=@($children.pids)

    if($result.same_instance_existed_before){
        $result.tree_kill_invoked=$true;$result.tree_kill_method="TASKKILL_PID_TREE_FORCE"
        try {
            $taskkill=(Get-Command taskkill.exe -CommandType Application -ErrorAction Stop).Source
            $psi=New-Object Diagnostics.ProcessStartInfo
            $psi.FileName=$taskkill;$psi.Arguments=("/PID "+$processId+" /T /F")
            $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
            $tp=New-Object Diagnostics.Process;$tp.StartInfo=$psi
            try {
                if($tp.Start()){
                    if($tp.WaitForExit(5000)){$result.taskkill_exit_code=[int]$tp.ExitCode}
                }
            } finally { $tp.Dispose() }
        } catch {}
    }

    try { $result.wait_for_exit_succeeded=[bool]$Process.WaitForExit($WaitMilliseconds) } catch {}

    $actualStart=Get-R9B4ProcessStartTimeUtc -ProcessId $processId
    $result.pid_present_after=($null -ne $actualStart)
    if($result.pid_present_after){
        $result.same_instance_exists_after=($actualStart -ceq $ExpectedStartTimeUtc)
        $result.pid_reused_after=($actualStart -cne $ExpectedStartTimeUtc)
    }

    $remaining=New-Object 'System.Collections.Generic.List[int]'
    foreach($childId in @($result.child_pids_before)){
        try {
            $cp=[Diagnostics.Process]::GetProcessById([int]$childId)
            try { if(-not $cp.HasExited){$remaining.Add([int]$childId)} }
            finally {$cp.Dispose()}
        } catch {}
    }
    $result.child_pids_remaining_after=@($remaining)
    return $result
}

Export-ModuleMember -Function Get-R9B4ProcessStartTimeUtc,Test-R9B4SameProcessInstance,Get-R9B4DescendantPids,Stop-R9B4ProcessTreeBounded
