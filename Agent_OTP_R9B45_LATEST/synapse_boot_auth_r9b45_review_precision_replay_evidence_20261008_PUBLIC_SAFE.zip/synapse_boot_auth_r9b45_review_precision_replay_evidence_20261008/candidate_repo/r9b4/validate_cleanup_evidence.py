#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from typing import Any

class Invalid(RuntimeError): pass

def load(path:Path)->dict[str,Any]:
    obj=json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(obj,dict):raise Invalid("TOP_LEVEL_NOT_OBJECT")
    return obj

def proc(p:dict[str,Any],role:str,require_started:bool,require_children_before:bool=False)->None:
    if require_started:
        if not isinstance(p.get("pid"),int):raise Invalid(role+"_PID_INVALID")
        if p.get("same_instance_existed_before") is not True:raise Invalid(role+"_NOT_ALIVE_BEFORE_CLEANUP")
        if p.get("tree_kill_invoked") is not True:raise Invalid(role+"_TREE_KILL_NOT_INVOKED")
        if p.get("tree_kill_method")!="TASKKILL_PID_TREE_FORCE":raise Invalid(role+"_TREE_KILL_METHOD_INVALID")
        if p.get("taskkill_exit_code")!=0:raise Invalid(role+"_TASKKILL_FAILED")
        if p.get("wait_for_exit_succeeded") is not True:raise Invalid(role+"_WAIT_NOT_CONFIRMED")
        if p.get("same_instance_exists_after") is not False:raise Invalid(role+"_RESIDUAL_PROCESS")
        if p.get("pid_reused_after") is not False:raise Invalid(role+"_PID_REUSED")
        if p.get("child_snapshot_status")!="AVAILABLE":raise Invalid(role+"_CHILD_SNAPSHOT_UNAVAILABLE")
        before=p.get("child_pids_before")
        after=p.get("child_pids_remaining_after")
        if not isinstance(before,list) or not isinstance(after,list):raise Invalid(role+"_CHILD_LIST_INVALID")
        if require_children_before and len(before)<1:raise Invalid(role+"_NO_CHILD_OBSERVED")
        if after:raise Invalid(role+"_CHILD_PROCESS_REMAINS")
    else:
        if p.get("pid") is not None:raise Invalid(role+"_UNEXPECTED_PID")
        if p.get("same_instance_existed_before") is not False:raise Invalid(role+"_UNEXPECTED_EXISTENCE")
        if p.get("tree_kill_invoked") is not False:raise Invalid(role+"_UNEXPECTED_TREE_KILL")
        if p.get("same_instance_exists_after") is not False:raise Invalid(role+"_UNEXPECTED_RESIDUAL")

def main()->int:
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="mode",required=True)
    a=sub.add_parser("timeout");a.add_argument("cleanup");a.add_argument("failure")
    b=sub.add_parser("tree");b.add_argument("receipt")
    c=sub.add_parser("wrongsid");c.add_argument("cleanup");c.add_argument("failure")
    ns=ap.parse_args()
    try:
        if ns.mode=="timeout":
            cleanup=load(Path(ns.cleanup));failure=load(Path(ns.failure))
            if failure.get("code")!="R9B4_SERVER_TIMEOUT":raise Invalid("TIMEOUT_FAILURE_CODE_INVALID")
            if failure.get("server_started") is not True or failure.get("client_started") is not False:raise Invalid("TIMEOUT_START_STATE_INVALID")
            if cleanup.get("status")!="PROCESSES_TERMINATED":raise Invalid("TIMEOUT_CLEANUP_STATUS_INVALID")
            proc(cleanup["server"],"SERVER",True,False);proc(cleanup["client"],"CLIENT",False,False)
        elif ns.mode=="tree":
            receipt=load(Path(ns.receipt))
            if receipt.get("status")!="PASS":raise Invalid("TREE_PROBE_STATUS_INVALID")
            proc(receipt["parent"],"PARENT",True,True)
        else:
            cleanup=load(Path(ns.cleanup));failure=load(Path(ns.failure))
            if failure.get("server_started") is not True or failure.get("client_started") is not True:raise Invalid("WRONGSID_START_STATE_INVALID")
            if cleanup.get("status")!="PROCESSES_TERMINATED":raise Invalid("WRONGSID_CLEANUP_STATUS_INVALID")
            # Wrong-SID path can self-terminate before cleanup helper observes existence.
            for role in ("server","client"):
                p=cleanup[role]
                if not isinstance(p.get("pid"),int):raise Invalid(role.upper()+"_PID_INVALID")
                if p.get("wait_for_exit_succeeded") is not True:raise Invalid(role.upper()+"_WAIT_NOT_CONFIRMED")
                if p.get("same_instance_exists_after") is not False:raise Invalid(role.upper()+"_RESIDUAL_PROCESS")
                if p.get("pid_reused_after") is not False:raise Invalid(role.upper()+"_PID_REUSED")
                if p.get("child_snapshot_status")!="AVAILABLE":raise Invalid(role.upper()+"_CHILD_SNAPSHOT_UNAVAILABLE")
                if p.get("child_pids_remaining_after")!=[]:raise Invalid(role.upper()+"_CHILD_PROCESS_REMAINS")
        print(json.dumps({"status":"PASS","mode":ns.mode,"authority_effect":"NONE"}))
        return 0
    except (Invalid,KeyError,TypeError,ValueError) as e:
        print(json.dumps({"status":"DENIED","code":str(e),"authority_effect":"NONE"}))
        return 2

if __name__=="__main__":raise SystemExit(main())
