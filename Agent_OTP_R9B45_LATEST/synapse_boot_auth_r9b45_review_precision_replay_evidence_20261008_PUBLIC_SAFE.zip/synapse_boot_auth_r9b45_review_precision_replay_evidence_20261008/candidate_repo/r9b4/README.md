# R9B.4.4 — HUMAN review completeness + cleanup-verifier hardening

R9B.4.4 does not change the Windows measurement producer protocol.

It addresses the non-authoritative HUMAN packet review:

- strengthens successful cleanup validation:
  - same process instance must be absent after cleanup;
  - PID reuse must not be observed;
  - bounded wait must be confirmed;
  - child snapshot must be available;
  - zero child PIDs may remain;
  - tree-kill fields must be internally consistent;
- adds `validate_cleanup_evidence.py` for timeout/tree/wrong-SID probe receipts;
- packages exact evaluator/verifier/harness/replay/mediator/child source for HUMAN reproduction;
- packages R9B.4.2 runtime evidence supplement for replay, timeout, tree cleanup and wrong-SID;
- corrects V2 question traceability;
- documents R9B.4.1 -> R9B.4.2 verifier PID lineage;
- distinguishes server-observed measurements from pass-through bound inputs;
- enumerates derived review-safe rebinding fields;
- describes the external GitHub anchor as producer-owned immutable publication, not independent attestation.

R9B.4.2 Windows measurement does not need to be repeated merely because of this review/evaluator hardening.
The HUMAN reviewer must still return an explicit verdict before R9C design may begin.

Security ceiling remains:
`MEASURED_NOT_AUTHENTICATED / UNBOUND / NOT_AUTHORIZED / NONE`.
