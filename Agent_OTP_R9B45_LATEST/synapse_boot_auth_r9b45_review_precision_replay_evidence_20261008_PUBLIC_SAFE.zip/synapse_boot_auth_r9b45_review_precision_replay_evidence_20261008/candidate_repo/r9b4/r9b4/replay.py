from __future__ import annotations
import hashlib,json,os
from datetime import datetime,timezone
from pathlib import Path
from .common import Denied

def token_key(run_id:str,nonce:str)->str:
    return hashlib.sha256((run_id+"\0"+nonce).encode("utf-8")).hexdigest()

def consume(run_id:str,nonce:str,ledger_dir:Path)->dict[str,object]:
    ledger_dir.mkdir(parents=True,exist_ok=True)
    key=token_key(run_id,nonce)
    path=ledger_dir/(key+".consumed.json")
    payload={
      "schema_version":"SYNAPSE-R9B4-REPLAY-CONSUMPTION-1",
      "token_sha256":key,
      "consumed_at_utc":datetime.now(timezone.utc).isoformat(),
      "authority_effect":"NONE"
    }
    try:
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    except FileExistsError as exc:
        raise Denied("RUN_TOKEN_ALREADY_CONSUMED") from exc
    try:
        with os.fdopen(fd,"w",encoding="utf-8",newline="\n") as f:
            json.dump(payload,f,indent=2);f.write("\n");f.flush();os.fsync(f.fileno())
    except Exception:
        try:path.unlink()
        except Exception:pass
        raise
    return {"token_sha256":key,"ledger_record_name":path.name,"consumed_at_utc":payload["consumed_at_utc"]}
