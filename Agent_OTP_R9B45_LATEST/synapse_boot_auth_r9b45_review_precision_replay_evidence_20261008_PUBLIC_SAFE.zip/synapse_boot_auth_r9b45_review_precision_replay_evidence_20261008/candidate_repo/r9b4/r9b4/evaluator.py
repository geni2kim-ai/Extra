from __future__ import annotations
from datetime import datetime,timezone,timedelta
from pathlib import PureWindowsPath
from typing import Any
from .common import Denied,require_hex64,require_sid,require_workload

def obj(v:object,code:str)->dict[str,Any]:
    if not isinstance(v,dict):raise Denied(code)
    return v
def arr(v:object,code:str)->list[Any]:
    if not isinstance(v,list):raise Denied(code)
    return v
def text(v:object,code:str)->str:
    if not isinstance(v,str) or not v:raise Denied(code)
    return v
def integer(v:object,code:str)->int:
    if not isinstance(v,int) or isinstance(v,bool):raise Denied(code)
    return v
def parse_time(v:object,code:str)->datetime:
    s=text(v,code)
    try:d=datetime.fromisoformat(s.replace("Z","+00:00"))
    except Exception as exc:raise Denied(code) from exc
    if d.tzinfo is None:raise Denied(code)
    return d.astimezone(timezone.utc)
def filetime_utc(v:object,code:str)->datetime:
    ticks=integer(v,code)
    if ticks<=0:raise Denied(code)
    try:return datetime(1601,1,1,tzinfo=timezone.utc)+timedelta(microseconds=ticks//10)
    except Exception as exc:raise Denied(code) from exc

def _authority_ceiling(name:str,d:dict[str,Any],authn:str|None,authz:str|None)->None:
    if d.get("authority_effect")!="NONE":raise Denied(name+"_AUTHORITY_EFFECT_NOT_NONE")
    if authn is not None and d.get("authentication_result")!=authn:raise Denied(name+"_AUTHENTICATION_PRECLAIMED")
    if authz is not None and d.get("authorization_status")!=authz:raise Denied(name+"_AUTHORIZATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if d.get(k,False) is not False:raise Denied(name+"_"+k.upper()+"_PRECLAIMED")

def evaluate(
    capture:dict[str,Any],build:dict[str,Any],registry:dict[str,Any],preflight:dict[str,Any],
    run_context:dict[str,Any],harness:dict[str,Any],completion:dict[str,Any],cleanup:dict[str,Any],
    hashes:dict[str,str],now_utc:datetime,require_fresh:bool
)->dict[str,Any]:
    expected_schemas={
      "capture":"SYNAPSE-R9B4-NAMED-PIPE-CAPTURE-1","build":"SYNAPSE-R9B4-BUILD-RECEIPT-1",
      "registry":"SYNAPSE-R9B4-PREPROVISIONED-VERIFIER-REGISTRY-1","preflight":"SYNAPSE-R9B4-PREFLIGHT-1",
      "run_context":"SYNAPSE-R9B4-RUN-CONTEXT-1","harness":"SYNAPSE-R9B4-MEASUREMENT-HARNESS-1",
      "completion":"SYNAPSE-R9B4-SERVER-COMPLETION-1","cleanup":"SYNAPSE-R9B4-CLEANUP-RECEIPT-1",
    }
    docs={"capture":capture,"build":build,"registry":registry,"preflight":preflight,
          "run_context":run_context,"harness":harness,"completion":completion,"cleanup":cleanup}
    for n,sv in expected_schemas.items():
        if docs[n].get("schema_version")!=sv:raise Denied(n.upper()+"_SCHEMA_INVALID")

    _authority_ceiling("CAPTURE",capture,"CAPTURE_ONLY","NOT_AUTHORIZED")
    _authority_ceiling("BUILD",build,"NOT_PERFORMED","NOT_AUTHORIZED")
    _authority_ceiling("REGISTRY",registry,"NOT_PERFORMED","NOT_AUTHORIZED")
    _authority_ceiling("PREFLIGHT",preflight,"NOT_PERFORMED","NOT_AUTHORIZED")
    _authority_ceiling("RUN_CONTEXT",run_context,"NOT_PERFORMED","NOT_AUTHORIZED")
    _authority_ceiling("HARNESS",harness,"NOT_PERFORMED","NOT_AUTHORIZED")
    _authority_ceiling("COMPLETION",completion,"CAPTURE_ONLY","NOT_AUTHORIZED")
    _authority_ceiling("CLEANUP",cleanup,"NOT_PERFORMED","NOT_AUTHORIZED")

    expected={}
    for k in ("registry","mediator","verifier_binary","verifier_source","build_receipt"):
        expected[k]=require_hex64(hashes.get("expected_"+k+"_sha256"),"EXPECTED_"+k.upper()+"_SHA_INVALID")
        if hashes.get(k+"_sha256")!=expected[k]:raise Denied(k.upper()+"_EXTERNAL_SHA_MISMATCH")

    if preflight.get("status")!="PREFLIGHT_PASS":raise Denied("PREFLIGHT_STATUS_INVALID")
    preflight_fields={"registry":"registry_sha256","mediator":"mediator_binary_sha256",
      "verifier_binary":"verifier_binary_sha256","verifier_source":"verifier_source_sha256","build_receipt":"build_receipt_sha256"}
    for k,field in preflight_fields.items():
        if preflight.get(field)!=expected[k]:raise Denied("PREFLIGHT_"+field.upper()+"_MISMATCH")
    preflight_sha=require_hex64(hashes.get("preflight_sha256"),"PREFLIGHT_SHA_INVALID")
    run_context_sha=require_hex64(hashes.get("run_context_sha256"),"RUN_CONTEXT_SHA_INVALID")
    capture_sha=require_hex64(hashes.get("capture_sha256"),"CAPTURE_SHA_INVALID")
    completion_sha=require_hex64(hashes.get("completion_sha256"),"COMPLETION_SHA_INVALID")
    cleanup_sha=require_hex64(hashes.get("cleanup_sha256"),"CLEANUP_SHA_INVALID")

    if build.get("mediator_binary_sha256")!=expected["mediator"]:raise Denied("BUILD_MEDIATOR_SHA_MISMATCH")
    if build.get("verifier_binary_sha256")!=expected["verifier_binary"]:raise Denied("BUILD_VERIFIER_BINARY_SHA_MISMATCH")
    if build.get("verifier_source_sha256")!=expected["verifier_source"]:raise Denied("BUILD_VERIFIER_SOURCE_SHA_MISMATCH")
    if hashes.get("build_receipt_sha256")!=expected["build_receipt"]:raise Denied("BUILD_RECEIPT_EXTERNAL_SHA_MISMATCH")
    if registry.get("registry_trust")!="PREPROVISIONED_REHEARSAL_ONLY":raise Denied("REGISTRY_TRUST_INVALID")

    run_id=text(run_context.get("run_id"),"RUN_ID_INVALID");nonce=text(run_context.get("measurement_nonce"),"RUN_NONCE_INVALID")
    pipe_name=text(run_context.get("pipe_name"),"RUN_PIPE_INVALID");session_id=text(run_context.get("node_session_id"),"RUN_SESSION_INVALID")
    if len(run_id)!=32 or len(nonce)!=32:raise Denied("RUN_TOKEN_FORMAT_INVALID")
    for f,e in (("registry_sha256",expected["registry"]),("mediator_binary_sha256",expected["mediator"]),
      ("verifier_binary_sha256",expected["verifier_binary"]),("verifier_source_sha256",expected["verifier_source"]),
      ("build_receipt_sha256",expected["build_receipt"]),("preflight_sha256",preflight_sha)):
        if run_context.get(f)!=e:raise Denied("RUN_CONTEXT_"+f.upper()+"_MISMATCH")

    if harness.get("status")!="CAPTURE_READY":raise Denied("HARNESS_STATUS_INVALID")
    for f,e in (("run_id",run_id),("measurement_nonce",nonce),("pipe_name",pipe_name),("node_session_id",session_id),
      ("run_context_sha256",run_context_sha),("preflight_sha256",preflight_sha),("build_receipt_sha256",expected["build_receipt"]),
      ("registry_sha256",expected["registry"]),("mediator_binary_sha256",expected["mediator"]),
      ("verifier_binary_sha256",expected["verifier_binary"]),("verifier_source_sha256",expected["verifier_source"]),
      ("capture_sha256",capture_sha),("completion_sha256",completion_sha),("cleanup_sha256",cleanup_sha)):
        if harness.get(f)!=e:raise Denied("HARNESS_"+f.upper()+"_MISMATCH")
    if harness.get("registry_input_unchanged") is not True:raise Denied("REGISTRY_INPUT_CHANGED")
    if harness.get("post_run_hashes_verified") is not True:raise Denied("POST_RUN_HASHES_NOT_VERIFIED")
    for f,e in (("post_run_registry_sha256",expected["registry"]),("post_run_mediator_sha256",expected["mediator"]),
                ("post_run_verifier_binary_sha256",expected["verifier_binary"]),
                ("post_run_verifier_source_sha256",expected["verifier_source"]),
                ("post_run_build_receipt_sha256",expected["build_receipt"])):
        if harness.get(f)!=e:raise Denied("HARNESS_"+f.upper()+"_MISMATCH")
    if integer(harness.get("server_exit_code"),"SERVER_EXIT_INVALID")!=0 or integer(harness.get("client_exit_code"),"CLIENT_EXIT_INVALID")!=0:
        raise Denied("HARNESS_PROCESS_EXIT_NONZERO")
    server_pid=integer(harness.get("server_pid"),"HARNESS_SERVER_PID_INVALID")
    client_pid=integer(harness.get("client_pid"),"HARNESS_CLIENT_PID_INVALID")

    if capture.get("run_id")!=run_id:raise Denied("CAPTURE_RUN_ID_MISMATCH")
    if capture.get("captured_node_session_id")!=session_id:raise Denied("CAPTURE_SESSION_MISMATCH")
    pipe=obj(capture.get("pipe"),"PIPE_NOT_OBJECT")
    if pipe.get("name")!=pipe_name:raise Denied("CAPTURE_PIPE_MISMATCH")
    claims=obj(capture.get("caller_claims"),"CALLER_CLAIMS_NOT_OBJECT")
    if claims.get("claimed_node_id") is not None or claims.get("claimed_workload_id") is not None:raise Denied("CLIENT_IDENTITY_CLAIMS_MUST_BE_ABSENT")
    if claims.get("measurement_nonce")!=nonce:raise Denied("CAPTURE_NONCE_MISMATCH")
    client=obj(capture.get("client"),"CLIENT_NOT_OBJECT")
    if integer(client.get("pid"),"CLIENT_PID_INVALID")!=client_pid:raise Denied("HARNESS_CAPTURE_CLIENT_PID_MISMATCH")
    if integer(client.get("pid_rechecked"),"CLIENT_PID_RECHECK_INVALID")!=client_pid:raise Denied("PIPE_CLIENT_PID_RECHECK_MISMATCH")
    if client.get("process_creation_time_100ns")!=client.get("process_creation_time_rechecked_100ns"):raise Denied("CLIENT_INSTANCE_RECHECK_FAILED")
    p1=text(client.get("process_path"),"CLIENT_PATH_INVALID");p2=text(client.get("process_path_rechecked"),"CLIENT_PATH_RECHECK_INVALID")
    if p1.casefold()!=p2.casefold():raise Denied("CLIENT_PATH_RECHECK_FAILED")
    if client.get("process_active_after_capture") is not True:raise Denied("CLIENT_NOT_ACTIVE")
    if client.get("process_sha256_semantics")!="ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH":raise Denied("PROCESS_SHA_SEMANTICS_INVALID")
    if client.get("loaded_image_hash_verified") is not False:raise Denied("LOADED_IMAGE_HASH_CLAIM_INVALID")
    if capture.get("evidence_source")!="PIPE_PID_BEFORE_FRAME+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK":
        raise Denied("EVIDENCE_SOURCE_INVALID")
    observed=require_hex64(client.get("process_sha256"),"CLIENT_SHA_INVALID")
    if observed!=expected["mediator"]:raise Denied("MEDIATOR_BINARY_SHA_MISMATCH")
    if PureWindowsPath(p1).name.casefold()!=str(build.get("mediator_binary_name","")).casefold():raise Denied("MEDIATOR_BINARY_NAME_MISMATCH")
    verifier=obj(capture.get("verifier"),"VERIFIER_NOT_OBJECT")
    if integer(verifier.get("pid"),"CAPTURE_VERIFIER_PID_INVALID")!=server_pid:raise Denied("HARNESS_CAPTURE_SERVER_PID_MISMATCH")
    if verifier.get("binary_sha256")!=expected["verifier_binary"]:raise Denied("CAPTURE_VERIFIER_BINARY_SHA_MISMATCH")
    if verifier.get("source_sha256")!=expected["verifier_source"]:raise Denied("CAPTURE_VERIFIER_SOURCE_SHA_MISMATCH")
    if capture.get("preflight_sha256")!=preflight_sha or capture.get("run_context_sha256")!=run_context_sha or capture.get("build_receipt_sha256")!=expected["build_receipt"]:
        raise Denied("CAPTURE_META_BINDING_MISMATCH")

    token=obj(capture.get("token"),"TOKEN_NOT_OBJECT")
    sid=require_sid(token.get("user_sid"),"CLIENT_SID_INVALID")
    if token.get("impersonation_succeeded") is not True:raise Denied("CLIENT_IMPERSONATION_REQUIRED")
    if token.get("token_source")!="ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)":raise Denied("TOKEN_SOURCE_INVALID")
    if pipe.get("allowed_client_sid")!=sid:raise Denied("PIPE_ALLOWED_SID_MISMATCH")
    entries=arr(registry.get("entries"),"REGISTRY_ENTRIES_INVALID")
    found=[e for e in entries if isinstance(e,dict) and e.get("mediator_binary_sha256")==observed and e.get("allowed_user_sid")==sid]
    if len(found)!=1:raise Denied("REGISTRY_MATCH_NOT_UNIQUE")
    workload=require_workload(found[0].get("derived_workload_id"),"DERIVED_WORKLOAD_ID_INVALID")

    if completion.get("status")!="SERVER_CAPTURE_COMPLETE":raise Denied("COMPLETION_STATUS_INVALID")
    if integer(completion.get("verifier_pid"),"COMPLETION_VERIFIER_PID_INVALID")!=server_pid:
        raise Denied("COMPLETION_VERIFIER_PID_MISMATCH")
    for f,e in (("run_id",run_id),("pipe_name",pipe_name),("node_session_id",session_id),("measurement_nonce",nonce),
      ("capture_sha256",capture_sha),("verifier_binary_sha256",expected["verifier_binary"]),
      ("verifier_source_sha256",expected["verifier_source"]),("preflight_sha256",preflight_sha),
      ("run_context_sha256",run_context_sha),("build_receipt_sha256",expected["build_receipt"])):
        if completion.get(f)!=e:raise Denied("COMPLETION_"+f.upper()+"_MISMATCH")
    if completion.get("server_instance_id")!=pipe.get("server_instance_id"):raise Denied("COMPLETION_SERVER_INSTANCE_MISMATCH")

    if cleanup.get("status")!="PROCESSES_TERMINATED":raise Denied("CLEANUP_STATUS_INVALID")
    if cleanup.get("run_id")!=run_id:raise Denied("CLEANUP_RUN_ID_MISMATCH")
    cleanup_started=parse_time(cleanup.get("started_at_utc"),"CLEANUP_START_TIME_INVALID")
    cleanup_completed=parse_time(cleanup.get("completed_at_utc"),"CLEANUP_COMPLETION_TIME_INVALID")
    for n,pid in (("server",server_pid),("client",client_pid)):
        c=obj(cleanup.get(n),"CLEANUP_"+n.upper()+"_INVALID")
        prefix="CLEANUP_"+n.upper()+"_"
        if integer(c.get("pid"),prefix+"PID_INVALID")!=pid:raise Denied(prefix+"PID_MISMATCH")
        if c.get("same_instance_exists_after") is not False:raise Denied(prefix+"RESIDUAL_PROCESS")
        if c.get("pid_reused_after") is not False:raise Denied(prefix+"PID_REUSE_OBSERVED")
        if c.get("wait_for_exit_succeeded") is not True:raise Denied(prefix+"WAIT_NOT_CONFIRMED")
        if c.get("child_snapshot_status")!="AVAILABLE":raise Denied(prefix+"CHILD_SNAPSHOT_UNAVAILABLE")
        children_after=c.get("child_pids_remaining_after")
        if not isinstance(children_after,list):raise Denied(prefix+"CHILD_REMAINDER_INVALID")
        if len(children_after)!=0:raise Denied(prefix+"CHILD_PROCESS_REMAINS")
        killed=c.get("tree_kill_invoked")
        method=c.get("tree_kill_method")
        kill_code=c.get("taskkill_exit_code")
        existed=c.get("same_instance_existed_before")
        if existed is True:
            if killed is not True:raise Denied(prefix+"EXPECTED_TREE_KILL_MISSING")
            if method!="TASKKILL_PID_TREE_FORCE":raise Denied(prefix+"TREE_KILL_METHOD_INVALID")
            if integer(kill_code,prefix+"TASKKILL_EXIT_INVALID")!=0:raise Denied(prefix+"TASKKILL_FAILED")
        elif existed is False:
            if killed is not False:raise Denied(prefix+"UNEXPECTED_TREE_KILL")
            if method!="NONE":raise Denied(prefix+"TREE_KILL_METHOD_INVALID")
            if kill_code is not None:raise Denied(prefix+"UNEXPECTED_TASKKILL_EXIT")
        else:
            raise Denied(prefix+"EXISTED_BEFORE_INVALID")

    issued=parse_time(run_context.get("issued_at_utc"),"RUN_ISSUED_TIME_INVALID")
    expires=parse_time(run_context.get("expires_at_utc"),"RUN_EXPIRES_TIME_INVALID")
    hstart=parse_time(harness.get("started_at_utc"),"HARNESS_START_TIME_INVALID")
    captured=parse_time(capture.get("captured_at_utc"),"CAPTURE_TIME_INVALID")
    completed=parse_time(completion.get("completed_at_utc"),"COMPLETION_TIME_INVALID")
    hend=parse_time(harness.get("completed_at_utc"),"HARNESS_END_TIME_INVALID")
    created=filetime_utc(client.get("process_creation_time_100ns"),"CLIENT_CREATION_TIME_INVALID")
    if expires<=issued or (expires-issued).total_seconds()>180:raise Denied("RUN_WINDOW_INVALID")
    if not (issued<=hstart<=created<=captured<=completed<=cleanup_started<=cleanup_completed<=hend<=expires):raise Denied("RUN_TIME_ORDER_INVALID")
    now=now_utc.astimezone(timezone.utc);fresh=issued<=now<=expires
    if require_fresh and not fresh:raise Denied("RUN_CONTEXT_NOT_FRESH_AT_EVALUATION")

    return {
      "result":"R9B4_FRESHNESS_BOUND_MEASUREMENT_READY" if require_fresh else "R9B4_OFFLINE_ARTIFACT_SET_BOUND",
      "derived_workload_id":workload,
      "run_binding":"RUN_ID+PIPE+SESSION+NONCE+PREFLIGHT+BUILD+CLIENT_PID+CAPTURE+COMPLETION+CLEANUP+POST_HASH",
      "authority_ceiling_validated":True,
      "fresh_at_evaluation":fresh,"evaluation_time_utc":now.isoformat(),"measurement_result":"MEASURED",
      "authentication_result":"MEASURED_NOT_AUTHENTICATED","stable_node_id":"UNBOUND","authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE",
      "loaded_image_hash_verified":False,"review_gate":"HUMAN_REQUIRED_V26","r9c_status":"BLOCKED"
    }
