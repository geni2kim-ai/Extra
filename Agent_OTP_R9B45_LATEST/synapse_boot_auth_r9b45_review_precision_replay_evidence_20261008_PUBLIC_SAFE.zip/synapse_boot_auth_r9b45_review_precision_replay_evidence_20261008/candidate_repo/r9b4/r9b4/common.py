from __future__ import annotations
import hashlib,json,re
from pathlib import Path
from typing import Any

HEX64=re.compile(r"\A[0-9a-f]{64}\Z")
SID=re.compile(r"\AS-[0-9]+(?:-[0-9]+){2,}\Z")
WORKLOAD=re.compile(r"\A[A-Za-z0-9._:-]{1,80}\Z")

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

def sha_bytes(data:bytes)->str:
    return hashlib.sha256(data).hexdigest()

def require_hex64(v:object,code:str)->str:
    if not isinstance(v,str) or HEX64.fullmatch(v) is None: raise Denied(code)
    return v

def require_sid(v:object,code:str)->str:
    if not isinstance(v,str) or SID.fullmatch(v) is None: raise Denied(code)
    return v

def require_workload(v:object,code:str)->str:
    if not isinstance(v,str) or WORKLOAD.fullmatch(v) is None: raise Denied(code)
    return v

def load_json_bytes(path:Path,label:str)->tuple[bytes,dict[str,Any]]:
    try:
        data=path.read_bytes()
    except Exception as exc:
        raise Denied(label+"_READ_FAILED") from exc
    try:
        obj=json.loads(data.decode("utf-8-sig"))
    except Exception as exc:
        raise Denied(label+"_JSON_INVALID") from exc
    if not isinstance(obj,dict): raise Denied(label+"_TOP_LEVEL_NOT_OBJECT")
    return data,obj
