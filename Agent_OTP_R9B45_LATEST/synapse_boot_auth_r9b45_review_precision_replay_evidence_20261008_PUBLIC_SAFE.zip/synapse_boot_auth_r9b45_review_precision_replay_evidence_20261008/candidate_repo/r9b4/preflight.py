#!/usr/bin/env python3
from __future__ import annotations
import argparse,json
from pathlib import Path
from r9b4.common import Denied,load_json_bytes,require_hex64,require_sid,require_workload,sha_bytes

def _ceiling(name:str,d:dict)->None:
    if d.get("authority_effect")!="NONE":raise Denied(name+"_AUTHORITY_EFFECT_NOT_NONE")
    if d.get("authentication_result")!="NOT_PERFORMED":raise Denied(name+"_AUTHENTICATION_PRECLAIMED")
    if d.get("authorization_status")!="NOT_AUTHORIZED":raise Denied(name+"_AUTHORIZATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if d.get(k,False) is not False:raise Denied(name+"_"+k.upper()+"_PRECLAIMED")

def main()->int:
    ap=argparse.ArgumentParser()
    for x in ("build-receipt","mediator-exe","registry","verifier-exe","verifier-source"):ap.add_argument("--"+x,required=True)
    for x in ("registry","mediator","verifier-binary","verifier-source","build-receipt"):ap.add_argument("--expected-"+x+"-sha256",required=True)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();out=Path(ns.output)
    try:
        exp={k:require_hex64(getattr(ns,"expected_"+k+"_sha256"),"EXPECTED_"+k.upper()+"_SHA_INVALID")
             for k in ("registry","mediator","verifier_binary","verifier_source","build_receipt")}
        bb,b=load_json_bytes(Path(ns.build_receipt),"BUILD")
        rb,r=load_json_bytes(Path(ns.registry),"REGISTRY")
        mb=Path(ns.mediator_exe).read_bytes();vb=Path(ns.verifier_exe).read_bytes();vs=Path(ns.verifier_source).read_bytes()
        actual={"registry":sha_bytes(rb),"mediator":sha_bytes(mb),"verifier_binary":sha_bytes(vb),
                "verifier_source":sha_bytes(vs),"build_receipt":sha_bytes(bb)}
        for k,v in actual.items():
            if v!=exp[k]:raise Denied(k.upper()+"_EXTERNAL_SHA_MISMATCH")
        if b.get("schema_version")!="SYNAPSE-R9B4-BUILD-RECEIPT-1":raise Denied("BUILD_SCHEMA_INVALID")
        if r.get("schema_version")!="SYNAPSE-R9B4-PREPROVISIONED-VERIFIER-REGISTRY-1":raise Denied("REGISTRY_SCHEMA_INVALID")
        _ceiling("BUILD",b);_ceiling("REGISTRY",r)
        if b.get("mediator_binary_sha256")!=actual["mediator"]:raise Denied("BUILD_MEDIATOR_SHA_MISMATCH")
        if b.get("verifier_binary_sha256")!=actual["verifier_binary"]:raise Denied("BUILD_VERIFIER_BINARY_SHA_MISMATCH")
        if b.get("verifier_source_sha256")!=actual["verifier_source"]:raise Denied("BUILD_VERIFIER_SOURCE_SHA_MISMATCH")
        entries=r.get("entries")
        if not isinstance(entries,list):raise Denied("REGISTRY_ENTRIES_INVALID")
        found=[e for e in entries if isinstance(e,dict) and e.get("mediator_binary_sha256")==actual["mediator"]]
        if len(found)!=1:raise Denied("REGISTRY_BINARY_MATCH_NOT_UNIQUE")
        sid=require_sid(found[0].get("allowed_user_sid"),"REGISTRY_ALLOWED_SID_INVALID")
        wid=require_workload(found[0].get("derived_workload_id"),"REGISTRY_WORKLOAD_ID_INVALID")
        doc={
          "schema_version":"SYNAPSE-R9B4-PREFLIGHT-1","status":"PREFLIGHT_PASS",
          "allowed_user_sid":sid,"derived_workload_id":wid,
          "registry_sha256":actual["registry"],"mediator_binary_sha256":actual["mediator"],
          "verifier_binary_sha256":actual["verifier_binary"],"verifier_source_sha256":actual["verifier_source"],
          "build_receipt_sha256":actual["build_receipt"],
          "external_pin_mode":"OPERATOR_SUPPLIED_SHA256_LITERALS_REHEARSAL",
          "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
          "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
        }
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(doc,indent=2)+"\n",encoding="utf-8",newline="\n")
        return 0
    except Denied as e:
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps({"schema_version":"SYNAPSE-R9B4-PREFLIGHT-1","status":"DENIED","code":e.code,
                                   "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
                                   "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,
                                   "authority_effect":"NONE"},indent=2)+"\n",encoding="utf-8",newline="\n")
        return 2
    except Exception:
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps({"schema_version":"SYNAPSE-R9B4-PREFLIGHT-1","status":"DENIED","code":"UNEXPECTED_PREFLIGHT_ERROR",
                                   "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
                                   "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,
                                   "authority_effect":"NONE"},indent=2)+"\n",encoding="utf-8",newline="\n")
        return 2

if __name__=="__main__":raise SystemExit(main())
