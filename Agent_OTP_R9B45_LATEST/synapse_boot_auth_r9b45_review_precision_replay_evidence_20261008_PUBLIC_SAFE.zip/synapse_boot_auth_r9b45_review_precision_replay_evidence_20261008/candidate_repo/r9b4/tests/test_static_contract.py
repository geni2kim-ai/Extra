from pathlib import Path
ROOT=Path(__file__).parents[1]
RUN=(ROOT/'windows'/'run_r9b4_measurement.ps1').read_text(encoding='utf-8')
FORCED=(ROOT/'windows'/'run_r9b41_forced_timeout_probe.ps1').read_text(encoding='utf-8')
TREE=(ROOT/'windows'/'run_r9b41_cleanup_tree_semantics_probe.ps1').read_text(encoding='utf-8')
MODULE=(ROOT/'windows'/'R9B4Cleanup.psm1').read_text(encoding='utf-8')
SERVER=(ROOT/'src'/'VerifierServer.cs').read_text(encoding='utf-8')
MED=(ROOT/'src'/'DedicatedMediator.cs').read_text(encoding='utf-8')
BUILD=(ROOT/'windows'/'build_r9b4.ps1').read_text(encoding='utf-8')

def test_all_core_source_files_present():
    for rel in ('src/VerifierServer.cs','src/DedicatedMediator.cs','src/SyntheticChild.cs','evaluate_r9b4.py',
                'preflight.py','verify_review_safe_set.py','provision_registry.py'):
        assert (ROOT/rel).is_file(), rel
def test_verifier_is_direct_exe_not_add_type():
    assert '$serverPsi.FileName=$verifier' in RUN and 'ExecutionPolicy Bypass' not in RUN and 'Add-Type' not in RUN
def test_production_and_probe_share_cleanup_module():
    assert 'R9B4Cleanup.psm1' in RUN and 'run_r9b4_measurement.ps1' in FORCED
    assert 'Stop-R9B4ProcessTreeBounded' in RUN and 'Stop-R9B4ProcessTreeBounded' in TREE
def test_forced_probe_validates_actual_timeout_branch_not_literal_receipt():
    assert '-TestSuppressClientStart' in FORCED and 'R9B4_SERVER_TIMEOUT' in FORCED
    assert 'same_instance_existed_before' in FORCED and 'taskkill_exit_code' in FORCED and 'same_instance_exists_after' in FORCED
def test_tree_probe_requires_real_child_and_no_residual():
    assert 'child_pids_before' in TREE and 'child_pids_remaining_after' in TREE and 'Count -lt 1' in TREE
def test_cleanup_module_uses_tree_kill_and_instance_identity():
    assert '/T /F' in MODULE and 'ExpectedStartTimeUtc' in MODULE and 'pid_reused_after' in MODULE
def test_framed_pipe_protocol():
    assert 'byte[] header = new byte[]' in MED and 'ReadExact(pipe,header,0,4' in SERVER and 'ReadExact(pipe,payload,0,payloadLen' in SERVER
def test_post_run_hash_checks_are_present():
    assert 'post_run_hashes_verified' in RUN and 'R9B4_POST_RUN_SHA_MISMATCH' in RUN
def test_build_receipt_does_not_claim_determinism():
    assert 'deterministic_build_verified=$false' in BUILD
def test_preflight_rejection_proves_runtime_not_started():
    assert 'server_started=$false;client_started=$false' in RUN and 'preflight_execution.json' in RUN


def test_cleanup_evidence_validator_is_packaged():
    assert (ROOT/"validate_cleanup_evidence.py").is_file()
