from pathlib import Path
from r9b4.replay import consume
from r9b4.common import Denied
def test_one_time_consumption(tmp_path):
    first=consume('a'*32,'b'*32,tmp_path)
    assert first['token_sha256']
    try:consume('a'*32,'b'*32,tmp_path)
    except Denied as e:assert e.code=='RUN_TOKEN_ALREADY_CONSUMED'
    else:assert False
def test_different_nonce_is_distinct(tmp_path):
    assert consume('a'*32,'b'*32,tmp_path)['token_sha256']!=consume('a'*32,'c'*32,tmp_path)['token_sha256']
