from pathlib import Path

ROOT=Path(__file__).parents[1]
SERVER=(ROOT/'src'/'VerifierServer.cs').read_text(encoding='utf-8')
EVALUATOR=(ROOT/'r9b4'/'evaluator.py').read_text(encoding='utf-8')

def test_verifier_capture_emits_pid_required_by_evaluator():
    assert '{"pid",selfPid}' in SERVER
    assert 'integer(verifier.get("pid"),"CAPTURE_VERIFIER_PID_INVALID")' in EVALUATOR
    assert 'HARNESS_CAPTURE_SERVER_PID_MISMATCH' in EVALUATOR

def test_completion_emits_verifier_pid_required_by_evaluator():
    assert '{"verifier_pid",selfPid}' in SERVER
    assert 'completion.get("verifier_pid")' in EVALUATOR
    assert 'COMPLETION_VERIFIER_PID_MISMATCH' in EVALUATOR

def test_same_self_pid_binds_both_producer_fields():
    assert SERVER.count('{"pid",selfPid}') == 1
    assert SERVER.count('{"verifier_pid",selfPid}') == 1
    assert 'using(Process selfProcess=Process.GetCurrentProcess())' in SERVER
