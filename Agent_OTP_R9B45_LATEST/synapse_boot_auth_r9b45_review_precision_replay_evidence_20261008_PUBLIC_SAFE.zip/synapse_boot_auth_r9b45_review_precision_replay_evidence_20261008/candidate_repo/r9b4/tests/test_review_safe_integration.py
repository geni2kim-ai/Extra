from __future__ import annotations
import hashlib,json,subprocess,sys
from datetime import datetime,timezone,timedelta
from pathlib import Path

ROOT=Path(__file__).parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):p.write_text(json.dumps(d,indent=2)+"\n",encoding="utf-8");return sha(p)
def ft(dt):
    epoch=datetime(1601,1,1,tzinfo=timezone.utc)
    return int((dt-epoch).total_seconds()*10_000_000)
def ceiling(a):
    return {'authentication_result':a,'authorization_status':'NOT_AUTHORIZED','runtime_grant_issued':False,
            'g1_token_issued':False,'f2_unlocked':False,'authority_effect':'NONE'}

def test_review_safe_round_trip_is_offline_verifiable_and_private(tmp_path):
    med=tmp_path/'R9B4_DedicatedMediator.exe';med.write_bytes(b'mediator')
    ver=tmp_path/'R9B4_VerifierServer.exe';ver.write_bytes(b'verifier')
    src=tmp_path/'VerifierServer.cs';src.write_bytes(b'// source')
    mh,vh,sh=sha(med),sha(ver),sha(src)
    build=tmp_path/'build.json'
    b={'schema_version':'SYNAPSE-R9B4-BUILD-RECEIPT-1','mediator_binary_sha256':mh,'mediator_binary_name':med.name,
       'verifier_binary_sha256':vh,'verifier_source_sha256':sh,**ceiling('NOT_PERFORMED')}
    bh=write(build,b)
    sid='S-1-5-21-123456789-234567890-345678901-1001'
    reg=tmp_path/'registry.json';rh=write(reg,{'schema_version':'SYNAPSE-R9B4-PREPROVISIONED-VERIFIER-REGISTRY-1',
      'registry_trust':'PREPROVISIONED_REHEARSAL_ONLY','entries':[{'derived_workload_id':'W1','mediator_binary_sha256':mh,'allowed_user_sid':sid}],
      **ceiling('NOT_PERFORMED')})
    pf=tmp_path/'preflight.json';ph=write(pf,{'schema_version':'SYNAPSE-R9B4-PREFLIGHT-1','status':'PREFLIGHT_PASS',
      'allowed_user_sid':sid,'derived_workload_id':'W1','registry_sha256':rh,'mediator_binary_sha256':mh,
      'verifier_binary_sha256':vh,'verifier_source_sha256':sh,'build_receipt_sha256':bh,**ceiling('NOT_PERFORMED')})
    now=datetime.now(timezone.utc);issued=now-timedelta(seconds=20);hstart=now-timedelta(seconds=18)
    created=now-timedelta(seconds=16);captured=now-timedelta(seconds=14);completed=now-timedelta(seconds=12)
    cs=now-timedelta(seconds=10);ce=now-timedelta(seconds=8);hend=now-timedelta(seconds=6)
    run='a'*32;nonce='b'*32;pipe='synapse-r9b4-'+run;session='r9b4-session-'+run
    ctx=tmp_path/'ctx.json';xh=write(ctx,{'schema_version':'SYNAPSE-R9B4-RUN-CONTEXT-1','run_id':run,'measurement_nonce':nonce,
      'pipe_name':pipe,'node_session_id':session,'issued_at_utc':issued.isoformat(),'expires_at_utc':(now+timedelta(seconds=60)).isoformat(),
      'registry_sha256':rh,'mediator_binary_sha256':mh,'verifier_binary_sha256':vh,'verifier_source_sha256':sh,
      'build_receipt_sha256':bh,'preflight_sha256':ph,**ceiling('NOT_PERFORMED')})
    cap=tmp_path/'capture.json';ch=write(cap,{'schema_version':'SYNAPSE-R9B4-NAMED-PIPE-CAPTURE-1','captured_at_utc':captured.isoformat(),'run_id':run,
      'pipe':{'name':pipe,'server_instance_id':'i1','allowed_client_sid':sid,'server_sid':sid},
      'client':{'pid':200,'pid_rechecked':200,'pid_source':'GetNamedPipeClientProcessId','process_creation_time_100ns':ft(created),
        'process_creation_time_rechecked_100ns':ft(created),'process_path':r'C:\Users\Alice\AppData\Local\R9B4_DedicatedMediator.exe',
        'process_path_rechecked':r'C:\Users\Alice\AppData\Local\R9B4_DedicatedMediator.exe','process_sha256':mh,
        'process_sha256_semantics':'ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH','loaded_image_hash_verified':False,'process_active_after_capture':True},
      'token':{'user_sid':sid,'service_sids':['S-1-5-80-12345'],'token_source':'ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)','impersonation_succeeded':True},
      'verifier':{'pid':100,'binary_name':ver.name,'binary_sha256':vh,'source_sha256':sh},
      'preflight_sha256':ph,'run_context_sha256':xh,'build_receipt_sha256':bh,
      'evidence_source':'PIPE_PID_BEFORE_FRAME+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK',
      'captured_node_session_id':session,'caller_claims':{'claimed_node_id':None,'claimed_workload_id':None,'measurement_nonce':nonce},**ceiling('CAPTURE_ONLY')})
    comp=tmp_path/'completion.json';dh=write(comp,{'schema_version':'SYNAPSE-R9B4-SERVER-COMPLETION-1','status':'SERVER_CAPTURE_COMPLETE',
      'completed_at_utc':completed.isoformat(),'run_id':run,'pipe_name':pipe,'server_instance_id':'i1','node_session_id':session,
      'measurement_nonce':nonce,'capture_sha256':ch,'verifier_pid':100,'verifier_binary_sha256':vh,'verifier_source_sha256':sh,
      'preflight_sha256':ph,'run_context_sha256':xh,'build_receipt_sha256':bh,**ceiling('CAPTURE_ONLY')})
    cleanup=tmp_path/'cleanup.json';kh=write(cleanup,{'schema_version':'SYNAPSE-R9B4-CLEANUP-RECEIPT-1','status':'PROCESSES_TERMINATED',
      'run_id':run,'started_at_utc':cs.isoformat(),'completed_at_utc':ce.isoformat(),
      'server':{'pid':100,'same_instance_existed_before':False,'child_snapshot_status':'AVAILABLE','child_pids_before':[],
        'tree_kill_invoked':False,'tree_kill_method':'NONE','taskkill_exit_code':None,'wait_for_exit_succeeded':True,
        'same_instance_exists_after':False,'pid_present_after':False,'pid_reused_after':False,'child_pids_remaining_after':[]},
      'client':{'pid':200,'same_instance_existed_before':False,'child_snapshot_status':'AVAILABLE','child_pids_before':[],
        'tree_kill_invoked':False,'tree_kill_method':'NONE','taskkill_exit_code':None,'wait_for_exit_succeeded':True,
        'same_instance_exists_after':False,'pid_present_after':False,'pid_reused_after':False,'child_pids_remaining_after':[]},
      **ceiling('NOT_PERFORMED')})
    harness=tmp_path/'harness.json';write(harness,{'schema_version':'SYNAPSE-R9B4-MEASUREMENT-HARNESS-1','status':'CAPTURE_READY',
      'run_id':run,'measurement_nonce':nonce,'pipe_name':pipe,'node_session_id':session,'started_at_utc':hstart.isoformat(),'completed_at_utc':hend.isoformat(),
      'server_pid':100,'client_pid':200,'run_context_sha256':xh,'preflight_sha256':ph,'build_receipt_sha256':bh,
      'registry_sha256':rh,'mediator_binary_sha256':mh,'verifier_binary_sha256':vh,'verifier_source_sha256':sh,
      'capture_sha256':ch,'completion_sha256':dh,'cleanup_sha256':kh,'registry_input_unchanged':True,'post_run_hashes_verified':True,
      'post_run_registry_sha256':rh,'post_run_mediator_sha256':mh,'post_run_verifier_binary_sha256':vh,
      'post_run_verifier_source_sha256':sh,'post_run_build_receipt_sha256':bh,'server_exit_code':0,'client_exit_code':0,**ceiling('NOT_PERFORMED')})
    result=tmp_path/'result.json';write(result,{'result':'R9B4_ONE_TIME_EVALUATION_MEASUREMENT_READY','authority_effect':'NONE'})
    out=tmp_path/'review'
    cmd=[sys.executable,'-S',str(ROOT/'distribution/make_review_safe_bundle.py'),
      '--capture',str(cap),'--registry',str(reg),'--preflight',str(pf),'--run-context',str(ctx),'--harness-summary',str(harness),
      '--server-completion',str(comp),'--cleanup-receipt',str(cleanup),'--build-receipt',str(build),'--result',str(result),
      '--mediator-exe',str(med),'--verifier-exe',str(ver),'--verifier-source',str(src),'--output-directory',str(out)]
    cp=subprocess.run(cmd,capture_output=True,text=True);assert cp.returncode==0,cp.stderr
    vr=tmp_path/'verify.json'
    cp2=subprocess.run([sys.executable,'-S',str(ROOT/'verify_review_safe_set.py'),str(out),'-o',str(vr)],capture_output=True,text=True)
    assert cp2.returncode==0,cp2.stderr
    assert json.loads(vr.read_text())['result']=='R9B4_OFFLINE_ARTIFACT_SET_BOUND'
    assert json.loads((out/'PRIVACY_SCAN.json').read_text())['status']=='PASS'
    receipt=json.loads((out/'TRANSFORMATION_RECEIPT.json').read_text())
    assert receipt['per_field_preimage_hashes_included'] is False
    assert 'before_sha256' not in json.dumps(receipt)
    inventory=json.loads((out/'COMPLETE_CHANGE_INVENTORY.json').read_text())
    pointers={x['json_pointer'] for x in inventory['changes']}
    assert '/preflight/allowed_user_sid' in pointers
    assert '/registry/entries/0/allowed_user_sid' in pointers
    assert '/capture/token/user_sid' in pointers
    assert inventory['count']==len(inventory['changes'])
