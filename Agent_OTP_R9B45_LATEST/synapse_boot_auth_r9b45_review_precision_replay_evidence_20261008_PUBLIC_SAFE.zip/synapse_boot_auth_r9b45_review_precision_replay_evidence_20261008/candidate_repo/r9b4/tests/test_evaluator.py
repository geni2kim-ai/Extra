from __future__ import annotations
from datetime import datetime,timezone,timedelta
from r9b4.evaluator import evaluate
from r9b4.common import Denied

def ft(dt):
    epoch=datetime(1601,1,1,tzinfo=timezone.utc)
    return int((dt-epoch).total_seconds()*10_000_000)

def ceiling(authn):
    return {'authentication_result':authn,'authorization_status':'NOT_AUTHORIZED',
            'runtime_grant_issued':False,'g1_token_issued':False,'f2_unlocked':False,'authority_effect':'NONE'}

def artifacts(now=None):
    now=now or datetime.now(timezone.utc)
    issued=now-timedelta(seconds=8);hstart=now-timedelta(seconds=7);created=now-timedelta(seconds=6)
    captured=now-timedelta(seconds=5);completed=now-timedelta(seconds=4)
    cleanup_start=now-timedelta(seconds=3);cleanup_end=now-timedelta(seconds=2);hend=now-timedelta(seconds=1)
    expires=now+timedelta(seconds=90)
    med='a'*64;reg='b'*64;vb='c'*64;vs='d'*64;br='e'*64;pfsha='f'*64;ctxsha='1'*64;capsha='2'*64;compsha='3'*64;cleansha='4'*64
    run='5'*32;nonce='6'*32;pipe='synapse-r9b4-'+run;session='r9b4-session-'+run;sid='S-1-5-21-123';spid=100;cpid=200
    build={'schema_version':'SYNAPSE-R9B4-BUILD-RECEIPT-1','mediator_binary_sha256':med,'mediator_binary_name':'R9B4_DedicatedMediator.exe',
      'verifier_binary_sha256':vb,'verifier_source_sha256':vs,**ceiling('NOT_PERFORMED')}
    registry={'schema_version':'SYNAPSE-R9B4-PREPROVISIONED-VERIFIER-REGISTRY-1','registry_trust':'PREPROVISIONED_REHEARSAL_ONLY',
      'entries':[{'derived_workload_id':'W1','mediator_binary_sha256':med,'allowed_user_sid':sid}],**ceiling('NOT_PERFORMED')}
    pf={'schema_version':'SYNAPSE-R9B4-PREFLIGHT-1','status':'PREFLIGHT_PASS','allowed_user_sid':sid,'derived_workload_id':'W1',
      'registry_sha256':reg,'mediator_binary_sha256':med,'verifier_binary_sha256':vb,'verifier_source_sha256':vs,
      'build_receipt_sha256':br,**ceiling('NOT_PERFORMED')}
    ctx={'schema_version':'SYNAPSE-R9B4-RUN-CONTEXT-1','run_id':run,'measurement_nonce':nonce,'pipe_name':pipe,'node_session_id':session,
      'issued_at_utc':issued.isoformat(),'expires_at_utc':expires.isoformat(),'registry_sha256':reg,'mediator_binary_sha256':med,
      'verifier_binary_sha256':vb,'verifier_source_sha256':vs,'build_receipt_sha256':br,'preflight_sha256':pfsha,**ceiling('NOT_PERFORMED')}
    capture={'schema_version':'SYNAPSE-R9B4-NAMED-PIPE-CAPTURE-1','captured_at_utc':captured.isoformat(),'run_id':run,
      'pipe':{'name':pipe,'server_instance_id':'i1','allowed_client_sid':sid,'security_configuration_basis':'PINNED_VERIFIER_SERVER_BINARY'},
      'client':{'pid':cpid,'pid_rechecked':cpid,'pid_source':'GetNamedPipeClientProcessId','process_creation_time_100ns':ft(created),
        'process_creation_time_rechecked_100ns':ft(created),'process_path':r'C:\x\R9B4_DedicatedMediator.exe',
        'process_path_rechecked':r'c:\X\R9B4_DedicatedMediator.exe','process_sha256':med,
        'process_sha256_semantics':'ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH','loaded_image_hash_verified':False,'process_active_after_capture':True},
      'token':{'user_sid':sid,'service_sids':[],'token_source':'ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)','impersonation_succeeded':True},
      'verifier':{'pid':spid,'binary_name':'R9B4_VerifierServer.exe','binary_sha256':vb,'source_sha256':vs},
      'preflight_sha256':pfsha,'run_context_sha256':ctxsha,'build_receipt_sha256':br,
      'evidence_source':'PIPE_PID_BEFORE_FRAME+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK',
      'captured_node_session_id':session,'caller_claims':{'claimed_node_id':None,'claimed_workload_id':None,'measurement_nonce':nonce},
      **ceiling('CAPTURE_ONLY')}
    completion={'schema_version':'SYNAPSE-R9B4-SERVER-COMPLETION-1','status':'SERVER_CAPTURE_COMPLETE','completed_at_utc':completed.isoformat(),
      'run_id':run,'pipe_name':pipe,'server_instance_id':'i1','node_session_id':session,'measurement_nonce':nonce,'capture_sha256':capsha,
      'verifier_pid':spid,'verifier_binary_sha256':vb,'verifier_source_sha256':vs,'preflight_sha256':pfsha,'run_context_sha256':ctxsha,
      'build_receipt_sha256':br,**ceiling('CAPTURE_ONLY')}
    cleanup={'schema_version':'SYNAPSE-R9B4-CLEANUP-RECEIPT-1','status':'PROCESSES_TERMINATED','run_id':run,
      'started_at_utc':cleanup_start.isoformat(),'completed_at_utc':cleanup_end.isoformat(),
      'server':{'pid':spid,'same_instance_existed_before':False,'child_snapshot_status':'AVAILABLE','child_pids_before':[],
        'tree_kill_invoked':False,'tree_kill_method':'NONE','taskkill_exit_code':None,'wait_for_exit_succeeded':True,
        'same_instance_exists_after':False,'pid_present_after':False,'pid_reused_after':False,'child_pids_remaining_after':[]},
      'client':{'pid':cpid,'same_instance_existed_before':False,'child_snapshot_status':'AVAILABLE','child_pids_before':[],
        'tree_kill_invoked':False,'tree_kill_method':'NONE','taskkill_exit_code':None,'wait_for_exit_succeeded':True,
        'same_instance_exists_after':False,'pid_present_after':False,'pid_reused_after':False,'child_pids_remaining_after':[]},
      **ceiling('NOT_PERFORMED')}
    harness={'schema_version':'SYNAPSE-R9B4-MEASUREMENT-HARNESS-1','status':'CAPTURE_READY','run_id':run,'measurement_nonce':nonce,
      'pipe_name':pipe,'node_session_id':session,'started_at_utc':hstart.isoformat(),'completed_at_utc':hend.isoformat(),
      'server_pid':spid,'client_pid':cpid,'run_context_sha256':ctxsha,'preflight_sha256':pfsha,'build_receipt_sha256':br,
      'registry_sha256':reg,'mediator_binary_sha256':med,'verifier_binary_sha256':vb,'verifier_source_sha256':vs,
      'capture_sha256':capsha,'completion_sha256':compsha,'cleanup_sha256':cleansha,'registry_input_unchanged':True,
      'post_run_hashes_verified':True,'post_run_registry_sha256':reg,'post_run_mediator_sha256':med,
      'post_run_verifier_binary_sha256':vb,'post_run_verifier_source_sha256':vs,'post_run_build_receipt_sha256':br,
      'server_exit_code':0,'client_exit_code':0,**ceiling('NOT_PERFORMED')}
    hashes={'expected_registry_sha256':reg,'expected_mediator_sha256':med,'expected_verifier_binary_sha256':vb,
      'expected_verifier_source_sha256':vs,'expected_build_receipt_sha256':br,'registry_sha256':reg,'mediator_sha256':med,
      'verifier_binary_sha256':vb,'verifier_source_sha256':vs,'build_receipt_sha256':br,'preflight_sha256':pfsha,
      'run_context_sha256':ctxsha,'capture_sha256':capsha,'completion_sha256':compsha,'cleanup_sha256':cleansha}
    return [capture,build,registry,pf,ctx,harness,completion,cleanup,hashes,now]

def deny(mut,code):
    a=artifacts();mut(a)
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code==code
    else:assert False

def test_ready_label_is_measurement_only():
    a=artifacts();o=evaluate(*a[:-1],a[-1],True)
    assert o['result']=='R9B4_FRESHNESS_BOUND_MEASUREMENT_READY'
    assert o['authority_ceiling_validated'] is True
    assert o['authentication_result']=='MEASURED_NOT_AUTHENTICATED' and o['r9c_status']=='BLOCKED'

def test_authorized_capture_is_denied():deny(lambda a:a[0].__setitem__('authorization_status','AUTHORIZED'),'CAPTURE_AUTHORIZATION_PRECLAIMED')
def test_authenticated_capture_is_denied():deny(lambda a:a[0].__setitem__('authentication_result','AUTHENTICATED'),'CAPTURE_AUTHENTICATION_PRECLAIMED')
def test_runtime_grant_preclaim_is_denied():deny(lambda a:a[0].__setitem__('runtime_grant_issued',True),'CAPTURE_RUNTIME_GRANT_ISSUED_PRECLAIMED')
def test_g1_preclaim_is_denied():deny(lambda a:a[0].__setitem__('g1_token_issued',True),'CAPTURE_G1_TOKEN_ISSUED_PRECLAIMED')
def test_f2_preclaim_is_denied():deny(lambda a:a[0].__setitem__('f2_unlocked',True),'CAPTURE_F2_UNLOCKED_PRECLAIMED')
def test_preflight_authority_preclaim_is_denied():deny(lambda a:a[3].__setitem__('authorization_status','AUTHORIZED'),'PREFLIGHT_AUTHORIZATION_PRECLAIMED')
def test_completion_status_is_checked():deny(lambda a:a[6].__setitem__('status','X'),'COMPLETION_STATUS_INVALID')
def test_preflight_hash_cross_binding_checked():deny(lambda a:a[4].__setitem__('preflight_sha256','0'*64),'RUN_CONTEXT_PREFLIGHT_SHA256_MISMATCH')
def test_capture_run_id_checked():deny(lambda a:a[0].__setitem__('run_id','0'*32),'CAPTURE_RUN_ID_MISMATCH')
def test_completion_run_id_checked():deny(lambda a:a[6].__setitem__('run_id','0'*32),'COMPLETION_RUN_ID_MISMATCH')
def test_harness_client_pid_checked():deny(lambda a:a[5].__setitem__('client_pid',201),'HARNESS_CAPTURE_CLIENT_PID_MISMATCH')
def test_build_receipt_digest_checked():deny(lambda a:a[5].__setitem__('build_receipt_sha256','0'*64),'HARNESS_BUILD_RECEIPT_SHA256_MISMATCH')
def test_post_run_hash_verification_required():deny(lambda a:a[5].__setitem__('post_run_hashes_verified',False),'POST_RUN_HASHES_NOT_VERIFIED')
def test_client_creation_must_be_in_window():
    def m(a):a[0]['client']['process_creation_time_100ns']=a[0]['client']['process_creation_time_rechecked_100ns']=1
    deny(m,'RUN_TIME_ORDER_INVALID')
def test_cleanup_run_id_checked():deny(lambda a:a[7].__setitem__('run_id','0'*32),'CLEANUP_RUN_ID_MISMATCH')
def test_cleanup_residual_denied():deny(lambda a:a[7]['server'].__setitem__('same_instance_exists_after',True),'CLEANUP_SERVER_RESIDUAL_PROCESS')
def test_token_source_checked():deny(lambda a:a[0]['token'].__setitem__('token_source','X'),'TOKEN_SOURCE_INVALID')
def test_evidence_source_checked():deny(lambda a:a[0].__setitem__('evidence_source','X'),'EVIDENCE_SOURCE_INVALID')
def test_literal_pipe_config_is_telemetry_only():
    a=artifacts();a[0]['pipe']['security_configuration_basis']='CHANGED_TELEMETRY'
    assert evaluate(*a[:-1],a[-1],True)['result']=='R9B4_FRESHNESS_BOUND_MEASUREMENT_READY'
