import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fixture(tmp_path):
    med=tmp_path/'m.exe';med.write_bytes(b'm');ver=tmp_path/'v.exe';ver.write_bytes(b'v');src=tmp_path/'v.cs';src.write_bytes(b's')
    build=tmp_path/'build.json'
    build.write_text(json.dumps({'schema_version':'SYNAPSE-R9B4-BUILD-RECEIPT-1','mediator_binary_sha256':sha(med),
      'verifier_binary_sha256':sha(ver),'verifier_source_sha256':sha(src),'authentication_result':'NOT_PERFORMED',
      'authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}))
    reg=tmp_path/'reg.json';reg.write_text(json.dumps({'schema_version':'SYNAPSE-R9B4-PREPROVISIONED-VERIFIER-REGISTRY-1',
      'registry_trust':'PREPROVISIONED_REHEARSAL_ONLY','entries':[{'derived_workload_id':'W1','mediator_binary_sha256':sha(med),'allowed_user_sid':'S-1-5-21-123'}],
      'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','runtime_grant_issued':False,
      'g1_token_issued':False,'f2_unlocked':False,'authority_effect':'NONE'}))
    return med,ver,src,build,reg
def call(tmp_path,bad=None):
    med,ver,src,bld,reg=fixture(tmp_path);out=tmp_path/'o.json'
    vals={'registry':sha(reg),'mediator':sha(med),'verifier-binary':sha(ver),'verifier-source':sha(src),'build-receipt':sha(bld)}
    if bad:vals[bad]='0'*64
    cmd=[sys.executable,str(ROOT/'preflight.py'),'--build-receipt',str(bld),'--mediator-exe',str(med),'--registry',str(reg),
      '--verifier-exe',str(ver),'--verifier-source',str(src)]
    for k,v in vals.items():cmd+=['--expected-'+k+'-sha256',v]
    cmd+=['-o',str(out)]
    cp=subprocess.run(cmd,capture_output=True,text=True);return cp,json.loads(out.read_text())
def test_all_five_external_hashes_pass(tmp_path):
    cp,o=call(tmp_path);assert cp.returncode==0 and o['status']=='PREFLIGHT_PASS'
def test_bad_registry_fails(tmp_path):
    cp,o=call(tmp_path,'registry');assert cp.returncode==2 and o['code']=='REGISTRY_EXTERNAL_SHA_MISMATCH'
def test_bad_verifier_binary_fails(tmp_path):
    cp,o=call(tmp_path,'verifier-binary');assert cp.returncode==2 and o['code']=='VERIFIER_BINARY_EXTERNAL_SHA_MISMATCH'
def test_bad_build_receipt_fails(tmp_path):
    cp,o=call(tmp_path,'build-receipt');assert cp.returncode==2 and o['code']=='BUILD_RECEIPT_EXTERNAL_SHA_MISMATCH'
