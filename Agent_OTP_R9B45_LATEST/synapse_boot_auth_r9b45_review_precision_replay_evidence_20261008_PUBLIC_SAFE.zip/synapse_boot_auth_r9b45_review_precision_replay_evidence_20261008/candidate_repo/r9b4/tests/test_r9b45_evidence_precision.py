from pathlib import Path
import json,subprocess,sys,hashlib
ROOT=Path(__file__).parents[1]
GEN=(ROOT/'distribution'/'make_review_safe_bundle.py').read_text(encoding='utf-8')
CLI=(ROOT/'evaluate_r9b4.py').read_text(encoding='utf-8')

def test_generator_uses_automatic_complete_inventory():
    assert 'AUTOMATIC_RECURSIVE_BEFORE_VS_FINAL_REVIEW_JSON_DIFF' in GEN
    assert 'COMPLETE_CHANGE_INVENTORY.json' in GEN
    assert 'inventory_diff' in GEN

def test_preflight_sid_goes_through_recursive_transform():
    assert 'pre=transform_value(copy.deepcopy(docs["preflight"]))' in GEN
    assert 'pre["allowed_user_sid"]=MASK_SID' not in GEN

def test_replay_denial_execution_binding_fields_are_defined():
    for token in ('evaluation_started_at_utc','evaluation_completed_at_utc','evaluator_cli_sha256',
                  'evaluator_core_sha256','replay_impl_sha256','run_id','measurement_nonce',
                  'input_set_sha256','input_bindings'):
        assert token in CLI

def test_input_set_digest_is_canonical_json():
    assert 'sort_keys=True' in CLI and 'separators=(",",":")' in CLI

def test_provenance_builder_is_packaged():
    assert (ROOT/'build_evidence_provenance.py').is_file()
