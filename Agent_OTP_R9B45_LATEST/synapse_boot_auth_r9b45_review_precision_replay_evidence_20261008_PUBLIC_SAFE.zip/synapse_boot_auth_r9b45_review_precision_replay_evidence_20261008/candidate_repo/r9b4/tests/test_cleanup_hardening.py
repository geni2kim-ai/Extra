from tests.test_evaluator import artifacts, deny
from r9b4.evaluator import evaluate

def test_normal_cleanup_still_passes():
    a=artifacts()
    assert evaluate(*a[:-1],a[-1],True)["result"]=="R9B4_FRESHNESS_BOUND_MEASUREMENT_READY"

def test_child_residual_denied():
    deny(lambda a:a[7]["server"].__setitem__("child_pids_remaining_after",[999]),"CLEANUP_SERVER_CHILD_PROCESS_REMAINS")

def test_wait_failure_denied():
    deny(lambda a:a[7]["server"].__setitem__("wait_for_exit_succeeded",False),"CLEANUP_SERVER_WAIT_NOT_CONFIRMED")

def test_pid_reuse_denied():
    deny(lambda a:a[7]["server"].__setitem__("pid_reused_after",True),"CLEANUP_SERVER_PID_REUSE_OBSERVED")

def test_unexpected_tree_kill_denied():
    def m(a):
        c=a[7]["server"];c["tree_kill_invoked"]=True;c["tree_kill_method"]="TASKKILL_PID_TREE_FORCE";c["taskkill_exit_code"]=0
    deny(m,"CLEANUP_SERVER_UNEXPECTED_TREE_KILL")

def test_alive_before_requires_successful_tree_kill():
    def m(a):
        c=a[7]["server"];c["same_instance_existed_before"]=True
    deny(m,"CLEANUP_SERVER_EXPECTED_TREE_KILL_MISSING")

def test_alive_before_tree_kill_passes_when_consistent():
    a=artifacts()
    c=a[7]["server"]
    c["same_instance_existed_before"]=True
    c["tree_kill_invoked"]=True
    c["tree_kill_method"]="TASKKILL_PID_TREE_FORCE"
    c["taskkill_exit_code"]=0
    assert evaluate(*a[:-1],a[-1],True)["result"]=="R9B4_FRESHNESS_BOUND_MEASUREMENT_READY"
