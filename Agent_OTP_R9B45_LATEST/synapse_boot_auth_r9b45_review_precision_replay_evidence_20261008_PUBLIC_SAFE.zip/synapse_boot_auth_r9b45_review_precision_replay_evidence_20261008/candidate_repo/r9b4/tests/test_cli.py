from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).parents[1]
def test_malformed_capture_writes_typed_deny(tmp_path):
    bad=tmp_path/'bad.json';bad.write_text('{bad')
    good=tmp_path/'g.json';good.write_text('{}')
    for n in ('m.exe','v.exe','v.cs'):(tmp_path/n).write_bytes(b'x')
    out=tmp_path/'out.json'
    cmd=[sys.executable,'-S',str(ROOT/'evaluate_r9b4.py'),str(bad)]
    for flag in ('build-receipt','registry','preflight','run-context','harness-summary','server-completion','cleanup-receipt'):
        cmd += ['--'+flag,str(good)]
    cmd += ['--mediator-exe',str(tmp_path/'m.exe'),'--verifier-exe',str(tmp_path/'v.exe'),'--verifier-source',str(tmp_path/'v.cs')]
    for flag in ('registry','mediator','verifier-binary','verifier-source','build-receipt'):
        cmd += ['--expected-'+flag+'-sha256','0'*64]
    cmd += ['--offline-artifact-check','-o',str(out)]
    cp=subprocess.run(cmd,capture_output=True,text=True)
    d=json.loads(out.read_text());assert cp.returncode==2 and d['result']=='R9B4_DENIED' and d['code']=='CAPTURE_JSON_INVALID'
    assert 'Traceback' not in cp.stderr
    eb=d['execution_binding']
    for key in ('evaluation_started_at_utc','evaluation_completed_at_utc','evaluator_cli_sha256',
                'evaluator_core_sha256','replay_impl_sha256','run_id','measurement_nonce',
                'input_set_sha256','input_bindings'):
        assert key in eb
