from pathlib import Path
S=(Path(__file__).parents[1]/'distribution'/'make_review_safe_bundle.py').read_text(encoding='utf-8')

def test_review_safe_rebinds_dependent_hashes():
    for token in ('capture.review.json','registry.review.json','preflight.review.json','run_context.review.json',
                  'harness.review.json','completion.review.json','cleanup.review.json','build.review.json'):
        assert token in S
    assert 'TRANSFORMATION_RECEIPT.json' in S
def test_review_safe_requires_out_of_band_anchor():
    assert 'OUT_OF_BAND_ANCHOR_REQUIRED.txt' in S
def test_transformation_receipt_does_not_include_low_entropy_field_hashes():
    assert 'before_sha256' not in S and 'after_sha256' not in S
    assert '"per_field_preimage_hashes_included":False' in S
def test_review_safe_runs_residual_privacy_scan():
    assert 'PRIVACY_SCAN.json' in S and 'UNEXPECTED_SID' in S and 'LOCAL_USER_PATH' in S
def test_anchor_file_uses_real_newline():
    assert 'reviewer access.\\n"' in S
