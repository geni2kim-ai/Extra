from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import importlib.util, json, os

from r7a.evaluator import evaluate,DiscoveryDenied

def base():
    return {
      "schema_version":"SYNAPSE-R7A-TARGET-DISCOVERY-1",
      "operator_label":{"value":"candidate-3X","trust":"UNVERIFIED_CLAIM"},
      "process":{
        "pid":1234,
        "pid_source":"OPERATOR_SELECTED_READONLY",
        "creation_time_utc":"2026-10-07T00:00:00Z",
        "creation_time_filetime_100ns":100,
        "creation_time_rechecked_filetime_100ns":100,
        "executable_path":r"C:\Agents\x.exe",
        "executable_path_rechecked":r"c:\agents\X.EXE",
        "executable_sha256":"a"*64,
        "active_after_capture":True,
        "command_line_captured":False,
        "evidence_source":"Win32_Process+GetFileHash+GetOwnerSid"
      },
      "owner":{"sid":"S-1-5-21-1","source":"Win32_Process.GetOwnerSid"},
      "mapped_services":[],
      "native_pipe_client_capability":{"status":"UNKNOWN_UNTESTED","reason":"not tested"},
      "authentication_result":"NOT_PERFORMED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
    }

def test_ready_is_discovery_only():
    r=evaluate(base())
    assert r["result"]=="R7A_DISCOVERY_EVIDENCE_READY"
    assert r["operator_label_trust"]=="UNVERIFIED_CLAIM"
    assert r["next_action"]=="R7B_CLIENT_HOOK_ASSESSMENT"
    assert r["authority_effect"]=="NONE"

def test_label_cannot_be_preverified():
    d=base(); d["operator_label"]["trust"]="VERIFIED"
    try: evaluate(d)
    except DiscoveryDenied as e: assert e.code=="OPERATOR_LABEL_MUST_REMAIN_UNVERIFIED"
    else: assert False

def test_creation_recheck_mismatch_denied():
    d=base(); d["process"]["creation_time_rechecked_filetime_100ns"]=101
    try: evaluate(d)
    except DiscoveryDenied as e: assert e.code=="CREATION_TIME_RECHECK_MISMATCH"
    else: assert False

def test_path_recheck_mismatch_denied():
    d=base(); d["process"]["executable_path_rechecked"]=r"C:\evil.exe"
    try: evaluate(d)
    except DiscoveryDenied as e: assert e.code=="EXECUTABLE_PATH_RECHECK_MISMATCH"
    else: assert False

def test_command_line_capture_forbidden():
    d=base(); d["process"]["command_line_captured"]=True
    try: evaluate(d)
    except DiscoveryDenied as e: assert e.code=="COMMAND_LINE_MUST_NOT_BE_CAPTURED"
    else: assert False

def test_authority_flag_denied():
    d=base(); d["g1_token_issued"]=True
    try: evaluate(d)
    except DiscoveryDenied as e: assert e.code=="AUTHORITY_FLAG_TRUE"
    else: assert False

def load_privacy_module():
    p=Path(__file__).parents[1]/"distribution"/"privacy_seal.py"
    spec=importlib.util.spec_from_file_location("privacy",p)
    m=importlib.util.module_from_spec(spec); assert spec.loader
    spec.loader.exec_module(m); return m

def test_privacy_scan_catches_utf8_clixml_like_metadata(tmp_path):
    m=load_privacy_module()
    (tmp_path/"stderr.txt").write_bytes(b'<S N="User">DOMAIN\\ALICE</S><S N="Source">C:\\Users\\ALICE\\Temp\\x.ps1</S>')
    patterns={"P001_USER":"ALICE","P002_PROFILE":r"C:\Users\ALICE"}
    hits=m.scan_tree(tmp_path,patterns)
    assert any(x["pattern_label"]=="P001_USER" for x in hits)
    assert any(x["pattern_label"]=="P002_PROFILE" for x in hits)

def test_privacy_scan_catches_utf16le(tmp_path):
    m=load_privacy_module()
    (tmp_path/"utf16.log").write_bytes("DOMAIN\\ALICE".encode("utf-16le"))
    hits=m.scan_tree(tmp_path,{"P001":"ALICE"})
    assert hits

def test_privacy_report_never_needs_literal_value(tmp_path):
    m=load_privacy_module()
    secret="ALICE"
    (tmp_path/"a.txt").write_text(secret,encoding="utf-8")
    hits=m.scan_tree(tmp_path,{"P001":secret})
    dumped=json.dumps(hits)
    assert secret not in dumped
