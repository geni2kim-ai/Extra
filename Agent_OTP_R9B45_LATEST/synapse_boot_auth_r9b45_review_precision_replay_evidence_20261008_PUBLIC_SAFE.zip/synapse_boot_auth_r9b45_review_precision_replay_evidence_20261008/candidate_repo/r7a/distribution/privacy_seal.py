#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,os
from pathlib import Path
from typing import Iterable

ENV_KEYS=("USERNAME","USER","COMPUTERNAME","USERPROFILE","HOME","TEMP","TMP")

def variants(value: str) -> set[str]:
    out={value}
    out.add(value.replace("\\","/"))
    out.add(value.replace("/","\\"))
    return {x for x in out if len(x) >= 3}

def derive_patterns(extra: Iterable[str]=()) -> dict[str,str]:
    values=[]
    for key in ENV_KEYS:
        v=os.environ.get(key)
        if v:
            values.append((f"ENV_{key}",v))
    for i,v in enumerate(extra,1):
        if v:
            values.append((f"EXTRA_{i:03d}",v))
    result={}
    n=0
    seen=set()
    for source,value in values:
        for v in variants(value):
            if v.casefold() in seen: continue
            seen.add(v.casefold()); n+=1
            result[f"P{n:03d}_{source}"]=v
    return result

def encodings(value: str) -> list[bytes]:
    return [
      value.encode("utf-8",errors="ignore"),
      value.encode("utf-16le",errors="ignore"),
      value.encode("utf-16be",errors="ignore"),
    ]

def scan_tree(root: Path, patterns: dict[str,str], exclude: set[Path]|None=None) -> list[dict]:
    exclude={p.resolve() for p in (exclude or set())}
    hits=[]
    for p in root.rglob("*"):
        if not p.is_file() or p.resolve() in exclude:
            continue
        data=p.read_bytes()
        for label,value in patterns.items():
            counts=[]
            for b in encodings(value):
                if not b: continue
                c=data.count(b)
                if c: counts.append(c)
            if counts:
                hits.append({
                  "file":p.relative_to(root).as_posix(),
                  "pattern_label":label,
                  "match_count":max(counts),
                })
    return hits

def digest_pattern(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("-o","--output",required=True)
    ap.add_argument("--patterns-file")
    ns=ap.parse_args()

    extra=[]
    if ns.patterns_file:
        extra=[x.strip() for x in Path(ns.patterns_file).read_text(encoding="utf-8-sig").splitlines() if x.strip()]
    patterns=derive_patterns(extra)

    out=Path(ns.output)
    hits=scan_tree(Path(ns.root),patterns,{out})
    report={
      "schema_version":"SYNAPSE-DISTRIBUTABLE-PRIVACY-SEAL-1",
      "scan_mode":"RAW_BYTES_UTF8_UTF16LE_UTF16BE",
      "pattern_commitments":{
        k:{"sha256":digest_pattern(v),"length":len(v)}
        for k,v in patterns.items()
      },
      "matches":hits,
      "status":"PASS" if not hits else "BLOCKED_PRIVACY_MATCH",
      "authority_effect":"NONE",
    }
    out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({"status":report["status"],"matches":hits},indent=2))
    return 0 if not hits else 2

if __name__=="__main__":
    raise SystemExit(main())
