#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path

def sha(p:Path)->str:
    return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--pair",action="append",required=True,
                    help="raw_path::distributed_masked_path")
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    records=[]
    for item in ns.pair:
        raw_s,masked_s=item.split("::",1)
        raw=Path(raw_s); masked=Path(masked_s)
        records.append({
          "local_unmasked_sha256":sha(raw),
          "distributed_masked_file":masked.as_posix(),
          "distributed_masked_sha256":sha(masked),
          "masking_transform_applied":sha(raw)!=sha(masked),
          "authority_effect":"NONE",
        })
    result={
      "schema_version":"SYNAPSE-DISTRIBUTION-LINEAGE-2",
      "records":records,
      "authority_effect":"NONE"
    }
    Path(ns.output).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
