# R7A — one real workload read-only discovery

Status: `CANDIDATE / READ-ONLY / NO AUTHORITY`

R6.3 proved the Windows Named Pipe capture boundary with an unchanged packaged synthetic client.

R7A does **not** authenticate a real workload. It only discovers one exact running process and binds:
- PID
- creation time + recheck
- executable path + recheck
- executable SHA-256
- owner SID
- mapped Windows service information

The operator-supplied workload label stays `UNVERIFIED_CLAIM`.

R7A deliberately does not capture command lines and does not inject a pipe client into the target process.

A PASS means only:

`R7A_DISCOVERY_EVIDENCE_READY`

The next phase is R7B source/client-hook assessment.
