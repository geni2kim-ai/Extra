from __future__ import annotations
from typing import Any

class DiscoveryDenied(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code=code

def evaluate(doc: dict[str, Any]) -> dict[str, Any]:
    if doc.get("schema_version") != "SYNAPSE-R7A-TARGET-DISCOVERY-1":
        raise DiscoveryDenied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect") != "NONE":
        raise DiscoveryDenied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status") != "NOT_AUTHORIZED":
        raise DiscoveryDenied("AUTHORIZATION_PRECLAIMED")
    if doc.get("authentication_result") != "NOT_PERFORMED":
        raise DiscoveryDenied("AUTHENTICATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if doc.get(k) is not False:
            raise DiscoveryDenied("AUTHORITY_FLAG_TRUE")

    label=doc.get("operator_label") or {}
    if label.get("trust") != "UNVERIFIED_CLAIM":
        raise DiscoveryDenied("OPERATOR_LABEL_MUST_REMAIN_UNVERIFIED")
    if not label.get("value"):
        raise DiscoveryDenied("OPERATOR_LABEL_MISSING")

    p=doc.get("process") or {}
    if p.get("pid_source") != "OPERATOR_SELECTED_READONLY":
        raise DiscoveryDenied("PID_SOURCE_INVALID")
    if not isinstance(p.get("pid"),int) or p["pid"] <= 0:
        raise DiscoveryDenied("PID_INVALID")
    c1=p.get("creation_time_filetime_100ns")
    c2=p.get("creation_time_rechecked_filetime_100ns")
    if not isinstance(c1,int) or c1 <= 0:
        raise DiscoveryDenied("CREATION_TIME_MISSING")
    if c1 != c2:
        raise DiscoveryDenied("CREATION_TIME_RECHECK_MISMATCH")
    path=p.get("executable_path")
    path2=p.get("executable_path_rechecked")
    if not path or not path2 or path.casefold() != path2.casefold():
        raise DiscoveryDenied("EXECUTABLE_PATH_RECHECK_MISMATCH")
    h=p.get("executable_sha256")
    if not isinstance(h,str) or not __import__("re").fullmatch(r"[0-9a-f]{64}",h):
        raise DiscoveryDenied("EXECUTABLE_SHA256_INVALID")
    if p.get("active_after_capture") is not True:
        raise DiscoveryDenied("PROCESS_NOT_ACTIVE_AFTER_CAPTURE")
    if p.get("command_line_captured") is not False:
        raise DiscoveryDenied("COMMAND_LINE_MUST_NOT_BE_CAPTURED")
    if p.get("evidence_source") != "Win32_Process+GetFileHash+GetOwnerSid":
        raise DiscoveryDenied("PROCESS_EVIDENCE_SOURCE_INVALID")

    owner=doc.get("owner") or {}
    sid=owner.get("sid")
    if not isinstance(sid,str) or not sid.startswith("S-"):
        raise DiscoveryDenied("OWNER_SID_MISSING")
    if owner.get("source") != "Win32_Process.GetOwnerSid":
        raise DiscoveryDenied("OWNER_SID_SOURCE_INVALID")

    capability=doc.get("native_pipe_client_capability") or {}
    if capability.get("status") not in {"UNKNOWN_UNTESTED","SOURCE_CONFIRMED","NOT_CAPABLE"}:
        raise DiscoveryDenied("CLIENT_CAPABILITY_STATUS_INVALID")

    return {
        "result":"R7A_DISCOVERY_EVIDENCE_READY",
        "operator_label":label["value"],
        "operator_label_trust":"UNVERIFIED_CLAIM",
        "pid":p["pid"],
        "creation_time_filetime_100ns":c1,
        "executable_path":path,
        "executable_sha256":h,
        "owner_sid":sid,
        "service_count":len(doc.get("mapped_services") or []),
        "native_pipe_client_capability":capability.get("status"),
        "next_action":"R7B_CLIENT_HOOK_ASSESSMENT",
        "authentication_result":"NOT_PERFORMED",
        "authorization_status":"NOT_AUTHORIZED",
        "runtime_grant_issued":False,
        "g1_token_issued":False,
        "f2_unlocked":False,
        "authority_effect":"NONE",
    }
