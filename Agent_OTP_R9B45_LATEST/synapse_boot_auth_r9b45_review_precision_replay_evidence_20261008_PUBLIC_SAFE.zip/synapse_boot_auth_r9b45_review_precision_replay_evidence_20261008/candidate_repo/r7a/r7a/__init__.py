"""R7A read-only workload discovery. No authority."""
