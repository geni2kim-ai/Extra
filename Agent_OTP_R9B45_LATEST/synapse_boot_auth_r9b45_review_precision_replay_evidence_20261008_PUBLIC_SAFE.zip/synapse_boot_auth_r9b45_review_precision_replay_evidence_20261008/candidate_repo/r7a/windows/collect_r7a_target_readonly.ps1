param(
    [Parameter(Mandatory=$true)]
    [int]$ProcessId,

    [Parameter(Mandatory=$true)]
    [string]$OperatorLabel,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath
)

$ErrorActionPreference = "Stop"

function Get-Proc([int]$TargetPid) {
    return Get-CimInstance Win32_Process -Filter ("ProcessId=" + $TargetPid)
}

$proc1 = Get-Proc $ProcessId
if (-not $proc1) { throw "TARGET_PROCESS_NOT_FOUND" }

$path1 = [string]$proc1.ExecutablePath
if (-not $path1 -or -not (Test-Path -LiteralPath $path1 -PathType Leaf)) {
    throw "TARGET_EXECUTABLE_NOT_RESOLVED"
}

$creation1 = $proc1.CreationDate
if (-not ($creation1 -is [datetime])) {
    throw "TARGET_CREATION_TIME_NOT_DATETIME"
}
$creationUtc1 = ([datetime]$creation1).ToUniversalTime()
$hash = (Get-FileHash -LiteralPath $path1 -Algorithm SHA256).Hash.ToLowerInvariant()

$ownerSidResult = Invoke-CimMethod -InputObject $proc1 -MethodName GetOwnerSid
$ownerSid = $ownerSidResult.Sid
if (-not $ownerSid) { throw "TARGET_OWNER_SID_NOT_RESOLVED" }

$allServices = @(Get-CimInstance Win32_Service)
$mapped = @()
foreach ($svc in @($allServices | Where-Object { [int]$_.ProcessId -eq $ProcessId })) {
    $showSid = $null
    $sidType = $null
    try { $showSid = (& sc.exe showsid $svc.Name 2>&1 | Out-String) } catch {}
    try { $sidType = (& sc.exe qsidtype $svc.Name 2>&1 | Out-String) } catch {}
    $mapped += [ordered]@{
        name = $svc.Name
        display_name = $svc.DisplayName
        state = $svc.State
        start_name = $svc.StartName
        path_name = $svc.PathName
        showsid_text = $showSid
        qsidtype_text = $sidType
    }
}

# Re-read the process after hashing to reduce PID-reuse / TOCTOU confusion.
$proc2 = Get-Proc $ProcessId
if (-not $proc2) { throw "TARGET_PROCESS_EXITED_DURING_CAPTURE" }
$path2 = [string]$proc2.ExecutablePath
$creation2 = $proc2.CreationDate
if (-not ($creation2 -is [datetime])) {
    throw "TARGET_CREATION_TIME_RECHECK_INVALID"
}
$creationUtc2 = ([datetime]$creation2).ToUniversalTime()

$report = [ordered]@{
    schema_version = "SYNAPSE-R7A-TARGET-DISCOVERY-1"
    collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    operator_label = [ordered]@{
        value = $OperatorLabel
        trust = "UNVERIFIED_CLAIM"
    }
    process = [ordered]@{
        pid = $ProcessId
        pid_source = "OPERATOR_SELECTED_READONLY"
        process_name = [string]$proc1.Name
        parent_pid = [int]$proc1.ParentProcessId
        creation_time_utc = $creationUtc1.ToString("o")
        creation_time_filetime_100ns = $creationUtc1.ToFileTimeUtc()
        creation_time_rechecked_filetime_100ns = $creationUtc2.ToFileTimeUtc()
        executable_path = $path1
        executable_path_rechecked = $path2
        executable_sha256 = $hash
        active_after_capture = $true
        command_line_captured = $false
        evidence_source = "Win32_Process+GetFileHash+GetOwnerSid"
    }
    owner = [ordered]@{
        sid = $ownerSid
        source = "Win32_Process.GetOwnerSid"
    }
    mapped_services = $mapped
    native_pipe_client_capability = [ordered]@{
        status = "UNKNOWN_UNTESTED"
        reason = "R7A discovery does not inject code or infer client capability from process name."
    }
    authentication_result = "NOT_PERFORMED"
    authorization_status = "NOT_AUTHORIZED"
    runtime_grant_issued = $false
    g1_token_issued = $false
    f2_unlocked = $false
    authority_effect = "NONE"
}

$report | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
$sha = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ("WROTE " + $OutputPath)
Write-Host ("SHA256 " + $sha)
Write-Host "AUTHORITY_EFFECT=NONE"
