param(
    [Parameter(Mandatory=$true)]
    [string]$NameRegex,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath,

    [ValidateRange(1, 100)]
    [int]$MaxCandidates = 30
)

$ErrorActionPreference = "Stop"

$procs = Get-CimInstance Win32_Process
$services = @(Get-CimInstance Win32_Service)
$rows = @()

foreach ($proc in $procs) {
    if ($rows.Count -ge $MaxCandidates) { break }

    $name = [string]$proc.Name
    $path = [string]$proc.ExecutablePath
    if (($name -notmatch $NameRegex) -and ($path -notmatch $NameRegex)) { continue }

    $ownerSid = $null
    try {
        $ownerSidResult = Invoke-CimMethod -InputObject $proc -MethodName GetOwnerSid
        $ownerSid = $ownerSidResult.Sid
    } catch {}

    $mapped = @($services | Where-Object { [int]$_.ProcessId -eq [int]$proc.ProcessId } | ForEach-Object {
        [ordered]@{
            name = $_.Name
            state = $_.State
            start_name = $_.StartName
            path_name = $_.PathName
        }
    })

    $rows += [ordered]@{
        pid = [int]$proc.ProcessId
        parent_pid = [int]$proc.ParentProcessId
        process_name = $name
        executable_path = if ($path) { $path } else { $null }
        owner_sid = $ownerSid
        mapped_services = $mapped
        command_line_captured = $false
        workload_identity = "NOT_INFERRED"
        classification = "OBSERVED_OS_DISCOVERY_ONLY"
    }
}

$report = [ordered]@{
    schema_version = "SYNAPSE-R7A-CANDIDATE-DISCOVERY-1"
    collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    filter_regex = $NameRegex
    candidates = $rows
    authentication_result = "NOT_PERFORMED"
    authorization_status = "NOT_AUTHORIZED"
    authority_effect = "NONE"
}

$report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host ("CANDIDATES " + $rows.Count)
Write-Host "AUTHORITY_EFFECT=NONE"
