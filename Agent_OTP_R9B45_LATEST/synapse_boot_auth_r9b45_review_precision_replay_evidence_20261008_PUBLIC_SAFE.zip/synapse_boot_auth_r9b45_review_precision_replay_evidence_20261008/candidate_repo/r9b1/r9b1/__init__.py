"""R9B.1 local Named Pipe workload measurement rehearsal."""
