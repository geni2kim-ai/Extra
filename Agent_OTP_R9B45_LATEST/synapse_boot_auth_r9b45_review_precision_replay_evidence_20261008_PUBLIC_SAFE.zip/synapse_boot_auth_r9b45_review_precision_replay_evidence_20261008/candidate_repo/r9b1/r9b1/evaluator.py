from __future__ import annotations
from pathlib import PureWindowsPath
from typing import Any
import re

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

HEX64=re.compile(r"[0-9a-f]{64}")

def _hex(v:object)->bool:
    return isinstance(v,str) and HEX64.fullmatch(v) is not None

def evaluate(capture:dict[str,Any],build:dict[str,Any],registry:dict[str,Any])->dict[str,Any]:
    if capture.get("schema_version")!="SYNAPSE-R6-NAMED-PIPE-CAPTURE-1":
        raise Denied("CAPTURE_SCHEMA_INVALID")
    if build.get("schema_version")!="SYNAPSE-R9B1-BUILD-RECEIPT-1":
        raise Denied("BUILD_SCHEMA_INVALID")
    if registry.get("schema_version")!="SYNAPSE-R9B1-LOCAL-VERIFIER-REGISTRY-1":
        raise Denied("REGISTRY_SCHEMA_INVALID")

    if capture.get("authority_effect")!="NONE" or build.get("authority_effect")!="NONE" or registry.get("authority_effect")!="NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if capture.get("authorization_status")!="NOT_AUTHORIZED" or build.get("authorization_status")!="NOT_AUTHORIZED":
        raise Denied("AUTHORIZATION_PRECLAIMED")
    if capture.get("authentication_result")!="CAPTURE_ONLY" or build.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("AUTH_RESULT_INVALID")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if capture.get(k) is not False:
            raise Denied("AUTHORITY_FLAG_TRUE")

    pipe=capture.get("pipe") or {}
    if pipe.get("remote_clients_rejected") is not True:
        raise Denied("REMOTE_CLIENT_REJECTION_REQUIRED")
    if pipe.get("explicit_acl") is not True:
        raise Denied("EXPLICIT_PIPE_ACL_REQUIRED")

    client=capture.get("client") or {}
    if client.get("pid_source")!="GetNamedPipeClientProcessId":
        raise Denied("CLIENT_PID_SOURCE_INVALID")
    if client.get("process_creation_time_100ns")!=client.get("process_creation_time_rechecked_100ns"):
        raise Denied("CLIENT_INSTANCE_RECHECK_FAILED")
    p1=client.get("process_path");p2=client.get("process_path_rechecked")
    if not isinstance(p1,str) or not isinstance(p2,str) or p1.casefold()!=p2.casefold():
        raise Denied("CLIENT_PATH_RECHECK_FAILED")
    if client.get("process_active_after_capture") is not True:
        raise Denied("CLIENT_NOT_ACTIVE")
    if capture.get("evidence_source")!="OpenProcess+GetProcessTimes+QueryFullProcessImageName":
        raise Denied("CLIENT_EVIDENCE_SOURCE_INVALID")
    observed_sha=client.get("process_sha256")
    if not _hex(observed_sha):
        raise Denied("CLIENT_SHA_INVALID")

    expected_sha=build.get("mediator_binary_sha256")
    expected_name=build.get("mediator_binary_name")
    if not _hex(expected_sha) or observed_sha!=expected_sha:
        raise Denied("MEDIATOR_BINARY_SHA_MISMATCH")
    if not isinstance(expected_name,str) or PureWindowsPath(p1).name.casefold()!=expected_name.casefold():
        raise Denied("MEDIATOR_BINARY_NAME_MISMATCH")

    token=capture.get("token") or {}
    if token.get("impersonation_succeeded") is not True:
        raise Denied("CLIENT_IMPERSONATION_REQUIRED")
    if token.get("token_source")!="ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)":
        raise Denied("TOKEN_SOURCE_INVALID")
    sid=token.get("user_sid")
    if not isinstance(sid,str) or not sid.startswith("S-"):
        raise Denied("CLIENT_SID_INVALID")
    if pipe.get("allowed_client_sid")!=sid:
        raise Denied("PIPE_ALLOWED_SID_MISMATCH")

    entries=registry.get("entries")
    if not isinstance(entries,list):
        raise Denied("REGISTRY_ENTRIES_INVALID")
    matches=[
        e for e in entries if isinstance(e,dict)
        and e.get("mediator_binary_sha256")==observed_sha
        and isinstance(e.get("allowed_user_sid"),str)
        and e["allowed_user_sid"].casefold()==sid.casefold()
    ]
    if len(matches)!=1:
        raise Denied("REGISTRY_MATCH_NOT_UNIQUE")
    entry=matches[0]
    workload_id=entry.get("derived_workload_id")
    if not isinstance(workload_id,str) or not workload_id:
        raise Denied("DERIVED_WORKLOAD_ID_INVALID")
    if entry.get("registry_trust")!="LOCAL_REHEARSAL_ONLY" or registry.get("registry_trust")!="LOCAL_REHEARSAL_ONLY":
        raise Denied("REGISTRY_TRUST_INVALID")

    claims=capture.get("caller_claims") or {}
    if claims.get("claimed_node_id") is not None or claims.get("claimed_workload_id") is not None:
        raise Denied("CLIENT_IDENTITY_CLAIMS_MUST_BE_ABSENT")

    return {
      "result":"R9B1_LOCAL_WORKLOAD_MEASUREMENT_READY",
      "derived_workload_id":workload_id,
      "derived_from":"PIPE_PID+HANDLE_EVIDENCE+BINARY_SHA+IMPERSONATED_SID+LOCAL_REGISTRY",
      "caller_claims_trust":"NOT_USED",
      "stable_node_id":"UNBOUND",
      "measurement_result":"MEASURED",
      "authentication_result":"MEASURED_NOT_AUTHENTICATED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
      "next_action":"R9C_PROTECTED_INSTALLATION_CREDENTIAL_DESIGN"
    }
