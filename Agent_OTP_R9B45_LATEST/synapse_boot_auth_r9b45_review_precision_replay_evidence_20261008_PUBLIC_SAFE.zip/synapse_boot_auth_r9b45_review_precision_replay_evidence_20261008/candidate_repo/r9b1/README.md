# R9B.1 — local Named Pipe workload measurement rehearsal

R9B.1 is **not authentication**.

It adds a local-only Named Pipe client mode to the dedicated mediator candidate and connects it to the already
tested R6 capture server.

Evidence chain:

`mediator local pipe connection`
→ `GetNamedPipeClientProcessId`
→ `OpenProcess`
→ `GetProcessTimes + QueryFullProcessImageName`
→ mediator binary SHA
→ `ImpersonateNamedPipeClient`
→ Windows user SID
→ local verifier registry mapping

The client sends an empty JSON object only. It does not claim a node ID or workload ID.

The verifier derives a rehearsal workload label from its local registry. The maximum result is:

`R9B1_LOCAL_WORKLOAD_MEASUREMENT_READY / MEASURED_NOT_AUTHENTICATED`

Binary SHA plus SID are measurements, not a protected/non-exportable credential. Stable node identity stays
UNBOUND and no G1/F2/runtime grant can be issued.
