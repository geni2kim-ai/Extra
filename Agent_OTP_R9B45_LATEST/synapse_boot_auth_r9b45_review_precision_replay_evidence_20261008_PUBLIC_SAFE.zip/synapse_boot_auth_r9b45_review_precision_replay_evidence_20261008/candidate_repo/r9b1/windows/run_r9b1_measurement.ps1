param(
    [Parameter(Mandatory=$true)][string]$MediatorExe,
    [Parameter(Mandatory=$true)][string]$BuildReceipt,
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference="Stop"

$exe=[IO.Path]::GetFullPath($MediatorExe)
$buildPath=[IO.Path]::GetFullPath($BuildReceipt)
$out=[IO.Path]::GetFullPath($OutputDirectory)
if(-not(Test-Path -LiteralPath $exe -PathType Leaf)){throw "R9B1_MEDIATOR_EXE_NOT_FOUND"}
if(-not(Test-Path -LiteralPath $buildPath -PathType Leaf)){throw "R9B1_BUILD_RECEIPT_NOT_FOUND"}
New-Item -ItemType Directory -Force -Path $out|Out-Null

$repoRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$serverScript=Join-Path $repoRoot "r6\windows\invoke_r6_capture_server.ps1"
if(-not(Test-Path -LiteralPath $serverScript -PathType Leaf)){throw "R9B1_R6_SERVER_NOT_FOUND"}

$build=Get-Content -LiteralPath $buildPath -Raw|ConvertFrom-Json
$actualMedSha=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
if($build.mediator_binary_sha256 -ne $actualMedSha){throw "R9B1_BUILD_BINARY_SHA_MISMATCH"}

$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if(-not $identity.User){throw "R9B1_CURRENT_USER_SID_MISSING"}
$userSid=$identity.User.Value

$registry=[ordered]@{
 schema_version="SYNAPSE-R9B1-LOCAL-VERIFIER-REGISTRY-1"
 registry_trust="LOCAL_REHEARSAL_ONLY"
 entries=@([ordered]@{
   derived_workload_id="R9B1_DEDICATED_MEDIATOR_CANDIDATE"
   mediator_binary_sha256=$actualMedSha
   allowed_user_sid=$userSid
   registry_trust="LOCAL_REHEARSAL_ONLY"
 })
 authority_effect="NONE"
}
$registryPath=Join-Path $out "local_verifier_registry.raw.json"
$registry|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $registryPath -Encoding UTF8

$pipeName="synapse-r9b1-"+[guid]::NewGuid().ToString("N")
$sessionId="r9b1-local-session-"+[guid]::NewGuid().ToString("N")
$capturePath=Join-Path $out "R9B1_capture.raw.json"
$completionPath=Join-Path $out "R9B1_server_completion.json"
$serverStdout=Join-Path $out "server.stdout.txt"
$serverStderr=Join-Path $out "server.stderr.txt"
$clientStdout=Join-Path $out "client.stdout.txt"
$clientStderr=Join-Path $out "client.stderr.txt"
$serverExitPath=Join-Path $out "server.exitcode.txt"
$clientExitPath=Join-Path $out "client.exitcode.txt"

function Q([string]$s){
 if($s.Contains('"')){throw "R9B1_QUOTE_IN_ARGUMENT_FORBIDDEN"}
 return '"'+$s+'"'
}

$psExe=(Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$serverPsi=New-Object Diagnostics.ProcessStartInfo
$serverPsi.FileName=$psExe
$serverPsi.Arguments=(
 "-NoProfile -ExecutionPolicy Bypass -File "+(Q $serverScript)+
 " -PipeName "+$pipeName+
 " -AllowedClientSid "+$userSid+
 " -NodeSessionId "+$sessionId+
 " -OutputPath "+(Q $capturePath)+
 " -CompletionPath "+(Q $completionPath)+
 " -MaxRequestBytes 4096"
)
$serverPsi.UseShellExecute=$false
$serverPsi.CreateNoWindow=$true
$serverPsi.RedirectStandardOutput=$true
$serverPsi.RedirectStandardError=$true

$clientPsi=New-Object Diagnostics.ProcessStartInfo
$clientPsi.FileName=$exe
$clientPsi.Arguments="--measure-pipe "+$pipeName
$clientPsi.UseShellExecute=$false
$clientPsi.CreateNoWindow=$true
$clientPsi.RedirectStandardOutput=$true
$clientPsi.RedirectStandardError=$true

$server=New-Object Diagnostics.Process
$client=New-Object Diagnostics.Process
$server.StartInfo=$serverPsi
$client.StartInfo=$clientPsi

try{
 if(-not $server.Start()){throw "R9B1_SERVER_START_FAILED"}
 $serverOutTask=$server.StandardOutput.ReadToEndAsync()
 $serverErrTask=$server.StandardError.ReadToEndAsync()

 if(-not $client.Start()){throw "R9B1_CLIENT_START_FAILED"}
 $clientOutTask=$client.StandardOutput.ReadToEndAsync()
 $clientErrTask=$client.StandardError.ReadToEndAsync()

 if(-not $client.WaitForExit(15000)){
   try{$client.Kill()}catch{}
   throw "R9B1_CLIENT_TIMEOUT"
 }
 $client.WaitForExit()
 if(-not $server.WaitForExit(15000)){
   try{$server.Kill()}catch{}
   throw "R9B1_SERVER_TIMEOUT"
 }
 $server.WaitForExit()

 $serverOut=$serverOutTask.GetAwaiter().GetResult()
 $serverErr=$serverErrTask.GetAwaiter().GetResult()
 $clientOut=$clientOutTask.GetAwaiter().GetResult()
 $clientErr=$clientErrTask.GetAwaiter().GetResult()
 $serverCode=[int]$server.ExitCode
 $clientCode=[int]$client.ExitCode

 [IO.File]::WriteAllText($serverStdout,$serverOut,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText($serverStderr,$serverErr,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText($clientStdout,$clientOut,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText($clientStderr,$clientErr,(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText($serverExitPath,([string]$serverCode+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false)))
 [IO.File]::WriteAllText($clientExitPath,([string]$clientCode+[Environment]::NewLine),(New-Object Text.UTF8Encoding($false)))

 if($serverCode -ne 0){throw ("R9B1_SERVER_EXIT_NONZERO "+$serverCode)}
 if($clientCode -ne 0){throw ("R9B1_CLIENT_EXIT_NONZERO "+$clientCode)}
 if(-not(Test-Path -LiteralPath $capturePath -PathType Leaf)){throw "R9B1_CAPTURE_MISSING"}
 if(-not(Test-Path -LiteralPath $completionPath -PathType Leaf)){throw "R9B1_COMPLETION_MISSING"}

 $captureSha=(Get-FileHash -LiteralPath $capturePath -Algorithm SHA256).Hash.ToLowerInvariant()
 $completion=Get-Content -LiteralPath $completionPath -Raw|ConvertFrom-Json
 if($completion.capture_sha256 -ne $captureSha){throw "R9B1_COMPLETION_CAPTURE_SHA_MISMATCH"}
 if($completion.authorization_status -ne "NOT_AUTHORIZED" -or $completion.authority_effect -ne "NONE"){
   throw "R9B1_COMPLETION_AUTHORITY_OVERCLAIM"
 }

 $sha=[Security.Cryptography.SHA256]::Create()
 try{
   $pipeHashBytes=$sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($pipeName))
 } finally {
   $sha.Dispose()
 }
 $pipeHash=($pipeHashBytes|ForEach-Object {$_.ToString("x2")}) -join ""

 $summary=[ordered]@{
   schema_version="SYNAPSE-R9B1-MEASUREMENT-HARNESS-1"
   status="CAPTURE_READY"
   pipe_name_sha256=$pipeHash
   capture_sha256=$captureSha
   mediator_binary_sha256=$actualMedSha
   server_exit_code=$serverCode
   client_exit_code=$clientCode
   registry_trust="LOCAL_REHEARSAL_ONLY"
   authentication_result="NOT_PERFORMED"
   authorization_status="NOT_AUTHORIZED"
   authority_effect="NONE"
 }
 $summary|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $out "measurement_harness_summary.json") -Encoding UTF8
 Write-Host "R9B1_MEASUREMENT_CAPTURE_READY"
 Write-Host "AUTHORITY_EFFECT=NONE"
}
finally{
 if($client){$client.Dispose()}
 if($server){$server.Dispose()}
}
