from r9b1.evaluator import evaluate,Denied
def triple():
    sha="a"*64
    c={"schema_version":"SYNAPSE-R6-NAMED-PIPE-CAPTURE-1",
       "pipe":{"remote_clients_rejected":True,"explicit_acl":True,"allowed_client_sid":"S-1-5-21-123"},
       "client":{"pid":200,"pid_source":"GetNamedPipeClientProcessId","process_creation_time_100ns":1,
         "process_creation_time_rechecked_100ns":1,"process_path":r"C:\x\R9B1_DedicatedMediator.exe",
         "process_path_rechecked":r"c:\X\R9B1_DedicatedMediator.exe","process_sha256":sha,"process_active_after_capture":True},
       "token":{"user_sid":"S-1-5-21-123","token_source":"ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)","impersonation_succeeded":True},
       "evidence_source":"OpenProcess+GetProcessTimes+QueryFullProcessImageName","caller_claims":{"claimed_node_id":None,"claimed_workload_id":None},
       "authentication_result":"CAPTURE_ONLY","authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,
       "g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"}
    b={"schema_version":"SYNAPSE-R9B1-BUILD-RECEIPT-1","mediator_binary_sha256":sha,
       "mediator_binary_name":"R9B1_DedicatedMediator.exe","authentication_result":"NOT_PERFORMED",
       "authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}
    r={"schema_version":"SYNAPSE-R9B1-LOCAL-VERIFIER-REGISTRY-1","registry_trust":"LOCAL_REHEARSAL_ONLY",
       "entries":[{"derived_workload_id":"R9B1_DEDICATED_MEDIATOR_CANDIDATE","mediator_binary_sha256":sha,
                   "allowed_user_sid":"S-1-5-21-123","registry_trust":"LOCAL_REHEARSAL_ONLY"}],
       "authority_effect":"NONE"}
    return c,b,r
def test_measured_not_authenticated():
    c,b,r=triple();o=evaluate(c,b,r)
    assert o["result"]=="R9B1_LOCAL_WORKLOAD_MEASUREMENT_READY"
    assert o["authentication_result"]=="MEASURED_NOT_AUTHENTICATED"
    assert o["stable_node_id"]=="UNBOUND"
    assert o["authorization_status"]=="NOT_AUTHORIZED"
def test_binary_mismatch_denied():
    c,b,r=triple();c["client"]["process_sha256"]="b"*64
    try:evaluate(c,b,r)
    except Denied as e:assert e.code=="MEDIATOR_BINARY_SHA_MISMATCH"
    else:assert False
def test_sid_mismatch_denied():
    c,b,r=triple();c["token"]["user_sid"]="S-1-5-21-999"
    try:evaluate(c,b,r)
    except Denied as e:assert e.code=="PIPE_ALLOWED_SID_MISMATCH"
    else:assert False
def test_registry_duplicate_denied():
    c,b,r=triple();r["entries"].append(dict(r["entries"][0]))
    try:evaluate(c,b,r)
    except Denied as e:assert e.code=="REGISTRY_MATCH_NOT_UNIQUE"
    else:assert False
def test_client_claims_forbidden_in_measurement_rehearsal():
    c,b,r=triple();c["caller_claims"]["claimed_node_id"]="3X"
    try:evaluate(c,b,r)
    except Denied as e:assert e.code=="CLIENT_IDENTITY_CLAIMS_MUST_BE_ABSENT"
    else:assert False
def test_capture_only_not_authentication():
    c,b,r=triple();c["authentication_result"]="VERIFIED"
    try:evaluate(c,b,r)
    except Denied as e:assert e.code=="AUTH_RESULT_INVALID"
    else:assert False
