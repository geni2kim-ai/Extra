from pathlib import Path
ROOT=Path(__file__).parents[1]
S=(ROOT/"src"/"DedicatedMediator.cs").read_text(encoding="utf-8")
H=(ROOT/"windows"/"run_r9b1_measurement.ps1").read_text(encoding="utf-8")
M=(ROOT/"distribution"/"mask_r9b1_capture.py").read_text(encoding="utf-8")
def test_mediator_has_local_pipe_measure_mode():
    assert "NamedPipeClientStream" in S
    assert "--measure-pipe" in S
    assert 'Encoding.UTF8.GetBytes("{}")' in S
def test_pipe_client_requests_impersonation():
    assert "TokenImpersonationLevel.Impersonation" in S
def test_client_waits_for_server_disconnect():
    assert "pipe.Read(one, 0, 1)" in S
def test_harness_uses_existing_r6_server():
    assert "invoke_r6_capture_server.ps1" in H
    assert "Get-FileHash -LiteralPath $exe" in H
def test_harness_generates_local_only_registry_not_authority():
    assert 'registry_trust="LOCAL_REHEARSAL_ONLY"' in H
    assert 'authorization_status="NOT_AUTHORIZED"' in H
    assert 'authority_effect="NONE"' in H
def test_distribution_masks_raw_path_and_sid():
    assert "PATH_MASKED" in M
    assert "SID_MASKED" in M
