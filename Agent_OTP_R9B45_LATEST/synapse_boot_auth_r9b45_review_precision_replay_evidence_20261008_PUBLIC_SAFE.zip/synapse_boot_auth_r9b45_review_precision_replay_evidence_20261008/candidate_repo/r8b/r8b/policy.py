from __future__ import annotations
from typing import Any
import re

class BoundaryDenied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

FORBIDDEN_CHILD_AUTH_FIELDS={"node_id","principal","capabilities","grant","runtime_grant","credential","token","authority"}

def validate_message_envelope(doc:dict[str,Any])->dict[str,Any]:
    if doc.get("schema_version")!="SYNAPSE-R8B-MEDIATED-CHILD-MESSAGE-1":
        raise BoundaryDenied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect")!="NONE":
        raise BoundaryDenied("AUTHORITY_EFFECT_NOT_NONE")

    mediator=doc.get("mediator") or {}
    if mediator.get("trust")!="CONTROLLED_LAUNCHER_UNAUTHENTICATED":
        raise BoundaryDenied("MEDIATOR_TRUST_INVALID")
    if mediator.get("authentication_result")!="NOT_PERFORMED":
        raise BoundaryDenied("MEDIATOR_AUTH_PRECLAIMED")

    child=doc.get("child_instance") or {}
    if child.get("identity")!="NOT_PROVED":
        raise BoundaryDenied("CHILD_IDENTITY_OVERCLAIM")
    if child.get("parent_binding_verified") is not True:
        raise BoundaryDenied("CHILD_PARENT_BINDING_REQUIRED")
    if not isinstance(child.get("pid"),int) or child["pid"]<=0:
        raise BoundaryDenied("CHILD_PID_INVALID")
    h=child.get("executable_sha256")
    if not isinstance(h,str) or not re.fullmatch(r"[0-9a-f]{64}",h):
        raise BoundaryDenied("CHILD_SHA_INVALID")

    message=doc.get("child_message") or {}
    for key in FORBIDDEN_CHILD_AUTH_FIELDS:
        if key in message:
            raise BoundaryDenied("CHILD_AUTHORITY_FIELD_FORBIDDEN")
    if message.get("trust")!="UNTRUSTED_CHILD_INPUT":
        raise BoundaryDenied("CHILD_MESSAGE_TRUST_INVALID")
    payload_hash=message.get("payload_sha256")
    if not isinstance(payload_hash,str) or not re.fullmatch(r"[0-9a-f]{64}",payload_hash):
        raise BoundaryDenied("PAYLOAD_SHA_INVALID")
    if not isinstance(message.get("sequence"),int) or message["sequence"]<0:
        raise BoundaryDenied("MESSAGE_SEQUENCE_INVALID")

    return {
      "result":"R8B_MEDIATED_BOUNDARY_EVIDENCE_READY",
      "mediator_trust":"CONTROLLED_LAUNCHER_UNAUTHENTICATED",
      "child_identity":"NOT_PROVED",
      "child_message_trust":"UNTRUSTED_CHILD_INPUT",
      "permitted_use":"INPUT_TO_POLICY_REVIEW_ONLY",
      "next_action":"R9_AUTHENTICATE_MEDIATOR_WORKLOAD",
      "authentication_result":"NOT_PERFORMED",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
    }
