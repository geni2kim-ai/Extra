from __future__ import annotations
from r8b.policy import validate_message_envelope,BoundaryDenied

def base():
    return {
      "schema_version":"SYNAPSE-R8B-MEDIATED-CHILD-MESSAGE-1",
      "mediator":{"session_id":"m1","trust":"CONTROLLED_LAUNCHER_UNAUTHENTICATED","authentication_result":"NOT_PERFORMED"},
      "child_instance":{"pid":200,"identity":"NOT_PROVED","parent_binding_verified":True,"executable_sha256":"a"*64},
      "child_message":{"message_id":"msg-1","sequence":0,"payload_sha256":"b"*64,"trust":"UNTRUSTED_CHILD_INPUT"},
      "authority_effect":"NONE"
    }

def test_mediated_message_is_never_identity():
    r=validate_message_envelope(base())
    assert r["result"]=="R8B_MEDIATED_BOUNDARY_EVIDENCE_READY"
    assert r["child_identity"]=="NOT_PROVED"
    assert r["child_message_trust"]=="UNTRUSTED_CHILD_INPUT"
    assert r["authorization_status"]=="NOT_AUTHORIZED"

def test_child_cannot_self_assert_node_id():
    d=base(); d["child_message"]["node_id"]="3X"
    try:validate_message_envelope(d)
    except BoundaryDenied as e: assert e.code=="CHILD_AUTHORITY_FIELD_FORBIDDEN"
    else: assert False

def test_child_cannot_supply_token():
    d=base(); d["child_message"]["token"]="x"
    try:validate_message_envelope(d)
    except BoundaryDenied as e: assert e.code=="CHILD_AUTHORITY_FIELD_FORBIDDEN"
    else: assert False

def test_parent_binding_required():
    d=base(); d["child_instance"]["parent_binding_verified"]=False
    try:validate_message_envelope(d)
    except BoundaryDenied as e: assert e.code=="CHILD_PARENT_BINDING_REQUIRED"
    else: assert False

def test_mediator_cannot_preclaim_authentication():
    d=base(); d["mediator"]["authentication_result"]="VERIFIED"
    try:validate_message_envelope(d)
    except BoundaryDenied as e: assert e.code=="MEDIATOR_AUTH_PRECLAIMED"
    else: assert False
