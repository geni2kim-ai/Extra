# R8B mediated workload boundary

Status: `DESIGN/PREP ONLY / NO LIVE AUTHORITY`

## Decision

The controlled launcher/mediator is the only component that may eventually become an authenticated workload.

An opaque child process is treated as an **untrusted tool**, not as the authenticated principal.

## Trust split

### Controlled mediator
- project-owned code
- starts and tracks child process instance
- can bind child PID / parent PID / creation time / executable SHA
- may later authenticate itself through the R6/R8 lineage
- currently `UNAUTHENTICATED`

### Opaque child
- `identity=NOT_PROVED`
- receives no node credential
- receives no runtime grant
- receives no G1/F2 token
- cannot choose `node_id`, capabilities, principal or authority
- its output is `UNTRUSTED_CHILD_INPUT`

## Mediation rule

A child message can only become input to the mediator's policy/review layer.

The mediator may attach provenance such as:
- mediator session id
- exact child process-instance binding
- message sequence
- payload SHA-256
- receive timestamp

This provenance says **where the input came from**, not **who the child is**.

## Next step after R8.1 Windows PASS

R9 should authenticate the controlled mediator workload itself using the previously designed OS/workload proof
boundary. Only after the mediator is authenticated can policy decide whether a mediated child output is eligible
for any higher-level operation.

Even then, the grant remains bound to the mediator, not to the opaque child.
