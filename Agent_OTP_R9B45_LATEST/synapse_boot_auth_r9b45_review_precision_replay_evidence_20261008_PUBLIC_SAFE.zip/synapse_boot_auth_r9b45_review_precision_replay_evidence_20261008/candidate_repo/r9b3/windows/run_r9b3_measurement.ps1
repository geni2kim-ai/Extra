param(
    [Parameter(Mandatory=$true)][string]$MediatorExe,
    [Parameter(Mandatory=$true)][string]$BuildReceipt,
    [Parameter(Mandatory=$true)][string]$RegistryPath,
    [Parameter(Mandatory=$true)][string]$ExpectedRegistrySha256,
    [Parameter(Mandatory=$true)][string]$ExpectedMediatorSha256,
    [Parameter(Mandatory=$true)][string]$ExpectedServerScriptSha256,
    [Parameter(Mandatory=$true)][string]$ExpectedCaptureSourceSha256,
    [Parameter(Mandatory=$true)][string]$OutputDirectory,
    [string]$PythonExe = "python"
)
$ErrorActionPreference="Stop"

function Resolve-ExistingFile([string]$Value) {
    return (Resolve-Path -LiteralPath $Value -ErrorAction Stop).ProviderPath
}
function Resolve-OutputPath([string]$Value) {
    return $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($Value)
}
function Q([string]$Value) {
    if($Value.Contains('"')){throw "R9B3_QUOTE_IN_ARGUMENT_FORBIDDEN"}
    return '"'+$Value+'"'
}
function Write-Utf8([string]$PathValue,[string]$Text) {
    [IO.File]::WriteAllText($PathValue,$Text,(New-Object Text.UTF8Encoding($false)))
}
function Kill-Bounded($Process,[bool]$Started) {
    if(-not $Process -or -not $Started){return}
    try {
        if(-not $Process.HasExited){
            $Process.Kill()
            [void]$Process.WaitForExit(2000)
        }
    } catch {}
}

$exe=Resolve-ExistingFile $MediatorExe
$buildPath=Resolve-ExistingFile $BuildReceipt
$registryFile=Resolve-ExistingFile $RegistryPath
$out=Resolve-OutputPath $OutputDirectory
[IO.Directory]::CreateDirectory($out)|Out-Null

$repoRoot=Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$serverScript=Resolve-ExistingFile (Join-Path $repoRoot "r6\windows\invoke_r6_capture_server.ps1")
$captureSource=Resolve-ExistingFile (Join-Path $repoRoot "r6\windows\R6NamedPipeCapture.cs")
$preflightScript=Resolve-ExistingFile (Join-Path $repoRoot "r9b3\preflight.py")

$preflightPath=Join-Path $out "R9B3_preflight.raw.json"
& $PythonExe $preflightScript `
  --build-receipt $buildPath `
  --mediator-exe $exe `
  --registry $registryFile `
  --server-script $serverScript `
  --capture-source $captureSource `
  --expected-registry-sha256 $ExpectedRegistrySha256 `
  --expected-mediator-sha256 $ExpectedMediatorSha256 `
  --expected-server-script-sha256 $ExpectedServerScriptSha256 `
  --expected-capture-source-sha256 $ExpectedCaptureSourceSha256 `
  -o $preflightPath
if($LASTEXITCODE -ne 0){throw "R9B3_PREFLIGHT_DENIED"}
$preflight=Get-Content -LiteralPath $preflightPath -Raw|ConvertFrom-Json
if($preflight.status -ne "PREFLIGHT_PASS"){throw "R9B3_PREFLIGHT_STATUS_INVALID"}

$runId=[guid]::NewGuid().ToString("N")
$nonce=[guid]::NewGuid().ToString("N")
$pipeName="synapse-r9b3-"+$runId
$sessionId="r9b3-session-"+$runId
$issued=[DateTime]::UtcNow
$expires=$issued.AddMinutes(3)
$runContextPath=Join-Path $out "R9B3_run_context.json"
$preflightSha=(Get-FileHash -LiteralPath $preflightPath -Algorithm SHA256).Hash.ToLowerInvariant()
$runContext=[ordered]@{
 schema_version="SYNAPSE-R9B3-RUN-CONTEXT-1"
 run_id=$runId
 measurement_nonce=$nonce
 pipe_name=$pipeName
 node_session_id=$sessionId
 issued_at_utc=$issued.ToString("o")
 expires_at_utc=$expires.ToString("o")
 registry_sha256=$preflight.registry_sha256
 mediator_binary_sha256=$preflight.mediator_binary_sha256
 server_script_sha256=$preflight.server_script_sha256
 capture_source_sha256=$preflight.capture_source_sha256
 preflight_sha256=$preflightSha
 external_pin_mode=$preflight.external_pin_mode
 authentication_result="NOT_PERFORMED"
 authorization_status="NOT_AUTHORIZED"
 authority_effect="NONE"
}
$runContext|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $runContextPath -Encoding UTF8
$runContextSha=(Get-FileHash -LiteralPath $runContextPath -Algorithm SHA256).Hash.ToLowerInvariant()

$capturePath=Join-Path $out "R9B3_capture.raw.json"
$completionPath=Join-Path $out "R9B3_server_completion.json"
$summaryPath=Join-Path $out "measurement_harness_summary.json"
$failurePath=Join-Path $out "harness_failure.json"
$serverStdoutPath=Join-Path $out "server.stdout.txt"
$serverStderrPath=Join-Path $out "server.stderr.txt"
$clientStdoutPath=Join-Path $out "client.stdout.txt"
$clientStderrPath=Join-Path $out "client.stderr.txt"
$serverExitPath=Join-Path $out "server.exitcode.txt"
$clientExitPath=Join-Path $out "client.exitcode.txt"

$psExe=(Get-Command powershell.exe -CommandType Application -ErrorAction Stop).Source
$serverPsi=New-Object Diagnostics.ProcessStartInfo
$serverPsi.FileName=$psExe
$serverPsi.Arguments=(
 "-NoProfile -ExecutionPolicy Bypass -File "+(Q $serverScript)+
 " -PipeName "+$pipeName+
 " -AllowedClientSid "+$preflight.allowed_user_sid+
 " -NodeSessionId "+$sessionId+
 " -OutputPath "+(Q $capturePath)+
 " -CompletionPath "+(Q $completionPath)+
 " -ExpectedCaptureSourceSha256 "+$ExpectedCaptureSourceSha256+
 " -MaxRequestBytes 4096"
)
$serverPsi.UseShellExecute=$false
$serverPsi.CreateNoWindow=$true
$serverPsi.RedirectStandardOutput=$true
$serverPsi.RedirectStandardError=$true

$clientPsi=New-Object Diagnostics.ProcessStartInfo
$clientPsi.FileName=$exe
$clientPsi.Arguments="--measure-pipe "+$pipeName+" "+$nonce
$clientPsi.UseShellExecute=$false
$clientPsi.CreateNoWindow=$true
$clientPsi.RedirectStandardOutput=$true
$clientPsi.RedirectStandardError=$true

$server=New-Object Diagnostics.Process
$client=New-Object Diagnostics.Process
$server.StartInfo=$serverPsi
$client.StartInfo=$clientPsi
$serverStarted=$false;$clientStarted=$false
$serverOutTask=$null;$serverErrTask=$null;$clientOutTask=$null;$clientErrTask=$null
$failureCode=$null;$failureType=$null
$startedAt=[DateTime]::UtcNow

try {
    $serverStarted=$server.Start()
    if(-not $serverStarted){throw "R9B3_SERVER_START_FAILED"}
    $serverOutTask=$server.StandardOutput.ReadToEndAsync()
    $serverErrTask=$server.StandardError.ReadToEndAsync()

    $clientStarted=$client.Start()
    if(-not $clientStarted){throw "R9B3_CLIENT_START_FAILED"}
    $clientOutTask=$client.StandardOutput.ReadToEndAsync()
    $clientErrTask=$client.StandardError.ReadToEndAsync()

    if(-not $client.WaitForExit(15000)){throw "R9B3_CLIENT_TIMEOUT"}
    $client.WaitForExit()
    if(-not $server.WaitForExit(15000)){throw "R9B3_SERVER_TIMEOUT"}
    $server.WaitForExit()

    if([int]$server.ExitCode -ne 0){throw ("R9B3_SERVER_EXIT_NONZERO_"+[int]$server.ExitCode)}
    if([int]$client.ExitCode -ne 0){throw ("R9B3_CLIENT_EXIT_NONZERO_"+[int]$client.ExitCode)}
    if(-not(Test-Path -LiteralPath $capturePath -PathType Leaf)){throw "R9B3_CAPTURE_MISSING"}
    if(-not(Test-Path -LiteralPath $completionPath -PathType Leaf)){throw "R9B3_COMPLETION_MISSING"}

    $captureSha=(Get-FileHash -LiteralPath $capturePath -Algorithm SHA256).Hash.ToLowerInvariant()
    $completion=Get-Content -LiteralPath $completionPath -Raw|ConvertFrom-Json
    if($completion.capture_sha256 -cne $captureSha){throw "R9B3_COMPLETION_CAPTURE_SHA_MISMATCH"}
    if($completion.pipe_name -cne $pipeName){throw "R9B3_COMPLETION_PIPE_MISMATCH"}
    if($completion.node_session_id -cne $sessionId){throw "R9B3_COMPLETION_SESSION_MISMATCH"}
    if($completion.measurement_nonce -cne $nonce){throw "R9B3_COMPLETION_NONCE_MISMATCH"}
    if($completion.capture_source_sha256 -cne $ExpectedCaptureSourceSha256){throw "R9B3_COMPLETION_SOURCE_SHA_MISMATCH"}
    if($completion.authorization_status -ne "NOT_AUTHORIZED" -or $completion.authority_effect -ne "NONE"){
        throw "R9B3_COMPLETION_AUTHORITY_OVERCLAIM"
    }

    $postMediatorSha=(Get-FileHash -LiteralPath $exe -Algorithm SHA256).Hash.ToLowerInvariant()
    $postServerSha=(Get-FileHash -LiteralPath $serverScript -Algorithm SHA256).Hash.ToLowerInvariant()
    $postSourceSha=(Get-FileHash -LiteralPath $captureSource -Algorithm SHA256).Hash.ToLowerInvariant()
    if($postMediatorSha -cne $ExpectedMediatorSha256){throw "R9B3_MEDIATOR_POSTRUN_SHA_MISMATCH"}
    if($postServerSha -cne $ExpectedServerScriptSha256){throw "R9B3_SERVER_SCRIPT_POSTRUN_SHA_MISMATCH"}
    if($postSourceSha -cne $ExpectedCaptureSourceSha256){throw "R9B3_CAPTURE_SOURCE_POSTRUN_SHA_MISMATCH"}

    $completedAt=[DateTime]::UtcNow
    $summary=[ordered]@{
      schema_version="SYNAPSE-R9B3-MEASUREMENT-HARNESS-1"
      status="CAPTURE_READY"
      run_id=$runId
      measurement_nonce=$nonce
      pipe_name=$pipeName
      node_session_id=$sessionId
      started_at_utc=$startedAt.ToString("o")
      completed_at_utc=$completedAt.ToString("o")
      run_context_sha256=$runContextSha
      preflight_sha256=$preflightSha
      registry_sha256=$preflight.registry_sha256
      mediator_binary_sha256=$preflight.mediator_binary_sha256
      server_script_sha256=$preflight.server_script_sha256
      capture_source_sha256=$preflight.capture_source_sha256
      capture_sha256=$captureSha
      registry_created_by_measurement_runner=$false
      server_exit_code=[int]$server.ExitCode
      client_exit_code=[int]$client.ExitCode
      authentication_result="NOT_PERFORMED"
      authorization_status="NOT_AUTHORIZED"
      authority_effect="NONE"
    }
    $summary|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $summaryPath -Encoding UTF8
}
catch {
    $failureType=$_.Exception.GetType().Name
    $msg=[string]$_.Exception.Message
    if($msg -cmatch '\AR9B3_[A-Z0-9_]+\z'){$failureCode=$msg}else{$failureCode="R9B3_UNEXPECTED_HARNESS_ERROR"}
}
finally {
    Kill-Bounded $client $clientStarted
    Kill-Bounded $server $serverStarted

    $serverOut="";$serverErr="";$clientOut="";$clientErr=""
    try{if($serverOutTask){$serverOut=$serverOutTask.GetAwaiter().GetResult()}}catch{}
    try{if($serverErrTask){$serverErr=$serverErrTask.GetAwaiter().GetResult()}}catch{}
    try{if($clientOutTask){$clientOut=$clientOutTask.GetAwaiter().GetResult()}}catch{}
    try{if($clientErrTask){$clientErr=$clientErrTask.GetAwaiter().GetResult()}}catch{}
    Write-Utf8 $serverStdoutPath $serverOut
    Write-Utf8 $serverStderrPath $serverErr
    Write-Utf8 $clientStdoutPath $clientOut
    Write-Utf8 $clientStderrPath $clientErr

    $serverExit="UNAVAILABLE";$clientExit="UNAVAILABLE"
    try{if($serverStarted -and $server.HasExited){$serverExit=[string][int]$server.ExitCode}}catch{}
    try{if($clientStarted -and $client.HasExited){$clientExit=[string][int]$client.ExitCode}}catch{}
    Write-Utf8 $serverExitPath ($serverExit+[Environment]::NewLine)
    Write-Utf8 $clientExitPath ($clientExit+[Environment]::NewLine)

    if($failureCode){
      $failure=[ordered]@{
        schema_version="SYNAPSE-R9B3-HARNESS-FAILURE-1"
        status="FAILED"
        code=$failureCode
        exception_type=$failureType
        run_id=$runId
        run_context_sha256=$runContextSha
        server_started=$serverStarted
        client_started=$clientStarted
        server_exit_code=$serverExit
        client_exit_code=$clientExit
        cleanup_attempted=$true
        authorization_status="NOT_AUTHORIZED"
        authority_effect="NONE"
      }
      $failure|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $failurePath -Encoding UTF8
    }

    if($client){$client.Dispose()}
    if($server){$server.Dispose()}
}

if($failureCode){throw $failureCode}
Write-Host "R9B3_MEASUREMENT_CAPTURE_READY"
Write-Host "AUTHORITY_EFFECT=NONE"
