from __future__ import annotations
from datetime import datetime,timezone,timedelta
from r9b3.evaluator import evaluate
from r9b3.common import Denied

def artifacts(now=None):
    now=now or datetime.now(timezone.utc); issued=now-timedelta(seconds=5); captured=now-timedelta(seconds=3); completed=now-timedelta(seconds=2); end=now-timedelta(seconds=1); expires=now+timedelta(seconds=120)
    h='a'*64; reg='b'*64; srv='c'*64; src='d'*64; cap='e'*64; ctx='f'*64
    pipe='synapse-r9b3-abc'; session='r9b3-session-abc'; nonce='1'*32; run='2'*32; sid='S-1-5-21-123'
    capture={'schema_version':'SYNAPSE-R6-NAMED-PIPE-CAPTURE-1','captured_at_utc':captured.isoformat(),
      'pipe':{'name':pipe,'server_instance_id':'i1','remote_clients_rejected':True,'explicit_acl':True,'allowed_client_sid':sid},
      'client':{'pid':10,'pid_rechecked':10,'pipe_client_pid_rechecked':True,'pid_source':'GetNamedPipeClientProcessId',
        'process_creation_time_100ns':1,'process_creation_time_rechecked_100ns':1,'process_path':r'C:\x\R9B3_DedicatedMediator.exe',
        'process_path_rechecked':r'c:\X\R9B3_DedicatedMediator.exe','process_sha256':h,'process_sha256_semantics':'ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH',
        'loaded_image_hash_verified':False,'process_active_after_capture':True},
      'token':{'user_sid':sid,'token_source':'ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)','impersonation_succeeded':True},
      'evidence_source':'PIPE_PID_BEFORE_REQUEST+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK',
      'captured_node_session_id':session,'caller_claims':{'claimed_node_id':None,'claimed_workload_id':None,'measurement_nonce':nonce},
      'authentication_result':'CAPTURE_ONLY','authorization_status':'NOT_AUTHORIZED','runtime_grant_issued':False,'g1_token_issued':False,'f2_unlocked':False,'authority_effect':'NONE'}
    build={'schema_version':'SYNAPSE-R9B3-BUILD-RECEIPT-1','mediator_binary_sha256':h,'mediator_binary_name':'R9B3_DedicatedMediator.exe',
      'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}
    registry={'schema_version':'SYNAPSE-R9B3-PREPROVISIONED-VERIFIER-REGISTRY-1','registry_trust':'PREPROVISIONED_REHEARSAL_ONLY',
      'entries':[{'derived_workload_id':'W1','mediator_binary_sha256':h,'allowed_user_sid':sid}],
      'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}
    context={'schema_version':'SYNAPSE-R9B3-RUN-CONTEXT-1','run_id':run,'measurement_nonce':nonce,'pipe_name':pipe,'node_session_id':session,
      'issued_at_utc':issued.isoformat(),'expires_at_utc':expires.isoformat(),'registry_sha256':reg,'mediator_binary_sha256':h,
      'server_script_sha256':srv,'capture_source_sha256':src,'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}
    harness={'schema_version':'SYNAPSE-R9B3-MEASUREMENT-HARNESS-1','status':'CAPTURE_READY','run_id':run,'measurement_nonce':nonce,'pipe_name':pipe,'node_session_id':session,
      'started_at_utc':issued.isoformat(),'completed_at_utc':end.isoformat(),'run_context_sha256':ctx,'registry_sha256':reg,'mediator_binary_sha256':h,
      'server_script_sha256':srv,'capture_source_sha256':src,'capture_sha256':cap,'registry_created_by_measurement_runner':False,
      'server_exit_code':0,'client_exit_code':0,'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}
    completion={'schema_version':'SYNAPSE-R6-SERVER-COMPLETION-1','completed_at_utc':completed.isoformat(),'pipe_name':pipe,'server_instance_id':'i1',
      'node_session_id':session,'capture_sha256':cap,'measurement_nonce':nonce,'capture_source_sha256':src,'authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}
    hashes={'expected_registry_sha256':reg,'expected_mediator_sha256':h,'expected_server_script_sha256':srv,'expected_capture_source_sha256':src,
      'registry_sha256':reg,'mediator_binary_sha256':h,'server_script_sha256':srv,'capture_source_sha256':src,'capture_sha256':cap,'run_context_sha256':ctx}
    return capture,build,registry,context,harness,completion,hashes,now

def test_live_ready_is_run_bound_and_not_authenticated():
    a=artifacts();o=evaluate(*a[:-1],a[-1],True);assert o['result']=='R9B3_EXTERNALLY_PINNED_RUN_BOUND_MEASUREMENT_READY';assert o['authentication_result']=='MEASURED_NOT_AUTHENTICATED'

def test_old_capture_rejected_by_time_order():
    a=list(artifacts()); a[0]['captured_at_utc']='2019-01-01T00:00:00+00:00'
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code=='RUN_TIME_ORDER_INVALID'
    else:assert False

def test_wrong_session_rejected():
    a=list(artifacts());a[0]['captured_node_session_id']='other'
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code=='CAPTURE_SESSION_MISMATCH'
    else:assert False

def test_wrong_pipe_rejected():
    a=list(artifacts());a[0]['pipe']['name']='other'
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code=='CAPTURE_PIPE_MISMATCH'
    else:assert False

def test_wrong_nonce_rejected():
    a=list(artifacts());a[0]['caller_claims']['measurement_nonce']='0'*32
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code=='CAPTURE_NONCE_MISMATCH'
    else:assert False

def test_registry_created_flag_is_evidence_derived():
    a=list(artifacts());a[4]['registry_created_by_measurement_runner']=True
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code=='HARNESS_REGISTRY_SELF_ENROLLMENT'
    else:assert False

def test_loaded_image_hash_is_not_overclaimed():
    a=list(artifacts());a[0]['client']['loaded_image_hash_verified']=True
    try:evaluate(*a[:-1],a[-1],True)
    except Denied as e:assert e.code=='LOADED_IMAGE_HASH_CLAIM_INVALID'
    else:assert False
