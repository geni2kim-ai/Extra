from pathlib import Path
import json,subprocess,sys
ROOT=Path(__file__).parents[1]

def test_privacy_seal_blocks_sid_in_evidence(tmp_path):
    evidence=tmp_path/'evidence';evidence.mkdir();(evidence/'x.txt').write_text('user=S-1-5-21-12345',encoding='utf-8')
    out=tmp_path/'seal.json';cp=subprocess.run([sys.executable,str(ROOT/'distribution'/'privacy_seal.py'),str(tmp_path),'-o',str(out)],capture_output=True,text=True)
    doc=json.loads(out.read_text());assert cp.returncode==2;assert doc['status']=='BLOCKED_PRIVACY_MATCH';assert any(x['pattern_class']=='SID_LIKE' for x in doc['matches'])

def test_distributable_seal_has_no_literal_commitments(tmp_path):
    out=tmp_path/'seal.json';cp=subprocess.run([sys.executable,str(ROOT/'distribution'/'privacy_seal.py'),str(tmp_path),'-o',str(out)],capture_output=True,text=True)
    doc=json.loads(out.read_text());assert 'pattern_commitments' not in doc;assert doc['distributable_literal_commitments_emitted'] is False
