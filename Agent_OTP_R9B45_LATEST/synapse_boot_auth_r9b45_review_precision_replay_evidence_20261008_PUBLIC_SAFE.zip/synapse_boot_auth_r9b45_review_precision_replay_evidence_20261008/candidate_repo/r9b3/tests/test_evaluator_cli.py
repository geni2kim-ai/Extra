from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).parents[1]

def test_malformed_json_writes_typed_deny(tmp_path):
    bad=tmp_path/'bad.json';bad.write_text('{bad',encoding='utf-8')
    good=tmp_path/'good.json';good.write_text('{}',encoding='utf-8')
    exe=tmp_path/'m.exe';exe.write_bytes(b'x');server=tmp_path/'s.ps1';server.write_bytes(b's');src=tmp_path/'c.cs';src.write_bytes(b'c')
    out=tmp_path/'out.json';out.write_text('stale',encoding='utf-8')
    cp=subprocess.run([sys.executable,str(ROOT/'evaluate_r9b3.py'),str(bad),'--build-receipt',str(good),'--registry',str(good),
      '--run-context',str(good),'--harness-summary',str(good),'--server-completion',str(good),'--mediator-exe',str(exe),
      '--server-script',str(server),'--capture-source',str(src),'--expected-registry-sha256','0'*64,'--expected-mediator-sha256','0'*64,
      '--expected-server-script-sha256','0'*64,'--expected-capture-source-sha256','0'*64,'-o',str(out)],capture_output=True,text=True)
    doc=json.loads(out.read_text());assert cp.returncode==2;assert doc['result']=='R9B3_DENIED';assert 'Traceback' not in cp.stderr

def test_top_level_list_writes_typed_deny(tmp_path):
    bad=tmp_path/'bad.json';bad.write_text('[]',encoding='utf-8');good=tmp_path/'good.json';good.write_text('{}',encoding='utf-8')
    exe=tmp_path/'m.exe';exe.write_bytes(b'x');server=tmp_path/'s.ps1';server.write_bytes(b's');src=tmp_path/'c.cs';src.write_bytes(b'c');out=tmp_path/'out.json'
    cp=subprocess.run([sys.executable,str(ROOT/'evaluate_r9b3.py'),str(bad),'--build-receipt',str(good),'--registry',str(good),
      '--run-context',str(good),'--harness-summary',str(good),'--server-completion',str(good),'--mediator-exe',str(exe),
      '--server-script',str(server),'--capture-source',str(src),'--expected-registry-sha256','0'*64,'--expected-mediator-sha256','0'*64,
      '--expected-server-script-sha256','0'*64,'--expected-capture-source-sha256','0'*64,'-o',str(out)],capture_output=True,text=True)
    doc=json.loads(out.read_text());assert cp.returncode==2;assert doc['result']=='R9B3_DENIED'
