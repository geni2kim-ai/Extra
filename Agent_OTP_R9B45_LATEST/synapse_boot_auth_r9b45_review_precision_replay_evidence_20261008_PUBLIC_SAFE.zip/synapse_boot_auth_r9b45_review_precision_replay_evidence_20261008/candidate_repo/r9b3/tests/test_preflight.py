from __future__ import annotations
import json,subprocess,sys,hashlib
from pathlib import Path
ROOT=Path(__file__).parents[1]

def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()

def fixture(tmp_path:Path):
    mediator=tmp_path/'R9B3_DedicatedMediator.exe'; mediator.write_bytes(b'mediator')
    server=tmp_path/'server.ps1'; server.write_bytes(b'server')
    source=tmp_path/'capture.cs'; source.write_bytes(b'capture')
    build=tmp_path/'build.json'; build.write_text(json.dumps({
      'schema_version':'SYNAPSE-R9B3-BUILD-RECEIPT-1','mediator_binary_sha256':sha(mediator),
      'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}),encoding='utf-8')
    registry=tmp_path/'registry.json'; registry.write_text(json.dumps({
      'schema_version':'SYNAPSE-R9B3-PREPROVISIONED-VERIFIER-REGISTRY-1','registry_trust':'PREPROVISIONED_REHEARSAL_ONLY',
      'entries':[{'derived_workload_id':'W1','mediator_binary_sha256':sha(mediator),'allowed_user_sid':'S-1-5-21-123'}],
      'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}),encoding='utf-8')
    return mediator,server,source,build,registry

def run_preflight(tmp_path:Path,bad_registry=False):
    med,srv,src,bld,reg=fixture(tmp_path); out=tmp_path/'out.json'
    expected_reg=('0'*64 if bad_registry else sha(reg))
    cp=subprocess.run([sys.executable,str(ROOT/'preflight.py'),'--build-receipt',str(bld),'--mediator-exe',str(med),'--registry',str(reg),
      '--server-script',str(srv),'--capture-source',str(src),'--expected-registry-sha256',expected_reg,
      '--expected-mediator-sha256',sha(med),'--expected-server-script-sha256',sha(srv),'--expected-capture-source-sha256',sha(src),'-o',str(out)],capture_output=True,text=True)
    return cp,json.loads(out.read_text())

def test_preflight_hashes_exact_file_bytes(tmp_path):
    cp,out=run_preflight(tmp_path); assert cp.returncode==0; assert out['status']=='PREFLIGHT_PASS'

def test_bad_registry_pin_fails_before_runtime(tmp_path):
    cp,out=run_preflight(tmp_path,True); assert cp.returncode==2; assert out['code']=='REGISTRY_EXTERNAL_SHA_MISMATCH'

def test_registry_bytes_mutated_after_expected_hash_are_rejected(tmp_path):
    med,srv,src,bld,reg=fixture(tmp_path); expected=sha(reg); reg.write_text(reg.read_text()+"\n",encoding='utf-8'); out=tmp_path/'out.json'
    cp=subprocess.run([sys.executable,str(ROOT/'preflight.py'),'--build-receipt',str(bld),'--mediator-exe',str(med),'--registry',str(reg),
      '--server-script',str(srv),'--capture-source',str(src),'--expected-registry-sha256',expected,'--expected-mediator-sha256',sha(med),
      '--expected-server-script-sha256',sha(srv),'--expected-capture-source-sha256',sha(src),'-o',str(out)],capture_output=True,text=True)
    assert cp.returncode==2 and json.loads(out.read_text())['code']=='REGISTRY_EXTERNAL_SHA_MISMATCH'
