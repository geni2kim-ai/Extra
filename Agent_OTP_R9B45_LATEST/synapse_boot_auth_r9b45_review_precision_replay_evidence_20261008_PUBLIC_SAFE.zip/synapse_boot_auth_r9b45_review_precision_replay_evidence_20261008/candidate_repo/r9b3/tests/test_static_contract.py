from pathlib import Path
ROOT=Path(__file__).parents[1]
RUN=(ROOT/'windows'/'run_r9b3_measurement.ps1').read_text(encoding='utf-8')
SERVER=(ROOT.parents[0]/'r6'/'windows'/'invoke_r6_capture_server.ps1').read_text(encoding='utf-8')
CAP=(ROOT.parents[0]/'r6'/'windows'/'R6NamedPipeCapture.cs').read_text(encoding='utf-8')
LINT=(ROOT.parents[0]/'tools'/'powershell_semantic_lint.py').read_text(encoding='utf-8')

def test_external_sha_literals_required_before_server_start():
    for token in ('$ExpectedRegistrySha256','$ExpectedMediatorSha256','$ExpectedServerScriptSha256','$ExpectedCaptureSourceSha256'):
        assert token in RUN
    assert RUN.index('R9B3_PREFLIGHT_DENIED') < RUN.index('$serverStarted=$server.Start()')

def test_measurement_runner_does_not_create_registry():
    assert 'registry_created_by_measurement_runner=$false' in RUN
    assert 'WindowsIdentity]::GetCurrent' not in RUN

def test_failure_cleanup_and_evidence_always_present():
    assert 'Kill-Bounded $client $clientStarted' in RUN
    assert 'Kill-Bounded $server $serverStarted' in RUN
    assert 'harness_failure.json' in RUN
    assert 'server.stdout.txt' in RUN and 'client.stderr.txt' in RUN

def test_provider_aware_path_resolution():
    assert 'GetUnresolvedProviderPathFromPSPath' in RUN
    assert 'Resolve-Path -LiteralPath' in RUN

def test_r6_server_pins_capture_source_and_no_raw_output_path_log():
    assert '[string]$ExpectedCaptureSourceSha256' in SERVER
    assert 'CAPTURE_SOURCE_SHA256_MISMATCH' in SERVER
    assert 'Write-Host "WROTE_CAPTURE"' in SERVER
    assert 'Write-Host ("WROTE " + $OutputPath)' not in SERVER

def test_r6_pipe_pid_rechecked_and_hash_semantics_explicit():
    assert 'CLIENT_PID_RECHECK_FAILED' in CAP
    assert 'PIPE_CLIENT_PID_CHANGED' in CAP
    assert 'ProcessSha256Semantics = "ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH"' in CAP
    assert 'LoadedImageHashVerified = false' in CAP

def test_linter_scans_assignments_too():
    assert 'ASSIGN_RE' in LINT
    assert '"location":"assignment"' in LINT
