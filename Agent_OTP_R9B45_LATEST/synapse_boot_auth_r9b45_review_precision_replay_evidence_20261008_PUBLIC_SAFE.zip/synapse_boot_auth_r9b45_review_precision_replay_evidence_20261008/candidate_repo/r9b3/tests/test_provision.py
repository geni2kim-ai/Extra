from pathlib import Path
import subprocess,sys,json,hashlib
ROOT=Path(__file__).parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def test_provision_refuses_overwrite_and_hashes_actual_exe(tmp_path):
    exe=tmp_path/'m.exe';exe.write_bytes(b'x');build=tmp_path/'b.json';build.write_text(json.dumps({'schema_version':'SYNAPSE-R9B3-BUILD-RECEIPT-1','mediator_binary_sha256':sha(exe),'authentication_result':'NOT_PERFORMED','authorization_status':'NOT_AUTHORIZED','authority_effect':'NONE'}))
    out=tmp_path/'r.json';cmd=[sys.executable,str(ROOT/'provision_registry.py'),'--build-receipt',str(build),'--mediator-exe',str(exe),'--allowed-user-sid','S-1-5-21-123','--derived-workload-id','W1','-o',str(out)]
    assert subprocess.run(cmd,capture_output=True).returncode==0
    assert subprocess.run(cmd,capture_output=True).returncode==2
    exe.write_bytes(b'y');out2=tmp_path/'r2.json';cmd[-1]=str(out2)
    assert subprocess.run(cmd,capture_output=True).returncode==2
