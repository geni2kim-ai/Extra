# R9B.3 security limitations

R9B.3 is still **measurement rehearsal**, not authentication.

## Explicit residuals

1. **Operator SHA literals are not a protected credential.**
   R9B.3 requires expected registry/mediator/server/C# SHA-256 values as separate operator-supplied inputs. This removes the R9B.2 registry+pin pair self-consistency bug, but the provenance of those literals is not cryptographically proven by this package.
2. **Executable SHA is an on-disk file hash.**
   The verifier hashes the executable at the OS-reported process path. It does not hash the already-loaded in-memory image. The receipt states `loaded_image_hash_verified=false`.
3. **Same-user execution remains possible.**
   A process with equivalent local execution rights can launch the same approved binary. No non-exportable installation credential exists yet.
4. **Named Pipe ACL is not the final identity boundary.**
   Impersonated SID, process evidence, nonce/run binding and registry match are all required. ACL alone is insufficient.
5. **CodeDiff review gate remains unsatisfied.**
   Official TextDiff assets are incomplete in the bundled snapshot. `trusted_for_gate=false`; required ADVERSARIAL/HUMAN review is not met.
6. **Windows execution is not performed in the preparation environment.**
   R9B.3 must be exercised on YM before any next-phase credential work.

## Authority ceiling

- `authentication_result = MEASURED_NOT_AUTHENTICATED`
- `stable_node_id = UNBOUND`
- `authorization_status = NOT_AUTHORIZED`
- `runtime_grant_issued = false`
- `g1_token_issued = false`
- `f2_unlocked = false`
- `authority_effect = NONE`
