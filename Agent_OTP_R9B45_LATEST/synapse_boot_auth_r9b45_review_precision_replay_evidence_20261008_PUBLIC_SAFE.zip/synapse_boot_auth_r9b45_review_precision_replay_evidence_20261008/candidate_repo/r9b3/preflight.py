#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from r9b3.common import Denied, load_json_bytes, require_hex64, require_sid, require_workload, sha_bytes

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--build-receipt",required=True)
    ap.add_argument("--mediator-exe",required=True)
    ap.add_argument("--registry",required=True)
    ap.add_argument("--server-script",required=True)
    ap.add_argument("--capture-source",required=True)
    ap.add_argument("--expected-registry-sha256",required=True)
    ap.add_argument("--expected-mediator-sha256",required=True)
    ap.add_argument("--expected-server-script-sha256",required=True)
    ap.add_argument("--expected-capture-source-sha256",required=True)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    out=Path(ns.output)
    try:
        exp_registry=require_hex64(ns.expected_registry_sha256,"EXPECTED_REGISTRY_SHA_INVALID")
        exp_mediator=require_hex64(ns.expected_mediator_sha256,"EXPECTED_MEDIATOR_SHA_INVALID")
        exp_server=require_hex64(ns.expected_server_script_sha256,"EXPECTED_SERVER_SCRIPT_SHA_INVALID")
        exp_source=require_hex64(ns.expected_capture_source_sha256,"EXPECTED_CAPTURE_SOURCE_SHA_INVALID")
        build_bytes,build=load_json_bytes(Path(ns.build_receipt),"BUILD_RECEIPT")
        registry_bytes,registry=load_json_bytes(Path(ns.registry),"REGISTRY")
        mediator_bytes=Path(ns.mediator_exe).read_bytes()
        server_bytes=Path(ns.server_script).read_bytes()
        source_bytes=Path(ns.capture_source).read_bytes()
        actual_registry=sha_bytes(registry_bytes); actual_mediator=sha_bytes(mediator_bytes)
        actual_server=sha_bytes(server_bytes); actual_source=sha_bytes(source_bytes)
        if actual_registry!=exp_registry: raise Denied("REGISTRY_EXTERNAL_SHA_MISMATCH")
        if actual_mediator!=exp_mediator: raise Denied("MEDIATOR_EXTERNAL_SHA_MISMATCH")
        if actual_server!=exp_server: raise Denied("SERVER_SCRIPT_EXTERNAL_SHA_MISMATCH")
        if actual_source!=exp_source: raise Denied("CAPTURE_SOURCE_EXTERNAL_SHA_MISMATCH")
        if build.get("schema_version")!="SYNAPSE-R9B3-BUILD-RECEIPT-1": raise Denied("BUILD_SCHEMA_INVALID")
        if registry.get("schema_version")!="SYNAPSE-R9B3-PREPROVISIONED-VERIFIER-REGISTRY-1": raise Denied("REGISTRY_SCHEMA_INVALID")
        if registry.get("registry_trust")!="PREPROVISIONED_REHEARSAL_ONLY": raise Denied("REGISTRY_TRUST_INVALID")
        if build.get("authentication_result")!="NOT_PERFORMED" or build.get("authorization_status")!="NOT_AUTHORIZED" or build.get("authority_effect")!="NONE": raise Denied("BUILD_AUTHORITY_OVERCLAIM")
        if registry.get("authentication_result")!="NOT_PERFORMED" or registry.get("authorization_status")!="NOT_AUTHORIZED" or registry.get("authority_effect")!="NONE": raise Denied("REGISTRY_AUTHORITY_OVERCLAIM")
        build_sha=require_hex64(build.get("mediator_binary_sha256"),"BUILD_MEDIATOR_SHA_INVALID")
        if build_sha!=actual_mediator: raise Denied("BUILD_MEDIATOR_SHA_MISMATCH")
        entries=registry.get("entries")
        if not isinstance(entries,list): raise Denied("REGISTRY_ENTRIES_INVALID")
        matched=[]
        for e in entries:
            if not isinstance(e,dict): continue
            if e.get("mediator_binary_sha256")==actual_mediator:
                matched.append(e)
        if len(matched)!=1: raise Denied("REGISTRY_BINARY_MATCH_NOT_UNIQUE")
        entry=matched[0]
        sid=require_sid(entry.get("allowed_user_sid"),"REGISTRY_ALLOWED_SID_INVALID")
        workload=require_workload(entry.get("derived_workload_id"),"REGISTRY_WORKLOAD_ID_INVALID")
        result={
          "schema_version":"SYNAPSE-R9B3-PREFLIGHT-1","status":"PREFLIGHT_PASS",
          "registry_sha256":actual_registry,"mediator_binary_sha256":actual_mediator,
          "server_script_sha256":actual_server,"capture_source_sha256":actual_source,
          "build_receipt_sha256":sha_bytes(build_bytes),"allowed_user_sid":sid,"derived_workload_id":workload,
          "external_pin_mode":"OPERATOR_SUPPLIED_SHA256_LITERALS_REHEARSAL",
          "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"
        }
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
        print(json.dumps({"status":"PREFLIGHT_PASS","authority_effect":"NONE"}))
        return 0
    except Denied as e:
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps({"schema_version":"SYNAPSE-R9B3-PREFLIGHT-1","status":"DENIED","code":e.code,"authority_effect":"NONE"},indent=2)+"\n",encoding="utf-8")
        print(json.dumps({"status":"DENIED","code":e.code,"authority_effect":"NONE"}))
        return 2
    except Exception:
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps({"schema_version":"SYNAPSE-R9B3-PREFLIGHT-1","status":"DENIED","code":"UNEXPECTED_PREFLIGHT_ERROR","authority_effect":"NONE"},indent=2)+"\n",encoding="utf-8")
        print(json.dumps({"status":"DENIED","code":"UNEXPECTED_PREFLIGHT_ERROR","authority_effect":"NONE"}))
        return 2
if __name__=="__main__": raise SystemExit(main())
