# R9B.3 — externally pinned, run-bound workload measurement rehearsal

R9B.3 is the remediation successor to R9B.2 after adversarial review.

It fixes the high/medium findings without opening authentication or authority.

## Main changes

- removes registry+pin-file self-consistency as the trust decision;
- requires operator-supplied expected SHA-256 literals for:
  - pre-provisioned registry,
  - mediator executable,
  - R6 server PowerShell,
  - R6 C# capture source;
- reads and hashes the exact registry bytes that are parsed;
- R6 server independently verifies the C# capture source SHA before `Add-Type`;
- pipe client PID is captured before request processing and rechecked before completion;
- process SHA semantics are explicitly `ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH` and never claimed as loaded-image verification;
- every measurement has a fresh run ID, pipe, session and nonce;
- evaluator consumes capture + run context + harness summary + server completion and checks timestamps/freshness;
- harness success fields are derived from evidence, not hardcoded assumptions;
- failure paths attempt bounded child cleanup and always write stdout/stderr/exit/failure evidence;
- PowerShell paths are resolved with provider-aware APIs;
- privacy seal scans evidence for SID-like values and no longer publishes low-entropy literal commitments;
- PowerShell semantic lint checks ordinary assignments as well as function parameters;
- current package manifest/evidence are regenerated from the current tree.

## Ceiling

`R9B3_EXTERNALLY_PINNED_RUN_BOUND_MEASUREMENT_READY` may only mean:

`MEASURED_NOT_AUTHENTICATED / stable_node_id=UNBOUND / NOT_AUTHORIZED / NONE`

It is not a node credential and cannot open G1/F2.
