from __future__ import annotations
import hashlib, json, re
from pathlib import Path
from typing import Any

HEX64 = re.compile(r"[0-9a-f]{64}")
SID = re.compile(r"S-[0-9]+(?:-[0-9]+){2,}")
WORKLOAD = re.compile(r"[A-Za-z0-9._:-]{1,80}")

class Denied(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code

def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def read_bytes(path: Path) -> bytes:
    return path.read_bytes()

def load_json_bytes(path: Path, code: str) -> tuple[bytes, dict[str, Any]]:
    data = read_bytes(path)
    try:
        obj = json.loads(data.decode("utf-8-sig"))
    except Exception as exc:
        raise Denied(code + "_JSON_INVALID") from exc
    if not isinstance(obj, dict):
        raise Denied(code + "_TOP_LEVEL_NOT_OBJECT")
    return data, obj

def require_hex64(value: object, code: str) -> str:
    if not isinstance(value, str) or HEX64.fullmatch(value) is None:
        raise Denied(code)
    return value

def require_sid(value: object, code: str) -> str:
    if not isinstance(value, str) or SID.fullmatch(value) is None:
        raise Denied(code)
    return value

def require_workload(value: object, code: str) -> str:
    if not isinstance(value, str) or WORKLOAD.fullmatch(value) is None:
        raise Denied(code)
    return value
