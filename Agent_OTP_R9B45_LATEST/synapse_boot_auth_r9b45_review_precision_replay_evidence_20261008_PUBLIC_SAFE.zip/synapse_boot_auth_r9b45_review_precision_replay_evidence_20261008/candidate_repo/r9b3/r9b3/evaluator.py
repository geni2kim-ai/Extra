from __future__ import annotations
from datetime import datetime, timezone
from pathlib import PureWindowsPath
from typing import Any
from .common import Denied, require_hex64, require_sid, require_workload

def obj(value: object, code: str) -> dict[str, Any]:
    if not isinstance(value, dict): raise Denied(code)
    return value

def arr(value: object, code: str) -> list[Any]:
    if not isinstance(value, list): raise Denied(code)
    return value

def text(value: object, code: str) -> str:
    if not isinstance(value, str) or not value: raise Denied(code)
    return value

def integer(value: object, code: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool): raise Denied(code)
    return value

def boolean(value: object, code: str) -> bool:
    if not isinstance(value, bool): raise Denied(code)
    return value

def parse_time(value: object, code: str) -> datetime:
    s=text(value,code)
    try:
        dt=datetime.fromisoformat(s.replace("Z","+00:00"))
    except Exception as exc:
        raise Denied(code) from exc
    if dt.tzinfo is None: raise Denied(code)
    return dt.astimezone(timezone.utc)

def evaluate(
    capture: dict[str,Any], build: dict[str,Any], registry: dict[str,Any],
    run_context: dict[str,Any], harness: dict[str,Any], completion: dict[str,Any],
    hashes: dict[str,str], now_utc: datetime, require_fresh: bool,
) -> dict[str,Any]:
    if capture.get("schema_version")!="SYNAPSE-R6-NAMED-PIPE-CAPTURE-1": raise Denied("CAPTURE_SCHEMA_INVALID")
    if build.get("schema_version")!="SYNAPSE-R9B3-BUILD-RECEIPT-1": raise Denied("BUILD_SCHEMA_INVALID")
    if registry.get("schema_version")!="SYNAPSE-R9B3-PREPROVISIONED-VERIFIER-REGISTRY-1": raise Denied("REGISTRY_SCHEMA_INVALID")
    if run_context.get("schema_version")!="SYNAPSE-R9B3-RUN-CONTEXT-1": raise Denied("RUN_CONTEXT_SCHEMA_INVALID")
    if harness.get("schema_version")!="SYNAPSE-R9B3-MEASUREMENT-HARNESS-1": raise Denied("HARNESS_SCHEMA_INVALID")
    if completion.get("schema_version")!="SYNAPSE-R6-SERVER-COMPLETION-1": raise Denied("COMPLETION_SCHEMA_INVALID")

    for name,doc in (("capture",capture),("build",build),("registry",registry),("run_context",run_context),("harness",harness),("completion",completion)):
        if doc.get("authority_effect")!="NONE": raise Denied(name.upper()+"_AUTHORITY_EFFECT_NOT_NONE")
    if capture.get("authorization_status")!="NOT_AUTHORIZED" or build.get("authorization_status")!="NOT_AUTHORIZED" or run_context.get("authorization_status")!="NOT_AUTHORIZED" or harness.get("authorization_status")!="NOT_AUTHORIZED" or completion.get("authorization_status")!="NOT_AUTHORIZED":
        raise Denied("AUTHORIZATION_PRECLAIMED")
    if capture.get("authentication_result")!="CAPTURE_ONLY" or build.get("authentication_result")!="NOT_PERFORMED" or run_context.get("authentication_result")!="NOT_PERFORMED" or harness.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("AUTHENTICATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if capture.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")

    expected_registry=require_hex64(hashes.get("expected_registry_sha256"),"EXPECTED_REGISTRY_SHA_INVALID")
    expected_mediator=require_hex64(hashes.get("expected_mediator_sha256"),"EXPECTED_MEDIATOR_SHA_INVALID")
    expected_server=require_hex64(hashes.get("expected_server_script_sha256"),"EXPECTED_SERVER_SCRIPT_SHA_INVALID")
    expected_source=require_hex64(hashes.get("expected_capture_source_sha256"),"EXPECTED_CAPTURE_SOURCE_SHA_INVALID")
    if hashes.get("registry_sha256")!=expected_registry: raise Denied("REGISTRY_EXTERNAL_SHA_MISMATCH")
    if hashes.get("mediator_binary_sha256")!=expected_mediator: raise Denied("MEDIATOR_EXTERNAL_SHA_MISMATCH")
    if hashes.get("server_script_sha256")!=expected_server: raise Denied("SERVER_SCRIPT_EXTERNAL_SHA_MISMATCH")
    if hashes.get("capture_source_sha256")!=expected_source: raise Denied("CAPTURE_SOURCE_EXTERNAL_SHA_MISMATCH")

    for field,expected in (("registry_sha256",expected_registry),("mediator_binary_sha256",expected_mediator),("server_script_sha256",expected_server),("capture_source_sha256",expected_source)):
        if run_context.get(field)!=expected: raise Denied("RUN_CONTEXT_"+field.upper()+"_MISMATCH")
        if harness.get(field)!=expected: raise Denied("HARNESS_"+field.upper()+"_MISMATCH")
    if completion.get("capture_source_sha256")!=expected_source: raise Denied("COMPLETION_CAPTURE_SOURCE_SHA_MISMATCH")
    if build.get("mediator_binary_sha256")!=expected_mediator: raise Denied("BUILD_MEDIATOR_SHA_MISMATCH")

    run_id=text(run_context.get("run_id"),"RUN_ID_INVALID")
    nonce=text(run_context.get("measurement_nonce"),"RUN_NONCE_INVALID")
    pipe_name=text(run_context.get("pipe_name"),"RUN_PIPE_INVALID")
    session_id=text(run_context.get("node_session_id"),"RUN_SESSION_INVALID")
    if harness.get("run_id")!=run_id: raise Denied("HARNESS_RUN_ID_MISMATCH")
    if harness.get("measurement_nonce")!=nonce: raise Denied("HARNESS_NONCE_MISMATCH")
    if harness.get("pipe_name")!=pipe_name: raise Denied("HARNESS_PIPE_MISMATCH")
    if harness.get("node_session_id")!=session_id: raise Denied("HARNESS_SESSION_MISMATCH")
    if harness.get("run_context_sha256")!=hashes.get("run_context_sha256"): raise Denied("HARNESS_RUN_CONTEXT_SHA_MISMATCH")
    if harness.get("status")!="CAPTURE_READY": raise Denied("HARNESS_STATUS_INVALID")
    if harness.get("registry_created_by_measurement_runner") is not False: raise Denied("HARNESS_REGISTRY_SELF_ENROLLMENT")
    if integer(harness.get("server_exit_code"),"SERVER_EXIT_INVALID")!=0 or integer(harness.get("client_exit_code"),"CLIENT_EXIT_INVALID")!=0:
        raise Denied("HARNESS_PROCESS_EXIT_NONZERO")

    pipe=obj(capture.get("pipe"),"PIPE_NOT_OBJECT")
    if pipe.get("name")!=pipe_name: raise Denied("CAPTURE_PIPE_MISMATCH")
    if pipe.get("remote_clients_rejected") is not True or pipe.get("explicit_acl") is not True: raise Denied("PIPE_BOUNDARY_INVALID")
    if capture.get("captured_node_session_id")!=session_id: raise Denied("CAPTURE_SESSION_MISMATCH")
    claims=obj(capture.get("caller_claims"),"CALLER_CLAIMS_NOT_OBJECT")
    if claims.get("claimed_node_id") is not None or claims.get("claimed_workload_id") is not None: raise Denied("CLIENT_IDENTITY_CLAIMS_MUST_BE_ABSENT")
    if claims.get("measurement_nonce")!=nonce: raise Denied("CAPTURE_NONCE_MISMATCH")

    client=obj(capture.get("client"),"CLIENT_NOT_OBJECT")
    if client.get("pid_source")!="GetNamedPipeClientProcessId": raise Denied("CLIENT_PID_SOURCE_INVALID")
    pid=integer(client.get("pid"),"CLIENT_PID_INVALID")
    if integer(client.get("pid_rechecked"),"CLIENT_PID_RECHECK_INVALID")!=pid: raise Denied("PIPE_CLIENT_PID_RECHECK_MISMATCH")
    if client.get("pipe_client_pid_rechecked") is not True: raise Denied("PIPE_CLIENT_PID_RECHECK_NOT_CONFIRMED")
    if client.get("process_creation_time_100ns")!=client.get("process_creation_time_rechecked_100ns"): raise Denied("CLIENT_INSTANCE_RECHECK_FAILED")
    p1=text(client.get("process_path"),"CLIENT_PATH_INVALID"); p2=text(client.get("process_path_rechecked"),"CLIENT_PATH_RECHECK_INVALID")
    if p1.casefold()!=p2.casefold(): raise Denied("CLIENT_PATH_RECHECK_FAILED")
    if client.get("process_active_after_capture") is not True: raise Denied("CLIENT_NOT_ACTIVE")
    if capture.get("evidence_source")!="PIPE_PID_BEFORE_REQUEST+OpenProcess+GetProcessTimes+QueryFullProcessImageName+PIPE_PID_RECHECK": raise Denied("CLIENT_EVIDENCE_SOURCE_INVALID")
    observed_sha=require_hex64(client.get("process_sha256"),"CLIENT_SHA_INVALID")
    if observed_sha!=expected_mediator: raise Denied("MEDIATOR_BINARY_SHA_MISMATCH")
    if client.get("process_sha256_semantics")!="ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH": raise Denied("PROCESS_SHA_SEMANTICS_INVALID")
    if client.get("loaded_image_hash_verified") is not False: raise Denied("LOADED_IMAGE_HASH_CLAIM_INVALID")
    if PureWindowsPath(p1).name.casefold()!=str(build.get("mediator_binary_name","")).casefold(): raise Denied("MEDIATOR_BINARY_NAME_MISMATCH")

    token=obj(capture.get("token"),"TOKEN_NOT_OBJECT")
    if token.get("impersonation_succeeded") is not True: raise Denied("CLIENT_IMPERSONATION_REQUIRED")
    if token.get("token_source")!="ImpersonateNamedPipeClient+WindowsIdentity.GetCurrent(true)": raise Denied("TOKEN_SOURCE_INVALID")
    sid=require_sid(token.get("user_sid"),"CLIENT_SID_INVALID")
    if pipe.get("allowed_client_sid")!=sid: raise Denied("PIPE_ALLOWED_SID_MISMATCH")

    entries=arr(registry.get("entries"),"REGISTRY_ENTRIES_INVALID")
    found=[]
    for entry in entries:
        if not isinstance(entry,dict): continue
        if entry.get("mediator_binary_sha256")==observed_sha and entry.get("allowed_user_sid")==sid:
            found.append(entry)
    if len(found)!=1: raise Denied("REGISTRY_MATCH_NOT_UNIQUE")
    workload=require_workload(found[0].get("derived_workload_id"),"DERIVED_WORKLOAD_ID_INVALID")
    if registry.get("registry_trust")!="PREPROVISIONED_REHEARSAL_ONLY": raise Denied("REGISTRY_TRUST_INVALID")

    capture_sha=require_hex64(hashes.get("capture_sha256"),"CAPTURE_SHA_INVALID")
    if harness.get("capture_sha256")!=capture_sha: raise Denied("HARNESS_CAPTURE_SHA_MISMATCH")
    if completion.get("capture_sha256")!=capture_sha: raise Denied("COMPLETION_CAPTURE_SHA_MISMATCH")
    if completion.get("pipe_name")!=pipe_name: raise Denied("COMPLETION_PIPE_MISMATCH")
    if completion.get("node_session_id")!=session_id: raise Denied("COMPLETION_SESSION_MISMATCH")
    if completion.get("measurement_nonce")!=nonce: raise Denied("COMPLETION_NONCE_MISMATCH")
    if completion.get("server_instance_id")!=pipe.get("server_instance_id"): raise Denied("COMPLETION_SERVER_INSTANCE_MISMATCH")

    issued=parse_time(run_context.get("issued_at_utc"),"RUN_ISSUED_TIME_INVALID")
    expires=parse_time(run_context.get("expires_at_utc"),"RUN_EXPIRES_TIME_INVALID")
    hstart=parse_time(harness.get("started_at_utc"),"HARNESS_START_TIME_INVALID")
    captured=parse_time(capture.get("captured_at_utc"),"CAPTURE_TIME_INVALID")
    completed=parse_time(completion.get("completed_at_utc"),"COMPLETION_TIME_INVALID")
    hend=parse_time(harness.get("completed_at_utc"),"HARNESS_END_TIME_INVALID")
    if expires<=issued or (expires-issued).total_seconds()>180: raise Denied("RUN_WINDOW_INVALID")
    if not (issued <= hstart <= captured <= completed <= hend <= expires): raise Denied("RUN_TIME_ORDER_INVALID")
    now_utc=now_utc.astimezone(timezone.utc)
    fresh=issued <= now_utc <= expires
    if require_fresh and not fresh: raise Denied("RUN_CONTEXT_NOT_FRESH_AT_EVALUATION")

    result_name="R9B3_EXTERNALLY_PINNED_RUN_BOUND_MEASUREMENT_READY" if require_fresh else "R9B3_OFFLINE_ARTIFACT_SET_BOUND"
    return {
      "result":result_name,
      "derived_workload_id":workload,
      "registry_binding":"EXTERNAL_EXPECTED_SHA256_MATCH_REHEARSAL",
      "registry_created_by_measurement_runner":boolean(harness.get("registry_created_by_measurement_runner"),"HARNESS_REGISTRY_FLAG_INVALID"),
      "run_binding":"PIPE+SESSION+NONCE+CAPTURE_SHA+COMPLETION+HARNESS",
      "fresh_at_evaluation":fresh,
      "process_sha256_semantics":"ON_DISK_EXECUTABLE_AT_OS_REPORTED_PATH",
      "loaded_image_hash_verified":False,
      "measurement_result":"MEASURED",
      "authentication_result":"MEASURED_NOT_AUTHENTICATED",
      "stable_node_id":"UNBOUND",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE",
      "review_gate":"UNSATISFIED_CODEDIFF_ADVERSARIAL_REQUIRED",
      "next_action":"HOLD_R9C_UNTIL_WINDOWS_REHEARSAL_AND_REVIEW_GATE"
    }
