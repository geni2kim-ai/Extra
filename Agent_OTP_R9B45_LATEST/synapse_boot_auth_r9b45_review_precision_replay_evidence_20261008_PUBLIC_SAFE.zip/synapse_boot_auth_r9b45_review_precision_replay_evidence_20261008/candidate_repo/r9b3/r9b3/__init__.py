"""R9B.3 pinned-source, run-bound workload measurement rehearsal."""
