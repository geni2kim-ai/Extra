#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("raw_capture");ap.add_argument("-o","--output",required=True);ap.add_argument("--lineage",required=True)
    ns=ap.parse_args();raw=Path(ns.raw_capture);out=Path(ns.output);lin=Path(ns.lineage);d=json.loads(raw.read_text(encoding="utf-8-sig"))
    pipe=d.get("pipe") or {};client=d.get("client") or {};token=d.get("token") or {}
    for k in ("allowed_client_sid","server_sid"):
        if k in pipe:pipe[k]="SID_MASKED"
    for k in ("process_path","process_path_rechecked"):
        if k in client:client[k]="PATH_MASKED"
    if "user_sid" in token:token["user_sid"]="SID_MASKED"
    if "service_sids" in token:token["service_sids"]=["SID_MASKED" for _ in (token.get("service_sids") or [])]
    out.write_text(json.dumps(d,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    lin.write_text(json.dumps({"schema_version":"SYNAPSE-R9B3-CAPTURE-MASKING-LINEAGE-1","raw_capture_sha256":sha(raw),"masked_capture_sha256":sha(out),
      "masked_fields":["pipe.allowed_client_sid","pipe.server_sid","client.process_path","client.process_path_rechecked","token.user_sid","token.service_sids"],"authority_effect":"NONE"},indent=2)+"\n",encoding="utf-8")
    return 0
if __name__=="__main__":raise SystemExit(main())
