#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,os,subprocess
from pathlib import Path
ENV_KEYS=("USERNAME","USER","COMPUTERNAME","USERPROFILE","HOME","TEMP","TMP")
def variants(v:str)->list[str]: return sorted(x for x in {v,v.replace("\\","/"),v.replace("/","\\")} if len(x)>=3)
def current_windows_sid()->str|None:
    if os.name!="nt": return None
    try:
        cp=subprocess.run(["whoami","/user","/fo","csv","/nh"],capture_output=True,text=True,timeout=5,check=True)
        fields=[x.strip().strip('"') for x in cp.stdout.strip().split(',')]
        for f in fields:
            if f.startswith("S-"): return f
    except Exception: return None
    return None
def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--source-id",required=True);ap.add_argument("--extra",action="append",default=[])
    ap.add_argument("--extra-sid",action="append",default=[]);ap.add_argument("--auto-current-sid",action="store_true");ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();rows=[];seen=set()
    def add(cls,val):
        for x in variants(val):
            if x.casefold() not in seen: seen.add(x.casefold());rows.append({"class":cls,"literal":x})
    for k in ENV_KEYS:
        v=os.environ.get(k)
        if v:add("ENV_"+k,v)
    for i,v in enumerate(ns.extra,1):add(f"EXTRA_{i:03d}",v)
    sids=list(ns.extra_sid)
    if ns.auto_current_sid:
        sid=current_windows_sid()
        if not sid: raise SystemExit("CURRENT_WINDOWS_SID_UNAVAILABLE")
        sids.append(sid)
    for i,v in enumerate(sids,1):add(f"SID_{i:03d}",v)
    result={"schema_version":"SYNAPSE-PRIVACY-SOURCE-MATERIAL-2","source_id":ns.source_id,"patterns":rows,"distribution":"LOCAL_ONLY_DO_NOT_PACKAGE"}
    Path(ns.output).write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({"source_id":ns.source_id,"patterns":len(rows),"sid_patterns":len(sids),"distribution":result["distribution"]}));return 0
if __name__=="__main__": raise SystemExit(main())
