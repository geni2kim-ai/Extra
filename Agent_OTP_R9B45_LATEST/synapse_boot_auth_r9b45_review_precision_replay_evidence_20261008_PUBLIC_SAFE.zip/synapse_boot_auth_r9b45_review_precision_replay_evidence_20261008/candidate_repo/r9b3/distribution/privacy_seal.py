#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,os,re
from pathlib import Path
from typing import Iterable

ENV_KEYS=("COMPUTERNAME","USERPROFILE","HOME","TEMP","TMP")
SID_RE=re.compile(r"(?<![A-Za-z0-9])S-[0-9]+(?:-[0-9]+){2,}(?![0-9-])")
EVIDENCE_PARTS={"evidence","review","reviews","logs","reports","deliverable","output","outputs","result","results"}

def variants(value:str)->set[str]:
    # Avoid low-entropy host literals (for example USER=root) that create broad false positives.
    # Short/sensitive values such as the actual SID should be supplied through local-only source material.
    return {x for x in {value,value.replace("\\","/"),value.replace("/","\\")} if len(x)>=8}

def current_host_patterns()->list[tuple[str,str,str]]:
    rows=[]
    for key in ENV_KEYS:
        value=os.environ.get(key)
        if value:
            for v in variants(value): rows.append(("CURRENT_HOST",f"ENV_{key}",v))
    return rows

def encodings(value:str)->list[bytes]:
    return [value.encode("utf-8",errors="ignore"),value.encode("utf-16le",errors="ignore"),value.encode("utf-16be",errors="ignore")]

def load_source_material(paths:Iterable[str])->tuple[list[tuple[str,str,str]],list[str]]:
    rows=[];ids=[]
    for raw in paths:
        doc=json.loads(Path(raw).read_text(encoding="utf-8-sig"))
        if doc.get("schema_version")!="SYNAPSE-PRIVACY-SOURCE-MATERIAL-2": raise ValueError("PRIVACY_SOURCE_MATERIAL_SCHEMA_INVALID")
        sid=str(doc.get("source_id") or "")
        if not sid: raise ValueError("PRIVACY_SOURCE_ID_MISSING")
        ids.append(sid)
        for p in doc.get("patterns") or []:
            literal=p.get("literal")
            if isinstance(literal,str) and len(literal)>=3: rows.append((sid,str(p.get("class") or "SOURCE"),literal))
    return rows,ids

def evidence_sid_scope(rel:Path)->bool:
    parts={p.casefold() for p in rel.parts}
    if "candidate_repo" in parts and not (parts & EVIDENCE_PARTS): return False
    return bool(parts & EVIDENCE_PARTS) or len(rel.parts)<=2

def scan_tree(root:Path,patterns:list[tuple[str,str,str]],exclude:set[Path])->list[dict]:
    excluded={p.resolve() for p in exclude};hits=[]
    for p in root.rglob("*"):
        if not p.is_file() or p.resolve() in excluded: continue
        data=p.read_bytes();rel=p.relative_to(root)
        for source_id,label,literal in patterns:
            count=0
            for b in encodings(literal):
                if b: count=max(count,data.count(b))
            if count: hits.append({"file":rel.as_posix(),"source_id":source_id,"pattern_class":label,"match_count":count})
        if evidence_sid_scope(rel):
            text="\n".join([
                data.decode("utf-8",errors="ignore"),
                data.decode("utf-16le",errors="ignore"),
                data.decode("utf-16be",errors="ignore"),
            ])
            sids=sorted(set(SID_RE.findall(text)))
            if sids:
                hits.append({"file":rel.as_posix(),"source_id":"BUILTIN","pattern_class":"SID_LIKE","match_count":len(sids)})
    return hits

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("root");ap.add_argument("-o","--output",required=True)
    ap.add_argument("--source-material",action="append",default=[]);ap.add_argument("--require-source-id",action="append",default=[])
    ns=ap.parse_args();patterns=current_host_patterns();imported,ids=load_source_material(ns.source_material);patterns.extend(imported)
    missing=sorted(set(ns.require_source_id)-set(ids));out=Path(ns.output)
    hits=scan_tree(Path(ns.root),patterns,{out,*(Path(x) for x in ns.source_material)})
    status="PRIVACY_SOURCE_COVERAGE_INCOMPLETE" if missing else ("BLOCKED_PRIVACY_MATCH" if hits else "PASS")
    report={"schema_version":"SYNAPSE-DISTRIBUTABLE-PRIVACY-SEAL-3","scan_mode":"RAW_BYTES_UTF8_UTF16LE_UTF16BE+EVIDENCE_SID_REGEX",
      "imported_source_ids":sorted(set(ids)),"required_source_ids":sorted(set(ns.require_source_id)),"missing_required_source_ids":missing,
      "literal_pattern_classes":sorted(set(label for _,label,_ in patterns)),"literal_pattern_count":len(patterns),
      "distributable_literal_commitments_emitted":False,"matches":hits,"status":status,"authority_effect":"NONE"}
    out.write_text(json.dumps(report,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({"status":status,"matches":len(hits),"missing_source_ids":missing},indent=2));return 0 if status=="PASS" else 2
if __name__=="__main__": raise SystemExit(main())
