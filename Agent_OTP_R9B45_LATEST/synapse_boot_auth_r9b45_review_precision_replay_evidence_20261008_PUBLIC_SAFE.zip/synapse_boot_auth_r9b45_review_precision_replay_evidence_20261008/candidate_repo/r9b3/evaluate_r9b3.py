#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json
from datetime import datetime, timezone
from pathlib import Path
from r9b3.common import Denied, load_json_bytes, sha_bytes
from r9b3.evaluator import evaluate

def load(path:Path,label:str):
    data,obj=load_json_bytes(path,label)
    return data,obj,sha_bytes(data)

def file_sha(path:Path)->str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser()
    ap.add_argument("capture"); ap.add_argument("--build-receipt",required=True); ap.add_argument("--registry",required=True)
    ap.add_argument("--run-context",required=True); ap.add_argument("--harness-summary",required=True); ap.add_argument("--server-completion",required=True)
    ap.add_argument("--mediator-exe",required=True); ap.add_argument("--server-script",required=True); ap.add_argument("--capture-source",required=True)
    ap.add_argument("--expected-registry-sha256",required=True); ap.add_argument("--expected-mediator-sha256",required=True)
    ap.add_argument("--expected-server-script-sha256",required=True); ap.add_argument("--expected-capture-source-sha256",required=True)
    ap.add_argument("--offline-artifact-check",action="store_true")
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args(); out=Path(ns.output)
    try:
        if out.exists(): out.unlink()
    except Exception: pass
    try:
        cb,c,csha=load(Path(ns.capture),"CAPTURE")
        bb,b,bsha=load(Path(ns.build_receipt),"BUILD")
        rb,r,rsha=load(Path(ns.registry),"REGISTRY")
        xb,x,xsha=load(Path(ns.run_context),"RUN_CONTEXT")
        hb,h,hsha=load(Path(ns.harness_summary),"HARNESS")
        db,d,dsha=load(Path(ns.server_completion),"COMPLETION")
        hashes={
          "capture_sha256":csha,"build_receipt_sha256":bsha,"registry_sha256":rsha,"run_context_sha256":xsha,
          "harness_sha256":hsha,"completion_sha256":dsha,
          "mediator_binary_sha256":file_sha(Path(ns.mediator_exe)),"server_script_sha256":file_sha(Path(ns.server_script)),
          "capture_source_sha256":file_sha(Path(ns.capture_source)),
          "expected_registry_sha256":ns.expected_registry_sha256,"expected_mediator_sha256":ns.expected_mediator_sha256,
          "expected_server_script_sha256":ns.expected_server_script_sha256,"expected_capture_source_sha256":ns.expected_capture_source_sha256,
        }
        result=evaluate(c,b,r,x,h,d,hashes,datetime.now(timezone.utc),not ns.offline_artifact_check)
        result["evidence_bindings"]={k:v for k,v in hashes.items() if not k.startswith("expected_")}
        result["evaluation_mode"]="OFFLINE_ARTIFACT_CHECK" if ns.offline_artifact_check else "LIVE_FRESHNESS_REQUIRED"
        code=0
    except Denied as e:
        result={"result":"R9B3_DENIED","code":e.code,"authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"};code=2
    except Exception:
        result={"result":"R9B3_DENIED","code":"MALFORMED_OR_UNEXPECTED_INPUT","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"};code=2
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2,ensure_ascii=False));return code
if __name__=="__main__": raise SystemExit(main())
