#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from r9b3.common import Denied, load_json_bytes, require_hex64, require_sid, require_workload, sha_bytes

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--build-receipt",required=True)
    ap.add_argument("--mediator-exe",required=True)
    ap.add_argument("--allowed-user-sid",required=True)
    ap.add_argument("--derived-workload-id",required=True)
    ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args()
    out=Path(ns.output)
    if out.exists():
        print(json.dumps({"status":"DENIED","code":"REGISTRY_OUTPUT_ALREADY_EXISTS"}))
        return 2
    try:
        _,build=load_json_bytes(Path(ns.build_receipt),"BUILD_RECEIPT")
        if build.get("schema_version")!="SYNAPSE-R9B3-BUILD-RECEIPT-1": raise Denied("BUILD_SCHEMA_INVALID")
        if build.get("authentication_result")!="NOT_PERFORMED" or build.get("authorization_status")!="NOT_AUTHORIZED" or build.get("authority_effect")!="NONE":
            raise Denied("BUILD_AUTHORITY_OVERCLAIM")
        mediator_bytes=Path(ns.mediator_exe).read_bytes()
        actual=sha_bytes(mediator_bytes)
        expected=require_hex64(build.get("mediator_binary_sha256"),"BUILD_MEDIATOR_SHA_INVALID")
        if actual!=expected: raise Denied("BUILD_MEDIATOR_SHA_MISMATCH")
        sid=require_sid(ns.allowed_user_sid,"ALLOWED_USER_SID_INVALID")
        workload=require_workload(ns.derived_workload_id,"DERIVED_WORKLOAD_ID_INVALID")
        reg={
          "schema_version":"SYNAPSE-R9B3-PREPROVISIONED-VERIFIER-REGISTRY-1",
          "provisioning_mode":"EXPLICIT_OPERATOR_REHEARSAL",
          "registry_trust":"PREPROVISIONED_REHEARSAL_ONLY",
          "entries":[{"derived_workload_id":workload,"mediator_binary_sha256":actual,"allowed_user_sid":sid}],
          "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"
        }
        encoded=(json.dumps(reg,indent=2,ensure_ascii=False)+"\n").encode("utf-8")
        out.parent.mkdir(parents=True,exist_ok=True)
        with out.open("xb") as f: f.write(encoded)
        print(json.dumps({"status":"R9B3_REGISTRY_PROVISIONED","registry_sha256":sha_bytes(encoded),"mediator_sha256":actual,"authority_effect":"NONE"}))
        return 0
    except Denied as e:
        print(json.dumps({"status":"DENIED","code":e.code,"authority_effect":"NONE"}))
        return 2
    except Exception:
        print(json.dumps({"status":"DENIED","code":"UNEXPECTED_PROVISIONING_ERROR","authority_effect":"NONE"}))
        return 2
if __name__=="__main__": raise SystemExit(main())
