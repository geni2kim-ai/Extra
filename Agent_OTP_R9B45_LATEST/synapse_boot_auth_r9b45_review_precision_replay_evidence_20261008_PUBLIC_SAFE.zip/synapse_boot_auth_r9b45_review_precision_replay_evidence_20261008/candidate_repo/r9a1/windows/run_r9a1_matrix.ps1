param(
    [Parameter(Mandatory=$true)]
    [string]$MediatorExe,

    [Parameter(Mandatory=$true)]
    [string]$OutputDirectory
)

$ErrorActionPreference = "Stop"
$exe = [IO.Path]::GetFullPath($MediatorExe)
$out = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Force -Path $out | Out-Null

function Run-Case([string]$Name, [string]$Mode, [int]$ExpectedExit, [bool]$NeedsReceipt) {
    $stdout = Join-Path $out ($Name + ".stdout.txt")
    $stderr = Join-Path $out ($Name + ".stderr.txt")
    $receipt = Join-Path $out ($Name + ".receipt.json")
    $exitfile = Join-Path $out ($Name + ".exitcode.txt")

    & $exe --output $receipt --mode $Mode --stdout-limit 4096 --stderr-limit 4096 --timeout-ms 2000 `
        1> $stdout 2> $stderr
    $code = $LASTEXITCODE
    Set-Content -LiteralPath $exitfile -Encoding ascii -Value ([string]$code)

    if ($code -ne $ExpectedExit) {
        throw ("R9A1_CASE_EXIT_MISMATCH " + $Name + " actual=" + $code + " expected=" + $ExpectedExit)
    }
    if ($NeedsReceipt -and -not (Test-Path -LiteralPath $receipt -PathType Leaf)) {
        throw ("R9A1_EXPECTED_RECEIPT_MISSING " + $Name)
    }
    if (-not $NeedsReceipt -and (Test-Path -LiteralPath $receipt -PathType Leaf)) {
        throw ("R9A1_UNEXPECTED_RECEIPT_PRESENT " + $Name)
    }
}

Run-Case "normal" "normal" 0 $true
Run-Case "stdout_overflow" "stdout-overflow" 20 $false
Run-Case "stderr_overflow" "stderr-overflow" 21 $false
Run-Case "timeout" "timeout" 22 $false

Write-Host "R9A1_MATRIX_PASS"
