from pathlib import Path

ROOT = Path(__file__).parents[1]
MED = (ROOT/"src"/"DedicatedMediator.cs").read_text(encoding="utf-8")
CHILD = (ROOT/"src"/"SyntheticChild.cs").read_text(encoding="utf-8")
BUILD = (ROOT/"windows"/"build_r9a1.ps1").read_text(encoding="utf-8")
MATRIX = (ROOT/"windows"/"run_r9a1_matrix.ps1").read_text(encoding="utf-8")

def test_no_powershell_encoded_child_launch():
    assert "powershell.exe" not in MED.lower()
    assert "-EncodedCommand" not in MED
    assert 'HelperName = "R9A1_SyntheticChild.exe"' in MED

def test_helper_modes_are_fixed_and_short():
    for mode in ("normal", "stdout-overflow", "stderr-overflow", "timeout"):
        assert mode in CHILD

def test_mediator_uses_bounded_concurrent_io():
    assert "ReadBoundedAsync" in MED
    assert "stdoutTask" in MED and "stderrTask" in MED
    assert '"CONCURRENT_BOUNDED"' in MED

def test_typed_negative_exit_codes_remain():
    assert "ExitStdoutLimit = 20" in MED
    assert "ExitStderrLimit = 21" in MED
    assert "ExitTimeout = 22" in MED

def test_build_receipt_binds_both_binaries_and_sources():
    for token in (
        "mediator_source_sha256", "child_source_sha256",
        "mediator_binary_sha256", "child_binary_sha256", "compiler_sha256"
    ):
        assert token in BUILD

def test_runtime_receipt_does_not_serialize_raw_paths():
    assert '"raw_local_paths_serialized", false' in MED
    assert '"executable_name"' in MED
    assert '"executable_path"' not in MED

def test_matrix_requires_all_four_results():
    assert 'Run-Case "normal" "normal" 0 $true' in MATRIX
    assert 'Run-Case "stdout_overflow" "stdout-overflow" 20 $false' in MATRIX
    assert 'Run-Case "stderr_overflow" "stderr-overflow" 21 $false' in MATRIX
    assert 'Run-Case "timeout" "timeout" 22 $false' in MATRIX
