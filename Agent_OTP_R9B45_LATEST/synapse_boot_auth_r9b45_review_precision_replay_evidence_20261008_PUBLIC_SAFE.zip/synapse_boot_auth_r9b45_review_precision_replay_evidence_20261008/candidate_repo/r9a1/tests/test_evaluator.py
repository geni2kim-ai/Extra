from r9a1.evaluator import evaluate, Denied

def pair():
    medsha = "a" * 64
    childsha = "b" * 64
    receipt = {
        "schema_version": "SYNAPSE-R9A1-DEDICATED-MEDIATOR-CANDIDATE-1",
        "mediator": {
            "session_id": "m", "pid": 100, "executable_name": "R9A1_DedicatedMediator.exe",
            "executable_sha256": medsha, "workload_identity_mode": "DEDICATED_EXECUTABLE_CANDIDATE",
            "authentication_result": "NOT_PERFORMED", "status": "CANDIDATE"
        },
        "child_instance": {
            "pid": 200, "pid_source": "System.Diagnostics.Process.Start", "parent_pid": 100,
            "parent_binding_verified": True, "creation_time_filetime_100ns": 10,
            "creation_time_rechecked_filetime_100ns": 10, "executable_name": "R9A1_SyntheticChild.exe",
            "executable_sha256": childsha, "same_directory_binding_verified": True, "identity": "NOT_PROVED"
        },
        "child_message": {
            "sequence": 0, "generated_by": "DEDICATED_MEDIATOR_CANDIDATE",
            "payload_handling": "OPAQUE_BYTES_NOT_PARSED", "payload_sha256": "c"*64,
            "payload_length": 91, "trust": "UNTRUSTED_CHILD_INPUT", "payload_content_in_receipt": False
        },
        "resource_bounds": {
            "stdout_limit_bytes": 4096, "stderr_limit_bytes": 4096, "timeout_ms": 2000,
            "stdout_bytes": 91, "stderr_bytes": 0, "stdout_limit_exceeded": False,
            "stderr_limit_exceeded": False, "timeout_triggered": False, "drain_mode": "CONCURRENT_BOUNDED"
        },
        "boundary": {
            "child_content_schema": "NOT_INSPECTED", "child_can_choose_principal": False,
            "child_can_receive_runtime_grant": False, "mediator_is_authenticated": False,
            "shared_interpreter_child_removed": True, "raw_local_paths_serialized": False
        },
        "authorization_status": "NOT_AUTHORIZED", "runtime_grant_issued": False,
        "g1_token_issued": False, "f2_unlocked": False, "authority_effect": "NONE"
    }
    build = {
        "schema_version": "SYNAPSE-R9A1-BUILD-RECEIPT-1", "status": "CANDIDATE",
        "mediator_source_sha256": "d"*64, "child_source_sha256": "e"*64,
        "mediator_binary_sha256": medsha, "child_binary_sha256": childsha,
        "compiler_sha256": "f"*64, "compiler_kind": "DOTNET_FRAMEWORK_CSC",
        "mediator_binary_name": "R9A1_DedicatedMediator.exe",
        "child_binary_name": "R9A1_SyntheticChild.exe",
        "workload_identity_mode": "DEDICATED_EXECUTABLE_CANDIDATE",
        "child_identity": "NOT_PROVED", "authentication_result": "NOT_PERFORMED",
        "authorization_status": "NOT_AUTHORIZED", "authority_effect": "NONE"
    }
    return receipt, build

def test_candidate_ready_but_not_authenticated():
    r, b = pair()
    out = evaluate(r, b)
    assert out["result"] == "R9A1_DEDICATED_MEDIATOR_AND_CHILD_CANDIDATE_READY"
    assert out["mediator_authentication"] == "NOT_PERFORMED"
    assert out["child_identity"] == "NOT_PROVED"

def test_mediator_build_sha_mismatch_denied():
    r, b = pair(); b["mediator_binary_sha256"] = "0"*64
    try: evaluate(r, b)
    except Denied as e: assert e.code == "MEDIATOR_BUILD_SHA_MISMATCH"
    else: assert False

def test_child_build_sha_mismatch_denied():
    r, b = pair(); b["child_binary_sha256"] = "0"*64
    try: evaluate(r, b)
    except Denied as e: assert e.code == "CHILD_BUILD_SHA_MISMATCH"
    else: assert False

def test_child_identity_overclaim_denied():
    r, b = pair(); r["child_instance"]["identity"] = "VERIFIED"
    try: evaluate(r, b)
    except Denied as e: assert e.code == "CHILD_IDENTITY_OVERCLAIM"
    else: assert False

def test_shared_interpreter_flag_required():
    r, b = pair(); r["boundary"]["shared_interpreter_child_removed"] = False
    try: evaluate(r, b)
    except Denied as e: assert e.code == "SHARED_INTERPRETER_STILL_PRESENT"
    else: assert False

def test_raw_local_paths_forbidden():
    r, b = pair(); r["boundary"]["raw_local_paths_serialized"] = True
    try: evaluate(r, b)
    except Denied as e: assert e.code == "RAW_LOCAL_PATH_SERIALIZATION_FORBIDDEN"
    else: assert False
