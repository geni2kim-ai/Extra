# R9A.1 — packaged synthetic child helper

R9A.1 is a remediation for the YM environment interaction observed in R9A.

R9A built the dedicated mediator successfully, but the mediator's `powershell.exe -EncodedCommand ...`
synthetic-child launch was blocked at process creation.

R9A.1 does **not** attempt to evade that policy. It removes the shared-interpreter launch primitive and packages a
separate synthetic helper executable:

`R9A1_DedicatedMediator.exe -> R9A1_SyntheticChild.exe <fixed-short-mode>`

Both source files, both binaries and the compiler are bound by SHA-256 in the build receipt.

The mediator:
- derives the helper path from its own directory,
- hashes the exact helper before launch,
- verifies OS-observed parent PID, process path and creation instance,
- hashes the observed helper binary,
- drains stdout/stderr concurrently with explicit caps,
- enforces timeout,
- treats stdout as opaque bytes,
- serializes no raw local paths.

No authentication or authority is added.
