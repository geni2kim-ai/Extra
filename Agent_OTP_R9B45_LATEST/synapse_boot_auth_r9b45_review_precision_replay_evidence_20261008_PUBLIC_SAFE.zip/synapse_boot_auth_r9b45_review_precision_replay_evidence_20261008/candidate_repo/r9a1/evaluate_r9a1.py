#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
from r9a1.evaluator import evaluate, Denied

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("receipt")
    ap.add_argument("--build-receipt", required=True)
    ap.add_argument("-o", "--output", required=True)
    ns = ap.parse_args()
    receipt = json.loads(Path(ns.receipt).read_text(encoding="utf-8-sig"))
    build = json.loads(Path(ns.build_receipt).read_text(encoding="utf-8-sig"))
    try:
        result = evaluate(receipt, build)
        code = 0
    except Denied as e:
        result = {
            "result": "R9A1_DENIED",
            "code": e.code,
            "authorization_status": "NOT_AUTHORIZED",
            "authority_effect": "NONE",
        }
        code = 2
    Path(ns.output).write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return code

if __name__ == "__main__":
    raise SystemExit(main())
