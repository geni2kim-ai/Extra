from __future__ import annotations
from typing import Any
import re

class Denied(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code

HEX64 = re.compile(r"[0-9a-f]{64}")

def _hex(v: object) -> bool:
    return isinstance(v, str) and HEX64.fullmatch(v) is not None

def evaluate(receipt: dict[str, Any], build: dict[str, Any]) -> dict[str, Any]:
    if receipt.get("schema_version") != "SYNAPSE-R9A1-DEDICATED-MEDIATOR-CANDIDATE-1":
        raise Denied("SCHEMA_VERSION_MISMATCH")
    if build.get("schema_version") != "SYNAPSE-R9A1-BUILD-RECEIPT-1":
        raise Denied("BUILD_SCHEMA_VERSION_MISMATCH")

    if receipt.get("authority_effect") != "NONE" or build.get("authority_effect") != "NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if receipt.get("authorization_status") != "NOT_AUTHORIZED" or build.get("authorization_status") != "NOT_AUTHORIZED":
        raise Denied("AUTHORIZATION_PRECLAIMED")
    for k in ("runtime_grant_issued", "g1_token_issued", "f2_unlocked"):
        if receipt.get(k) is not False:
            raise Denied("AUTHORITY_FLAG_TRUE")

    med = receipt.get("mediator") or {}
    if med.get("status") != "CANDIDATE":
        raise Denied("MEDIATOR_STATUS_NOT_CANDIDATE")
    if med.get("authentication_result") != "NOT_PERFORMED" or build.get("authentication_result") != "NOT_PERFORMED":
        raise Denied("AUTHENTICATION_PRECLAIMED")
    if med.get("workload_identity_mode") != "DEDICATED_EXECUTABLE_CANDIDATE":
        raise Denied("MEDIATOR_IDENTITY_MODE_INVALID")

    if med.get("executable_name") != build.get("mediator_binary_name"):
        raise Denied("MEDIATOR_BINARY_NAME_MISMATCH")
    if not _hex(med.get("executable_sha256")) or not _hex(build.get("mediator_binary_sha256")):
        raise Denied("MEDIATOR_SHA_INVALID")
    if med["executable_sha256"] != build["mediator_binary_sha256"]:
        raise Denied("MEDIATOR_BUILD_SHA_MISMATCH")

    child = receipt.get("child_instance") or {}
    if child.get("identity") != "NOT_PROVED" or build.get("child_identity") != "NOT_PROVED":
        raise Denied("CHILD_IDENTITY_OVERCLAIM")
    if child.get("executable_name") != build.get("child_binary_name"):
        raise Denied("CHILD_BINARY_NAME_MISMATCH")
    if not _hex(child.get("executable_sha256")) or not _hex(build.get("child_binary_sha256")):
        raise Denied("CHILD_SHA_INVALID")
    if child["executable_sha256"] != build["child_binary_sha256"]:
        raise Denied("CHILD_BUILD_SHA_MISMATCH")
    if child.get("parent_binding_verified") is not True:
        raise Denied("CHILD_PARENT_BINDING_REQUIRED")
    if child.get("parent_pid") != med.get("pid"):
        raise Denied("CHILD_PARENT_PID_MISMATCH")
    if child.get("creation_time_filetime_100ns") != child.get("creation_time_rechecked_filetime_100ns"):
        raise Denied("CHILD_INSTANCE_RECHECK_FAILED")
    if child.get("same_directory_binding_verified") is not True:
        raise Denied("CHILD_DIRECTORY_BINDING_REQUIRED")

    msg = receipt.get("child_message") or {}
    if msg.get("payload_handling") != "OPAQUE_BYTES_NOT_PARSED":
        raise Denied("PAYLOAD_INTERPRETATION_FORBIDDEN")
    if msg.get("trust") != "UNTRUSTED_CHILD_INPUT":
        raise Denied("CHILD_MESSAGE_TRUST_INVALID")
    if msg.get("payload_content_in_receipt") is not False:
        raise Denied("RAW_PAYLOAD_IN_RECEIPT_FORBIDDEN")
    if not _hex(msg.get("payload_sha256")):
        raise Denied("PAYLOAD_SHA_INVALID")

    rb = receipt.get("resource_bounds") or {}
    if rb.get("drain_mode") != "CONCURRENT_BOUNDED":
        raise Denied("DRAIN_MODE_INVALID")
    if rb.get("stdout_limit_exceeded") is not False:
        raise Denied("STDOUT_LIMIT_EXCEEDED")
    if rb.get("stderr_limit_exceeded") is not False:
        raise Denied("STDERR_LIMIT_EXCEEDED")
    if rb.get("timeout_triggered") is not False:
        raise Denied("CHILD_EXECUTION_TIMEOUT")

    boundary = receipt.get("boundary") or {}
    if boundary.get("mediator_is_authenticated") is not False:
        raise Denied("MEDIATOR_AUTH_OVERCLAIM")
    if boundary.get("child_can_choose_principal") is not False:
        raise Denied("CHILD_PRINCIPAL_CHOICE_FORBIDDEN")
    if boundary.get("child_can_receive_runtime_grant") is not False:
        raise Denied("CHILD_RUNTIME_GRANT_FORBIDDEN")
    if boundary.get("shared_interpreter_child_removed") is not True:
        raise Denied("SHARED_INTERPRETER_STILL_PRESENT")
    if boundary.get("raw_local_paths_serialized") is not False:
        raise Denied("RAW_LOCAL_PATH_SERIALIZATION_FORBIDDEN")

    for key in (
        "mediator_source_sha256",
        "child_source_sha256",
        "mediator_binary_sha256",
        "child_binary_sha256",
        "compiler_sha256",
    ):
        if not _hex(build.get(key)):
            raise Denied("BUILD_LINEAGE_SHA_INVALID")

    return {
        "result": "R9A1_DEDICATED_MEDIATOR_AND_CHILD_CANDIDATE_READY",
        "mediator_binary_sha256": med["executable_sha256"],
        "child_binary_sha256": child["executable_sha256"],
        "build_lineage_bound": True,
        "resource_boundary": "CONCURRENT_BOUNDED",
        "mediator_authentication": "NOT_PERFORMED",
        "child_identity": "NOT_PROVED",
        "next_action": "R9B_OS_WORKLOAD_ATTESTATION_PREP",
        "authorization_status": "NOT_AUTHORIZED",
        "runtime_grant_issued": False,
        "g1_token_issued": False,
        "f2_unlocked": False,
        "authority_effect": "NONE",
    }
