"""R9A.1 packaged synthetic-child helper candidate."""
