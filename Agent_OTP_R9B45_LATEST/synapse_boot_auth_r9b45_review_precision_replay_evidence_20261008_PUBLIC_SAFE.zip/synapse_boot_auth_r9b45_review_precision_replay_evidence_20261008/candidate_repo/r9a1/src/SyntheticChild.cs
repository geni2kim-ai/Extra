using System;
using System.Text;
using System.Threading;

namespace SynapseR9A1
{
    internal static class SyntheticChild
    {
        private static int Main(string[] args)
        {
            if (args.Length != 1) return 2;
            string mode = args[0];

            if (mode == "normal")
            {
                string payload =
                    "{\"meta\":{\"node_id\":\"UNTRUSTED_CHILD_CLAIM\",\"token\":\"UNTRUSTED_CHILD_TOKEN\"},\"data\":\"hello\"}";
                byte[] bytes = Encoding.UTF8.GetBytes(payload);
                var stdout = Console.OpenStandardOutput();
                stdout.Write(bytes, 0, bytes.Length);
                stdout.Flush();
                Thread.Sleep(700);
                return 0;
            }

            if (mode == "stdout-overflow")
            {
                byte[] bytes = new byte[8192];
                var stdout = Console.OpenStandardOutput();
                stdout.Write(bytes, 0, bytes.Length);
                stdout.Flush();
                Thread.Sleep(700);
                return 0;
            }

            if (mode == "stderr-overflow")
            {
                byte[] bytes = new byte[8192];
                var stderr = Console.OpenStandardError();
                stderr.Write(bytes, 0, bytes.Length);
                stderr.Flush();
                Thread.Sleep(700);
                return 0;
            }

            if (mode == "timeout")
            {
                Thread.Sleep(10000);
                return 0;
            }

            return 3;
        }
    }
}
