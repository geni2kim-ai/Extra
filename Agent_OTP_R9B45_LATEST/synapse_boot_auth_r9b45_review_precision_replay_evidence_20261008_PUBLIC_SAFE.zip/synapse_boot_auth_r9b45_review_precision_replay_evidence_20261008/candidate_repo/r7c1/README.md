# R7C.1 — reference-first controlled launcher discovery

R7C.1 fixes a false-negative risk in R7C.

Runtime references are checked against all bounded controlled `.ps1/.py/.cmd/.bat/.exe` files first.
Filename regex matching is secondary only.

Discovery source labels:
- `REFERENCE_BOUND`
- `DIRECT_RUNNING_EXECUTABLE`
- `NAME_HEURISTIC`

No raw service/wrapper reference values are emitted.
No authentication or authority is performed.
