param(
    [Parameter(Mandatory=$true)]
    [string[]]$ControlledRoots,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath,

    [string]$FileNameRegex = "(?i)(synapse|agent|runner|workboard|launcher|daemon|service|watcher)",

    [ValidateRange(100, 20000)]
    [int]$MaxIndexedFiles = 5000
)

$ErrorActionPreference = "Stop"

function Normalize-ExistingRoot([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    try {
        $full=[System.IO.Path]::GetFullPath($Value)
        if (-not (Test-Path -LiteralPath $full -PathType Container)) { return $null }
        return $full.TrimEnd('\','/')
    } catch { return $null }
}

function Relative-ToRoot([string]$Candidate,[string]$Root) {
    $c=[System.IO.Path]::GetFullPath($Candidate)
    $r=[System.IO.Path]::GetFullPath($Root).TrimEnd('\','/')
    $prefix=$r+[System.IO.Path]::DirectorySeparatorChar
    if (-not $c.StartsWith($prefix,[System.StringComparison]::OrdinalIgnoreCase)) { return $null }
    return $c.Substring($prefix.Length)
}

$roots=@()
$idx=0
foreach ($raw in $ControlledRoots) {
    $norm=Normalize-ExistingRoot $raw
    if (-not $norm) { continue }
    $idx++
    $gitHead=$null
    if (Get-Command git.exe -ErrorAction SilentlyContinue) {
        try { $gitHead=(& git.exe -C $norm rev-parse HEAD 2>$null | Select-Object -First 1) } catch {}
    }
    $roots += [ordered]@{
        root_id=("ROOT-{0:D2}" -f $idx)
        root_path=$norm
        git_head=$gitHead
        classification="OPERATOR_SUPPLIED_CONTROLLED_ROOT"
    }
}
if ($roots.Count -eq 0) { throw "NO_VALID_CONTROLLED_ROOT" }

$allowed=@(".ps1",".py",".cmd",".bat",".exe")
$index=@()
foreach ($root in $roots) {
    $files=@(Get-ChildItem -LiteralPath $root.root_path -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $allowed -contains $_.Extension.ToLowerInvariant() })
    if (($index.Count + $files.Count) -gt $MaxIndexedFiles) { throw "CONTROLLED_FILE_INDEX_LIMIT_EXCEEDED" }
    foreach ($file in $files) {
        $index += [ordered]@{
            root_id=$root.root_id
            full_path_local_only=$file.FullName
            relative_path=Relative-ToRoot $file.FullName $root.root_path
            extension=$file.Extension.ToLowerInvariant()
            name=$file.Name
            length=[int64]$file.Length
        }
    }
}

# Local-only runtime reference corpus. Raw values are never serialized.
$referenceRows=@()
$services=@(Get-CimInstance Win32_Service)
foreach ($svc in $services) {
    $values=@()
    if ($svc.PathName) { $values += [string]$svc.PathName }

    $paramKey="HKLM:\SYSTEM\CurrentControlSet\Services\$($svc.Name)\Parameters"
    if (Test-Path -LiteralPath $paramKey) {
        try {
            $props=Get-ItemProperty -LiteralPath $paramKey
            foreach ($propName in @("Application","AppDirectory","AppParameters")) {
                $v=$props.$propName
                if ($v) { $values += [string]$v }
            }
        } catch {}
    }

    $referenceRows += [ordered]@{
        service_name=$svc.Name
        service_state=$svc.State
        process_id=[int]$svc.ProcessId
        values_local_only=$values
    }
}

$candidateMap=@{}
function Add-Candidate([object]$Entry,[string]$Source) {
    $key=([string]$Entry.root_id)+"|"+([string]$Entry.relative_path).ToLowerInvariant()
    if (-not $candidateMap.ContainsKey($key)) {
        $candidateMap[$key]=[ordered]@{
            candidate_id=$null
            root_id=$Entry.root_id
            relative_path=$Entry.relative_path
            extension=$Entry.extension
            sha256=(Get-FileHash -LiteralPath $Entry.full_path_local_only -Algorithm SHA256).Hash.ToLowerInvariant()
            length=$Entry.length
            discovery_sources=@()
            full_path_local_only=$Entry.full_path_local_only
        }
    }
    if ($candidateMap[$key].discovery_sources -notcontains $Source) {
        $candidateMap[$key].discovery_sources += $Source
    }
}

# 1) Reference-bound candidates: filename does not matter.
$serviceLinks=@()
foreach ($ref in $referenceRows) {
    $matchedKeys=@()
    foreach ($entry in $index) {
        foreach ($value in $ref.values_local_only) {
            if ($value.IndexOf([string]$entry.full_path_local_only,[System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                Add-Candidate $entry "REFERENCE_BOUND"
                $key=([string]$entry.root_id)+"|"+([string]$entry.relative_path).ToLowerInvariant()
                $matchedKeys += $key
                break
            }
        }
    }
    if ($matchedKeys.Count -gt 0) {
        $serviceLinks += [ordered]@{
            service_name=$ref.service_name
            service_state=$ref.service_state
            process_id=$ref.process_id
            candidate_keys=@($matchedKeys | Sort-Object -Unique)
            raw_reference_emitted=$false
        }
    }
}

# 2) Name heuristic is secondary only.
foreach ($entry in $index) {
    if ($entry.name -match $FileNameRegex) {
        Add-Candidate $entry "NAME_HEURISTIC"
    }
}

# 3) Direct controlled executables already running.
$procs=@(Get-CimInstance Win32_Process)
$processLinks=@()
foreach ($entry in @($index | Where-Object { $_.extension -eq ".exe" })) {
    foreach ($proc in $procs) {
        $pp=[string]$proc.ExecutablePath
        if ($pp -and $pp.Equals([string]$entry.full_path_local_only,[System.StringComparison]::OrdinalIgnoreCase)) {
            Add-Candidate $entry "DIRECT_RUNNING_EXECUTABLE"
            $key=([string]$entry.root_id)+"|"+([string]$entry.relative_path).ToLowerInvariant()
            $processLinks += [ordered]@{
                candidate_key=$key
                pid=[int]$proc.ProcessId
                process_name=[string]$proc.Name
            }
        }
    }
}

# Stable candidate ids.
$candidates=@()
$n=0
foreach ($key in @($candidateMap.Keys | Sort-Object)) {
    $n++
    $candidateMap[$key].candidate_id=("FILE-{0:D4}" -f $n)
}
$keyToId=@{}
foreach ($key in $candidateMap.Keys) { $keyToId[$key]=$candidateMap[$key].candidate_id }

$serviceLinksOut=@($serviceLinks | ForEach-Object {
    [ordered]@{
        service_name=$_.service_name
        service_state=$_.service_state
        process_id=$_.process_id
        candidate_ids=@($_.candidate_keys | ForEach-Object { $keyToId[$_] } | Sort-Object -Unique)
        raw_reference_emitted=$false
    }
})
$processLinksOut=@($processLinks | ForEach-Object {
    [ordered]@{
        candidate_id=$keyToId[$_.candidate_key]
        pid=$_.pid
        process_name=$_.process_name
        classification="DIRECT_EXECUTABLE_RUNTIME_LINK"
    }
})
$candidatesOut=@($candidateMap.Keys | Sort-Object | ForEach-Object {
    $c=$candidateMap[$_]
    [ordered]@{
        candidate_id=$c.candidate_id
        root_id=$c.root_id
        relative_path=$c.relative_path
        extension=$c.extension
        sha256=$c.sha256
        length=$c.length
        discovery_sources=@($c.discovery_sources | Sort-Object)
    }
})
$rootsOut=@($roots | ForEach-Object {
    [ordered]@{
        root_id=$_.root_id
        root_path=$_.root_path
        git_head=$_.git_head
        classification=$_.classification
    }
})

$report=[ordered]@{
    schema_version="SYNAPSE-R7C1-REFERENCE-FIRST-DISCOVERY-1"
    collected_at_utc=(Get-Date).ToUniversalTime().ToString("o")
    controlled_roots=$rootsOut
    indexed_file_count=$index.Count
    file_candidates=$candidatesOut
    service_links=$serviceLinksOut
    process_links=$processLinksOut
    command_line_captured=$false
    raw_runtime_reference_emitted=$false
    authentication_result="NOT_PERFORMED"
    authorization_status="NOT_AUTHORIZED"
    runtime_grant_issued=$false
    g1_token_issued=$false
    f2_unlocked=$false
    authority_effect="NONE"
}
$report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
$sha=(Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ("WROTE "+$OutputPath)
Write-Host ("SHA256 "+$sha)
Write-Host "AUTHORITY_EFFECT=NONE"
