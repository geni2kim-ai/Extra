"""R7C.1 reference-first controlled launcher discovery."""
