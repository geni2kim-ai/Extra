from __future__ import annotations
import re
from typing import Any

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

def evaluate(doc:dict[str,Any])->dict[str,Any]:
    if doc.get("schema_version")!="SYNAPSE-R7C1-REFERENCE-FIRST-DISCOVERY-1":
        raise Denied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect")!="NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status")!="NOT_AUTHORIZED" or doc.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("AUTH_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if doc.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")
    if doc.get("command_line_captured") is not False: raise Denied("COMMAND_LINE_CAPTURE_FORBIDDEN")
    if doc.get("raw_runtime_reference_emitted") is not False: raise Denied("RAW_REFERENCE_FORBIDDEN")

    roots={r["root_id"] for r in doc.get("controlled_roots") or [] if r.get("root_id")}
    if not roots: raise Denied("ROOTS_MISSING")
    cand={}
    for c in doc.get("file_candidates") or []:
        cid=c.get("candidate_id")
        if not cid or c.get("root_id") not in roots: raise Denied("CANDIDATE_INVALID")
        if not re.fullmatch(r"[0-9a-f]{64}",str(c.get("sha256",""))): raise Denied("CANDIDATE_SHA_INVALID")
        src=set(c.get("discovery_sources") or [])
        if not src or not src <= {"REFERENCE_BOUND","NAME_HEURISTIC","DIRECT_RUNNING_EXECUTABLE"}:
            raise Denied("DISCOVERY_SOURCE_INVALID")
        cand[cid]=c

    runtime=set()
    for s in doc.get("service_links") or []:
        if s.get("raw_reference_emitted") is not False: raise Denied("RAW_REFERENCE_FORBIDDEN")
        for cid in s.get("candidate_ids") or []:
            if cid not in cand: raise Denied("SERVICE_LINK_UNKNOWN_CANDIDATE")
            runtime.add(cid)
    for p in doc.get("process_links") or []:
        cid=p.get("candidate_id")
        if cid not in cand: raise Denied("PROCESS_LINK_UNKNOWN_CANDIDATE")
        runtime.add(cid)

    reference_bound=sorted(cid for cid,c in cand.items() if "REFERENCE_BOUND" in c.get("discovery_sources",[]))
    if runtime:
        result="R7C1_CONTROLLED_RUNTIME_CANDIDATE_FOUND"
        next_action="R7D_SOURCE_ENTRYPOINT_REVIEW"
    elif reference_bound:
        result="R7C1_REFERENCE_BOUND_SOURCE_FOUND_NO_LIVE_RUNTIME"
        next_action="RUNTIME_STATE_OR_SOURCE_REVIEW"
    elif cand:
        result="R7C1_HEURISTIC_SOURCE_ONLY"
        next_action="CONTROLLED_ROOT_SOURCE_REVIEW_OR_BINDING_EVIDENCE"
    else:
        result="R7C1_NO_CANDIDATE_IN_SUPPLIED_ROOTS"
        next_action="R7D_LOCATE_ACTUAL_CONTROLLED_SOURCE_ROOT"

    return {
        "result":result,
        "candidate_count":len(cand),
        "runtime_candidate_count":len(runtime),
        "reference_bound_candidate_ids":reference_bound,
        "next_action":next_action,
        "authentication_result":"NOT_PERFORMED",
        "authorization_status":"NOT_AUTHORIZED",
        "runtime_grant_issued":False,
        "g1_token_issued":False,
        "f2_unlocked":False,
        "authority_effect":"NONE",
    }
