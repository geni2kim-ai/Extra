from __future__ import annotations
from r7c1.evaluator import evaluate,Denied

def base():
    return {
      "schema_version":"SYNAPSE-R7C1-REFERENCE-FIRST-DISCOVERY-1",
      "controlled_roots":[{"root_id":"ROOT-01","root_path":"X"}],
      "indexed_file_count":1,
      "file_candidates":[{
        "candidate_id":"FILE-0001","root_id":"ROOT-01","relative_path":"plain.py",
        "extension":".py","sha256":"a"*64,"length":10,
        "discovery_sources":["REFERENCE_BOUND"]
      }],
      "service_links":[{"service_name":"svc","candidate_ids":["FILE-0001"],"raw_reference_emitted":False}],
      "process_links":[],
      "command_line_captured":False,"raw_runtime_reference_emitted":False,
      "authentication_result":"NOT_PERFORMED","authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,"g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"
    }

def test_reference_bound_neutral_name_is_candidate():
    r=evaluate(base())
    assert r["result"]=="R7C1_CONTROLLED_RUNTIME_CANDIDATE_FOUND"
    assert r["reference_bound_candidate_ids"]==["FILE-0001"]

def test_no_candidates_is_scoped_stop():
    d=base(); d["file_candidates"]=[]; d["service_links"]=[]
    r=evaluate(d)
    assert r["result"]=="R7C1_NO_CANDIDATE_IN_SUPPLIED_ROOTS"

def test_raw_reference_forbidden():
    d=base(); d["raw_runtime_reference_emitted"]=True
    try: evaluate(d)
    except Denied as e: assert e.code=="RAW_REFERENCE_FORBIDDEN"
    else: assert False

def test_unknown_service_candidate_denied():
    d=base(); d["service_links"][0]["candidate_ids"]=["FILE-9999"]
    try: evaluate(d)
    except Denied as e: assert e.code=="SERVICE_LINK_UNKNOWN_CANDIDATE"
    else: assert False
