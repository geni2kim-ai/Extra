param(
    [Parameter(Mandatory=$true)]
    [string]$SourcePath,

    [Parameter(Mandatory=$true)]
    [string]$OutputExe,

    [Parameter(Mandatory=$true)]
    [string]$BuildReceipt
)

$ErrorActionPreference = "Stop"

$candidates = @(
    (Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"),
    (Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe")
)
$csc = $candidates | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
if (-not $csc) { throw "R9A_CSC_NOT_FOUND" }

$source = [System.IO.Path]::GetFullPath($SourcePath)
$out = [System.IO.Path]::GetFullPath($OutputExe)
$receipt = [System.IO.Path]::GetFullPath($BuildReceipt)

$compilerArgs = @(
    "/nologo",
    "/target:exe",
    "/optimize+",
    "/platform:anycpu",
    ("/out:" + $out),
    "/reference:System.Management.dll",
    "/reference:System.Web.Extensions.dll",
    $source
)
& $csc @compilerArgs
if ($LASTEXITCODE -ne 0) { throw "R9A_CSC_BUILD_FAILED" }
if (-not (Test-Path -LiteralPath $out -PathType Leaf)) { throw "R9A_OUTPUT_EXE_MISSING" }

$build = [ordered]@{
    schema_version = "SYNAPSE-R9A-BUILD-RECEIPT-1"
    status = "CANDIDATE"
    source_sha256 = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    binary_sha256 = (Get-FileHash -LiteralPath $out -Algorithm SHA256).Hash.ToLowerInvariant()
    compiler_sha256 = (Get-FileHash -LiteralPath $csc -Algorithm SHA256).Hash.ToLowerInvariant()
    compiler_kind = "DOTNET_FRAMEWORK_CSC"
    workload_identity_mode = "DEDICATED_EXECUTABLE_CANDIDATE"
    authentication_result = "NOT_PERFORMED"
    authorization_status = "NOT_AUTHORIZED"
    authority_effect = "NONE"
}
$build | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $receipt -Encoding UTF8
Write-Host "R9A_BUILD_CANDIDATE_READY"
Write-Host ("BINARY_SHA256 " + $build.binary_sha256)
Write-Host "AUTHORITY_EFFECT=NONE"
