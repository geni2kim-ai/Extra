using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace SynapseR9A
{
    internal sealed class LimitExceededException : Exception
    {
        internal readonly string Code;
        internal LimitExceededException(string code) : base(code) { Code = code; }
    }

    internal static class Program
    {
        private const int ExitStdoutLimit = 20;
        private const int ExitStderrLimit = 21;
        private const int ExitTimeout = 22;
        private const int ExitGeneric = 23;

        private static string Sha256File(string path)
        {
            using (var sha = SHA256.Create())
            using (var s = File.OpenRead(path))
                return Hex(sha.ComputeHash(s));
        }

        private static string Sha256Bytes(byte[] data)
        {
            using (var sha = SHA256.Create())
                return Hex(sha.ComputeHash(data));
        }

        private static string Hex(byte[] data)
        {
            var sb = new StringBuilder(data.Length * 2);
            foreach (byte b in data) sb.Append(b.ToString("x2"));
            return sb.ToString();
        }

        private static async Task<byte[]> ReadBoundedAsync(Stream stream, int maxBytes, string code)
        {
            var buffer = new byte[1024];
            using (var ms = new MemoryStream())
            {
                while (true)
                {
                    int n = await stream.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
                    if (n == 0) break;
                    if (ms.Length + n > maxBytes) throw new LimitExceededException(code);
                    ms.Write(buffer, 0, n);
                }
                return ms.ToArray();
            }
        }

        private static int ParentPid(int pid)
        {
            using (var searcher = new ManagementObjectSearcher(
                "SELECT ParentProcessId FROM Win32_Process WHERE ProcessId=" + pid))
            {
                foreach (ManagementObject mo in searcher.Get())
                    return Convert.ToInt32((UInt32)mo["ParentProcessId"]);
            }
            throw new InvalidOperationException("R9A_PARENT_PID_NOT_FOUND");
        }

        private static string ProcessPath(int pid)
        {
            using (var searcher = new ManagementObjectSearcher(
                "SELECT ExecutablePath FROM Win32_Process WHERE ProcessId=" + pid))
            {
                foreach (ManagementObject mo in searcher.Get())
                    return Convert.ToString(mo["ExecutablePath"]);
            }
            throw new InvalidOperationException("R9A_PROCESS_PATH_NOT_FOUND");
        }

        private static void KillQuiet(Process p)
        {
            try { if (!p.HasExited) p.Kill(); } catch { }
            try { p.WaitForExit(2000); } catch { }
        }

        private static int Main(string[] args)
        {
            try { return MainCore(args); }
            catch (Exception ex)
            {
                Console.Error.WriteLine("R9A_GENERIC_FAILURE " + ex.GetType().Name);
                return ExitGeneric;
            }
        }

        private static int MainCore(string[] args)
        {
            string output = null;
            string mode = "normal";
            int stdoutLimit = 4096;
            int stderrLimit = 4096;
            int timeoutMs = 5000;

            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "--output" && i + 1 < args.Length) output = args[++i];
                else if (args[i] == "--mode" && i + 1 < args.Length) mode = args[++i];
                else if (args[i] == "--stdout-limit" && i + 1 < args.Length) stdoutLimit = Int32.Parse(args[++i]);
                else if (args[i] == "--stderr-limit" && i + 1 < args.Length) stderrLimit = Int32.Parse(args[++i]);
                else if (args[i] == "--timeout-ms" && i + 1 < args.Length) timeoutMs = Int32.Parse(args[++i]);
                else throw new ArgumentException("R9A_ARGUMENT_INVALID");
            }
            if (String.IsNullOrWhiteSpace(output)) throw new ArgumentException("R9A_OUTPUT_REQUIRED");
            if (stdoutLimit < 1 || stdoutLimit > 65536) throw new ArgumentException("R9A_STDOUT_LIMIT_INVALID");
            if (stderrLimit < 1 || stderrLimit > 16384) throw new ArgumentException("R9A_STDERR_LIMIT_INVALID");
            if (timeoutMs < 1 || timeoutMs > 30000) throw new ArgumentException("R9A_TIMEOUT_INVALID");
            if (mode!="normal" && mode!="stdout-overflow" && mode!="stderr-overflow" && mode!="timeout")
                throw new ArgumentException("R9A_MODE_INVALID");

            var self = Process.GetCurrentProcess();
            int mediatorPid = self.Id;
            string mediatorExe = self.MainModule.FileName;
            string mediatorSha = Sha256File(mediatorExe);
            string mediatorSession = "r9a-mediator-" + Guid.NewGuid().ToString("N");

            string childExe = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
            if (!File.Exists(childExe)) throw new FileNotFoundException("R9A_CHILD_EXE_NOT_FOUND");
            string childExpectedSha = Sha256File(childExe);

            string payload = "{\"meta\":{\"node_id\":\"UNTRUSTED_CHILD_CLAIM\",\"token\":\"UNTRUSTED_CHILD_TOKEN\"},\"data\":\"hello\"}";
            string childCommand;
            if (mode == "normal")
            {
                string b64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(payload));
                childCommand =
                    "$b=[Convert]::FromBase64String('" + b64 + "');" +
                    "$s=[Console]::OpenStandardOutput();$s.Write($b,0,$b.Length);$s.Flush();" +
                    "Start-Sleep -Milliseconds 700";
            }
            else if (mode == "stdout-overflow")
            {
                childCommand =
                    "$b=New-Object byte[] 8192;" +
                    "$s=[Console]::OpenStandardOutput();$s.Write($b,0,$b.Length);$s.Flush();Start-Sleep -Milliseconds 700";
            }
            else if (mode == "stderr-overflow")
            {
                childCommand =
                    "$b=New-Object byte[] 8192;" +
                    "$s=[Console]::OpenStandardError();$s.Write($b,0,$b.Length);$s.Flush();Start-Sleep -Milliseconds 700";
            }
            else
            {
                childCommand = "Start-Sleep -Seconds 10";
            }

            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(childCommand));
            var psi = new ProcessStartInfo();
            psi.FileName = childExe;
            psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -EncodedCommand " + encoded;
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            psi.RedirectStandardOutput = true;
            psi.RedirectStandardError = true;

            using (var child = new Process())
            {
                child.StartInfo = psi;
                if (!child.Start()) throw new InvalidOperationException("R9A_CHILD_START_FAILED");
                int childPid = child.Id;

                int parentPid = ParentPid(childPid);
                if (parentPid != mediatorPid)
                {
                    KillQuiet(child);
                    throw new InvalidOperationException("R9A_CHILD_PARENT_PID_MISMATCH");
                }

                string observedPath = ProcessPath(childPid);
                if (!String.Equals(observedPath, childExe, StringComparison.OrdinalIgnoreCase))
                {
                    KillQuiet(child);
                    throw new InvalidOperationException("R9A_CHILD_PATH_MISMATCH");
                }
                string observedSha = Sha256File(observedPath);
                if (observedSha != childExpectedSha)
                {
                    KillQuiet(child);
                    throw new InvalidOperationException("R9A_CHILD_SHA_MISMATCH");
                }

                long creation1 = Process.GetProcessById(childPid).StartTime.ToUniversalTime().ToFileTimeUtc();
                Thread.Sleep(50);
                long creation2 = Process.GetProcessById(childPid).StartTime.ToUniversalTime().ToFileTimeUtc();
                if (creation1 != creation2)
                {
                    KillQuiet(child);
                    throw new InvalidOperationException("R9A_CHILD_INSTANCE_RECHECK_FAILED");
                }

                Task<byte[]> stdoutTask = ReadBoundedAsync(
                    child.StandardOutput.BaseStream, stdoutLimit, "R9A_CHILD_STDOUT_LIMIT_EXCEEDED");
                Task<byte[]> stderrTask = ReadBoundedAsync(
                    child.StandardError.BaseStream, stderrLimit, "R9A_CHILD_STDERR_LIMIT_EXCEEDED");

                var sw = Stopwatch.StartNew();
                while (!child.HasExited && !stdoutTask.IsFaulted && !stderrTask.IsFaulted && sw.ElapsedMilliseconds < timeoutMs)
                    Thread.Sleep(10);

                bool timedOut = !child.HasExited && sw.ElapsedMilliseconds >= timeoutMs;
                if (timedOut) KillQuiet(child);
                if (stdoutTask.IsFaulted || stderrTask.IsFaulted) KillQuiet(child);
                if (!child.HasExited) child.WaitForExit();

                try { Task.WaitAll(new Task[] { stdoutTask, stderrTask }, 2000); }
                catch (AggregateException) { }

                if (stdoutTask.IsFaulted)
                {
                    var ex = stdoutTask.Exception.Flatten().InnerException as LimitExceededException;
                    if (ex != null && ex.Code == "R9A_CHILD_STDOUT_LIMIT_EXCEEDED")
                    {
                        Console.Error.WriteLine(ex.Code);
                        return ExitStdoutLimit;
                    }
                    throw stdoutTask.Exception.Flatten().InnerException;
                }
                if (stderrTask.IsFaulted)
                {
                    var ex = stderrTask.Exception.Flatten().InnerException as LimitExceededException;
                    if (ex != null && ex.Code == "R9A_CHILD_STDERR_LIMIT_EXCEEDED")
                    {
                        Console.Error.WriteLine(ex.Code);
                        return ExitStderrLimit;
                    }
                    throw stderrTask.Exception.Flatten().InnerException;
                }
                if (timedOut)
                {
                    Console.Error.WriteLine("R9A_CHILD_EXECUTION_TIMEOUT");
                    return ExitTimeout;
                }

                byte[] stdoutBytes = stdoutTask.Result;
                byte[] stderrBytes = stderrTask.Result;

                if (mode != "normal")
                    throw new InvalidOperationException("R9A_NEGATIVE_MODE_DID_NOT_TRIGGER");

                string expectedPayloadSha = Sha256Bytes(Encoding.UTF8.GetBytes(payload));
                string observedPayloadSha = Sha256Bytes(stdoutBytes);
                if (observedPayloadSha != expectedPayloadSha)
                    throw new InvalidOperationException("R9A_PAYLOAD_HASH_MISMATCH");
                if (stderrBytes.Length != 0)
                    throw new InvalidOperationException("R9A_CHILD_STDERR_NONEMPTY");
                if (child.ExitCode != 0)
                    throw new InvalidOperationException("R9A_CHILD_EXIT_NONZERO");

                var receipt = new Dictionary<string, object>();
                receipt["schema_version"] = "SYNAPSE-R9A-DEDICATED-MEDIATOR-CANDIDATE-1";
                receipt["collected_at_utc"] = DateTime.UtcNow.ToString("o");

                receipt["mediator"] = new Dictionary<string, object> {
                    {"session_id", mediatorSession},
                    {"pid", mediatorPid},
                    {"executable_path", mediatorExe},
                    {"executable_sha256", mediatorSha},
                    {"workload_identity_mode", "DEDICATED_EXECUTABLE_CANDIDATE"},
                    {"authentication_result", "NOT_PERFORMED"},
                    {"status", "CANDIDATE"}
                };
                receipt["child_instance"] = new Dictionary<string, object> {
                    {"pid", childPid},
                    {"pid_source", "System.Diagnostics.Process.Start"},
                    {"parent_pid", parentPid},
                    {"parent_binding_verified", true},
                    {"creation_time_filetime_100ns", creation1},
                    {"creation_time_rechecked_filetime_100ns", creation2},
                    {"executable_path", observedPath},
                    {"executable_sha256", observedSha},
                    {"identity", "NOT_PROVED"}
                };
                receipt["child_message"] = new Dictionary<string, object> {
                    {"sequence", 0},
                    {"generated_by", "DEDICATED_MEDIATOR_CANDIDATE"},
                    {"payload_handling", "OPAQUE_BYTES_NOT_PARSED"},
                    {"payload_sha256", observedPayloadSha},
                    {"payload_length", stdoutBytes.Length},
                    {"trust", "UNTRUSTED_CHILD_INPUT"},
                    {"payload_content_in_receipt", false}
                };
                receipt["resource_bounds"] = new Dictionary<string, object> {
                    {"stdout_limit_bytes", stdoutLimit},
                    {"stderr_limit_bytes", stderrLimit},
                    {"timeout_ms", timeoutMs},
                    {"stdout_bytes", stdoutBytes.Length},
                    {"stderr_bytes", stderrBytes.Length},
                    {"stdout_limit_exceeded", false},
                    {"stderr_limit_exceeded", false},
                    {"timeout_triggered", false},
                    {"drain_mode", "CONCURRENT_BOUNDED"}
                };
                receipt["boundary"] = new Dictionary<string, object> {
                    {"child_content_schema", "NOT_INSPECTED"},
                    {"child_can_choose_principal", false},
                    {"child_can_receive_runtime_grant", false},
                    {"mediator_is_authenticated", false}
                };
                receipt["authorization_status"] = "NOT_AUTHORIZED";
                receipt["runtime_grant_issued"] = false;
                receipt["g1_token_issued"] = false;
                receipt["f2_unlocked"] = false;
                receipt["authority_effect"] = "NONE";

                var serializer = new JavaScriptSerializer();
                File.WriteAllText(output, serializer.Serialize(receipt), new UTF8Encoding(false));
                Console.WriteLine("R9A_DEDICATED_MEDIATOR_CANDIDATE_RECEIPT_READY");
                Console.WriteLine("AUTHORITY_EFFECT=NONE");
                return 0;
            }
        }
    }
}
