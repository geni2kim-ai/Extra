"""R9A dedicated mediator binary candidate policy."""
