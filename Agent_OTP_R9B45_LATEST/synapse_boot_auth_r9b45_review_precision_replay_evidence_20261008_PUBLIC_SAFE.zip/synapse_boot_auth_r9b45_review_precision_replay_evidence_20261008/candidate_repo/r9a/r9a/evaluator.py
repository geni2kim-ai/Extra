from __future__ import annotations
from typing import Any
import re

class Denied(RuntimeError):
    def __init__(self,code:str):
        super().__init__(code); self.code=code

HEX64=re.compile(r"[0-9a-f]{64}")

def _hex(v:object)->bool:
    return isinstance(v,str) and HEX64.fullmatch(v) is not None

def evaluate(receipt:dict[str,Any], build:dict[str,Any])->dict[str,Any]:
    if receipt.get("schema_version")!="SYNAPSE-R9A-DEDICATED-MEDIATOR-CANDIDATE-1":
        raise Denied("SCHEMA_VERSION_MISMATCH")
    if build.get("schema_version")!="SYNAPSE-R9A-BUILD-RECEIPT-1":
        raise Denied("BUILD_SCHEMA_VERSION_MISMATCH")
    if receipt.get("authority_effect")!="NONE" or build.get("authority_effect")!="NONE":
        raise Denied("AUTHORITY_EFFECT_NOT_NONE")
    if receipt.get("authorization_status")!="NOT_AUTHORIZED" or build.get("authorization_status")!="NOT_AUTHORIZED":
        raise Denied("AUTHORIZATION_PRECLAIMED")
    for k in ("runtime_grant_issued","g1_token_issued","f2_unlocked"):
        if receipt.get(k) is not False: raise Denied("AUTHORITY_FLAG_TRUE")

    med=receipt.get("mediator") or {}
    if med.get("status")!="CANDIDATE":
        raise Denied("MEDIATOR_STATUS_NOT_CANDIDATE")
    if med.get("workload_identity_mode")!="DEDICATED_EXECUTABLE_CANDIDATE":
        raise Denied("MEDIATOR_IDENTITY_MODE_INVALID")
    if med.get("authentication_result")!="NOT_PERFORMED" or build.get("authentication_result")!="NOT_PERFORMED":
        raise Denied("AUTHENTICATION_PRECLAIMED")
    if not _hex(med.get("executable_sha256")) or not _hex(build.get("binary_sha256")):
        raise Denied("MEDIATOR_SHA_INVALID")
    if med["executable_sha256"]!=build["binary_sha256"]:
        raise Denied("MEDIATOR_BUILD_SHA_MISMATCH")
    if not _hex(build.get("source_sha256")) or not _hex(build.get("compiler_sha256")):
        raise Denied("BUILD_LINEAGE_SHA_INVALID")

    child=receipt.get("child_instance") or {}
    if child.get("identity")!="NOT_PROVED":
        raise Denied("CHILD_IDENTITY_OVERCLAIM")
    if child.get("parent_binding_verified") is not True:
        raise Denied("CHILD_PARENT_BINDING_REQUIRED")
    if child.get("parent_pid")!=med.get("pid"):
        raise Denied("CHILD_PARENT_PID_MISMATCH")
    if child.get("creation_time_filetime_100ns")!=child.get("creation_time_rechecked_filetime_100ns"):
        raise Denied("CHILD_INSTANCE_RECHECK_FAILED")
    if not _hex(child.get("executable_sha256")):
        raise Denied("CHILD_SHA_INVALID")

    msg=receipt.get("child_message") or {}
    if msg.get("generated_by")!="DEDICATED_MEDIATOR_CANDIDATE":
        raise Denied("MESSAGE_PROVENANCE_INVALID")
    if msg.get("payload_handling")!="OPAQUE_BYTES_NOT_PARSED":
        raise Denied("PAYLOAD_INTERPRETATION_FORBIDDEN")
    if msg.get("trust")!="UNTRUSTED_CHILD_INPUT":
        raise Denied("CHILD_MESSAGE_TRUST_INVALID")
    if msg.get("payload_content_in_receipt") is not False:
        raise Denied("RAW_PAYLOAD_IN_RECEIPT_FORBIDDEN")
    if not _hex(msg.get("payload_sha256")):
        raise Denied("PAYLOAD_SHA_INVALID")

    rb=receipt.get("resource_bounds") or {}
    out_lim=rb.get("stdout_limit_bytes"); err_lim=rb.get("stderr_limit_bytes"); timeout=rb.get("timeout_ms")
    if not isinstance(out_lim,int) or not 1<=out_lim<=65536: raise Denied("STDOUT_LIMIT_INVALID")
    if not isinstance(err_lim,int) or not 1<=err_lim<=16384: raise Denied("STDERR_LIMIT_INVALID")
    if not isinstance(timeout,int) or not 1<=timeout<=30000: raise Denied("TIMEOUT_INVALID")
    if not isinstance(rb.get("stdout_bytes"),int) or not 0<=rb["stdout_bytes"]<=out_lim:
        raise Denied("STDOUT_OBSERVED_OUT_OF_BOUNDS")
    if not isinstance(rb.get("stderr_bytes"),int) or not 0<=rb["stderr_bytes"]<=err_lim:
        raise Denied("STDERR_OBSERVED_OUT_OF_BOUNDS")
    if rb.get("stdout_limit_exceeded") is not False: raise Denied("STDOUT_LIMIT_EXCEEDED")
    if rb.get("stderr_limit_exceeded") is not False: raise Denied("STDERR_LIMIT_EXCEEDED")
    if rb.get("timeout_triggered") is not False: raise Denied("CHILD_EXECUTION_TIMEOUT")
    if rb.get("drain_mode")!="CONCURRENT_BOUNDED": raise Denied("DRAIN_MODE_INVALID")

    boundary=receipt.get("boundary") or {}
    if boundary.get("mediator_is_authenticated") is not False:
        raise Denied("MEDIATOR_AUTH_OVERCLAIM")
    if boundary.get("child_can_choose_principal") is not False:
        raise Denied("CHILD_PRINCIPAL_CHOICE_FORBIDDEN")
    if boundary.get("child_can_receive_runtime_grant") is not False:
        raise Denied("CHILD_RUNTIME_GRANT_FORBIDDEN")

    return {
      "result":"R9A_DEDICATED_MEDIATOR_CANDIDATE_READY",
      "binary_sha256":med["executable_sha256"],
      "build_lineage_bound":True,
      "resource_boundary":"CONCURRENT_BOUNDED",
      "mediator_authentication":"NOT_PERFORMED",
      "child_identity":"NOT_PROVED",
      "next_action":"R9B_OS_WORKLOAD_ATTESTATION_FOR_DEDICATED_MEDIATOR",
      "authorization_status":"NOT_AUTHORIZED",
      "runtime_grant_issued":False,
      "g1_token_issued":False,
      "f2_unlocked":False,
      "authority_effect":"NONE",
    }
