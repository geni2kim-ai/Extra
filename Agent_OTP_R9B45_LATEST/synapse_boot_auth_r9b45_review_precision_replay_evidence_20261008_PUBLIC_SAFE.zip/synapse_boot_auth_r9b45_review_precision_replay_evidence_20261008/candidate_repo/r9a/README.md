# R9A — dedicated mediator executable candidate

R9A prepares a uniquely OS-observable mediator **candidate executable**.

It is not authenticated and receives no authority.

The candidate:
- hashes its own executable,
- binds that SHA to a separate build receipt,
- launches only a synthetic child,
- verifies parent PID + child process instance + child executable SHA,
- drains stdout/stderr concurrently with byte limits,
- enforces child execution timeout,
- treats stdout as opaque bytes,
- records only payload hash/length,
- keeps the child `NOT_PROVED`.

Negative modes exist only for sandbox proof of fail-closed resource limits:
- `stdout-overflow` -> exit 20
- `stderr-overflow` -> exit 21
- `timeout` -> exit 22

A normal R9A PASS means only `DEDICATED_EXECUTABLE_CANDIDATE`, not live authentication.
