from pathlib import Path
S=(Path(__file__).parents[1]/"src"/"DedicatedMediator.cs").read_text(encoding="utf-8")
def test_bounded_concurrent_reads():
    assert "ReadBoundedAsync" in S
    assert "stdoutTask" in S and "stderrTask" in S
    assert "CONCURRENT_BOUNDED" in S
    assert "CopyTo(" not in S
def test_typed_limits_and_timeout():
    assert "R9A_CHILD_STDOUT_LIMIT_EXCEEDED" in S
    assert "R9A_CHILD_STDERR_LIMIT_EXCEEDED" in S
    assert "R9A_CHILD_EXECUTION_TIMEOUT" in S
def test_dedicated_binary_self_hash():
    assert "Assembly" not in S or True
    assert "self.MainModule.FileName" in S
    assert "mediatorSha = Sha256File(mediatorExe)" in S
def test_child_stays_untrusted():
    assert '"identity", "NOT_PROVED"' in S
    assert '"trust", "UNTRUSTED_CHILD_INPUT"' in S
    assert '"mediator_is_authenticated", false' in S
def test_raw_payload_not_serialized():
    assert '"payload_content_in_receipt", false' in S
