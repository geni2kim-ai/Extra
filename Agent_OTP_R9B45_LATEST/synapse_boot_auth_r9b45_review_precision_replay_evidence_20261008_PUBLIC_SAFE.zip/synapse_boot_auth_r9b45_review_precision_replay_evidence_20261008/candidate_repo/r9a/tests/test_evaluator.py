from r9a.evaluator import evaluate,Denied
def pair():
    sha="a"*64
    r={
      "schema_version":"SYNAPSE-R9A-DEDICATED-MEDIATOR-CANDIDATE-1",
      "mediator":{"session_id":"m","pid":100,"executable_path":"x","executable_sha256":sha,
        "workload_identity_mode":"DEDICATED_EXECUTABLE_CANDIDATE","authentication_result":"NOT_PERFORMED","status":"CANDIDATE"},
      "child_instance":{"pid":200,"pid_source":"System.Diagnostics.Process.Start","parent_pid":100,
        "parent_binding_verified":True,"creation_time_filetime_100ns":10,"creation_time_rechecked_filetime_100ns":10,
        "executable_path":"c","executable_sha256":"b"*64,"identity":"NOT_PROVED"},
      "child_message":{"sequence":0,"generated_by":"DEDICATED_MEDIATOR_CANDIDATE","payload_handling":"OPAQUE_BYTES_NOT_PARSED",
        "payload_sha256":"c"*64,"payload_length":91,"trust":"UNTRUSTED_CHILD_INPUT","payload_content_in_receipt":False},
      "resource_bounds":{"stdout_limit_bytes":4096,"stderr_limit_bytes":4096,"timeout_ms":5000,"stdout_bytes":91,
        "stderr_bytes":0,"stdout_limit_exceeded":False,"stderr_limit_exceeded":False,"timeout_triggered":False,
        "drain_mode":"CONCURRENT_BOUNDED"},
      "boundary":{"child_content_schema":"NOT_INSPECTED","child_can_choose_principal":False,
        "child_can_receive_runtime_grant":False,"mediator_is_authenticated":False},
      "authorization_status":"NOT_AUTHORIZED","runtime_grant_issued":False,
      "g1_token_issued":False,"f2_unlocked":False,"authority_effect":"NONE"}
    b={"schema_version":"SYNAPSE-R9A-BUILD-RECEIPT-1","status":"CANDIDATE","source_sha256":"d"*64,
       "binary_sha256":sha,"compiler_sha256":"e"*64,"compiler_kind":"DOTNET_FRAMEWORK_CSC",
       "workload_identity_mode":"DEDICATED_EXECUTABLE_CANDIDATE","authentication_result":"NOT_PERFORMED",
       "authorization_status":"NOT_AUTHORIZED","authority_effect":"NONE"}
    return r,b

def test_candidate_ready_not_authenticated():
    r,b=pair(); out=evaluate(r,b)
    assert out["result"]=="R9A_DEDICATED_MEDIATOR_CANDIDATE_READY"
    assert out["mediator_authentication"]=="NOT_PERFORMED"
    assert out["child_identity"]=="NOT_PROVED"

def test_build_binary_sha_mismatch_denied():
    r,b=pair(); b["binary_sha256"]="f"*64
    try:evaluate(r,b)
    except Denied as e: assert e.code=="MEDIATOR_BUILD_SHA_MISMATCH"
    else:assert False

def test_unbounded_stdout_denied():
    r,b=pair(); r["resource_bounds"]["stdout_bytes"]=5000
    try:evaluate(r,b)
    except Denied as e: assert e.code=="STDOUT_OBSERVED_OUT_OF_BOUNDS"
    else:assert False

def test_timeout_denied():
    r,b=pair(); r["resource_bounds"]["timeout_triggered"]=True
    try:evaluate(r,b)
    except Denied as e: assert e.code=="CHILD_EXECUTION_TIMEOUT"
    else:assert False

def test_mediator_auth_overclaim_denied():
    r,b=pair(); r["boundary"]["mediator_is_authenticated"]=True
    try:evaluate(r,b)
    except Denied as e: assert e.code=="MEDIATOR_AUTH_OVERCLAIM"
    else:assert False

def test_child_identity_overclaim_denied():
    r,b=pair(); r["child_instance"]["identity"]="VERIFIED"
    try:evaluate(r,b)
    except Denied as e: assert e.code=="CHILD_IDENTITY_OVERCLAIM"
    else:assert False
