from __future__ import annotations
import re
from typing import Any

class DiscoveryDenied(RuntimeError):
    def __init__(self, code: str):
        super().__init__(code)
        self.code = code

def evaluate(doc: dict[str, Any]) -> dict[str, Any]:
    if doc.get("schema_version") != "SYNAPSE-R7C-CONTROLLED-LAUNCHER-DISCOVERY-1":
        raise DiscoveryDenied("SCHEMA_VERSION_MISMATCH")
    if doc.get("authority_effect") != "NONE":
        raise DiscoveryDenied("AUTHORITY_EFFECT_NOT_NONE")
    if doc.get("authorization_status") != "NOT_AUTHORIZED":
        raise DiscoveryDenied("AUTHORIZATION_PRECLAIMED")
    if doc.get("authentication_result") != "NOT_PERFORMED":
        raise DiscoveryDenied("AUTHENTICATION_PRECLAIMED")
    for k in ("runtime_grant_issued", "g1_token_issued", "f2_unlocked"):
        if doc.get(k) is not False:
            raise DiscoveryDenied("AUTHORITY_FLAG_TRUE")

    if doc.get("command_line_captured") is not False:
        raise DiscoveryDenied("COMMAND_LINE_CAPTURE_FORBIDDEN")
    if doc.get("raw_service_path_emitted") is not False:
        raise DiscoveryDenied("RAW_SERVICE_PATH_FORBIDDEN")
    if doc.get("raw_wrapper_parameters_emitted") is not False:
        raise DiscoveryDenied("RAW_WRAPPER_PARAMETERS_FORBIDDEN")

    roots = doc.get("controlled_roots") or []
    if not roots:
        raise DiscoveryDenied("CONTROLLED_ROOTS_MISSING")
    root_ids = set()
    for r in roots:
        rid = r.get("root_id")
        if not isinstance(rid, str) or not rid:
            raise DiscoveryDenied("ROOT_ID_INVALID")
        root_ids.add(rid)

    candidates = doc.get("file_candidates") or []
    candidate_map: dict[str, dict[str, Any]] = {}
    for c in candidates:
        cid = c.get("candidate_id")
        if not isinstance(cid, str) or not cid:
            raise DiscoveryDenied("CANDIDATE_ID_INVALID")
        if c.get("root_id") not in root_ids:
            raise DiscoveryDenied("CANDIDATE_ROOT_UNKNOWN")
        h = c.get("sha256")
        if not isinstance(h, str) or not re.fullmatch(r"[0-9a-f]{64}", h):
            raise DiscoveryDenied("CANDIDATE_SHA256_INVALID")
        rel = c.get("relative_path")
        if not isinstance(rel, str) or not rel or rel.startswith(("\\", "/")) or ".." in rel.replace("\\", "/").split("/"):
            raise DiscoveryDenied("CANDIDATE_RELATIVE_PATH_INVALID")
        candidate_map[cid] = c

    runtime_links: list[dict[str, Any]] = []
    for link in doc.get("service_links") or []:
        linked = sorted(
            set((link.get("direct_candidate_ids") or []) + (link.get("wrapper_parameter_candidate_ids") or []))
        )
        for cid in linked:
            if cid not in candidate_map:
                raise DiscoveryDenied("SERVICE_LINK_UNKNOWN_CANDIDATE")
        if linked:
            runtime_links.append({
                "kind": "WINDOWS_SERVICE",
                "service_name": link.get("service_name"),
                "service_state": link.get("service_state"),
                "process_id": link.get("process_id"),
                "service_sid_present": bool(link.get("service_sid")),
                "candidate_ids": linked,
            })

    for link in doc.get("process_links") or []:
        cid = link.get("candidate_id")
        if cid not in candidate_map:
            raise DiscoveryDenied("PROCESS_LINK_UNKNOWN_CANDIDATE")
        runtime_links.append({
            "kind": "DIRECT_PROCESS",
            "process_id": link.get("pid"),
            "candidate_ids": [cid],
        })

    linked_candidate_ids = sorted({cid for link in runtime_links for cid in link["candidate_ids"]})
    linked_candidates = [
        {
            "candidate_id": cid,
            "root_id": candidate_map[cid]["root_id"],
            "relative_path": candidate_map[cid]["relative_path"],
            "extension": candidate_map[cid]["extension"],
            "sha256": candidate_map[cid]["sha256"],
        }
        for cid in linked_candidate_ids
    ]

    if runtime_links:
        result = "R7C_CONTROLLED_LAUNCHER_CANDIDATE_FOUND"
        next_action = "R7D_REVIEW_LINKED_SOURCE_ENTRYPOINT"
    elif candidates:
        result = "R7C_CONTROLLED_SOURCE_FILES_FOUND_NO_RUNTIME_BINDING"
        next_action = "R7C_BINDING_EVIDENCE_REQUIRED"
    else:
        result = "R7C_NO_CONTROLLED_LAUNCHER_FOUND"
        next_action = "SELECT_OR_CREATE_CONTROLLED_AGENT_LAUNCHER"

    return {
        "result": result,
        "controlled_root_count": len(roots),
        "file_candidate_count": len(candidates),
        "runtime_link_count": len(runtime_links),
        "linked_candidates": linked_candidates,
        "runtime_links": runtime_links,
        "next_action": next_action,
        "authentication_result": "NOT_PERFORMED",
        "authorization_status": "NOT_AUTHORIZED",
        "runtime_grant_issued": False,
        "g1_token_issued": False,
        "f2_unlocked": False,
        "authority_effect": "NONE",
    }
