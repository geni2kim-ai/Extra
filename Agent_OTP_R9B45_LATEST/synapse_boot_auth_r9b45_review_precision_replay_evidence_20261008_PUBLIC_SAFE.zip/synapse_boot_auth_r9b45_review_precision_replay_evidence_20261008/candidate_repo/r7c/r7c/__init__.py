"""R7C controlled launcher discovery. Read-only, no authority."""
