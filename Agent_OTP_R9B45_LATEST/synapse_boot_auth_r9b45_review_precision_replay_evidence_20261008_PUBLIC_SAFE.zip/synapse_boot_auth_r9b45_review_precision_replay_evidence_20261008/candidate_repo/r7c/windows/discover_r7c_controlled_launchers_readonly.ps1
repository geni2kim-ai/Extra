param(
    [Parameter(Mandatory=$true)]
    [string[]]$ControlledRoots,

    [Parameter(Mandatory=$true)]
    [string]$OutputPath,

    [string]$ServiceNameRegex = "(?i)(synapse|agent|runner|workboard|node|pc[0-9])",

    [string]$FileNameRegex = "(?i)(synapse|agent|runner|workboard|launcher|daemon|service)",

    [ValidateRange(1, 2000)]
    [int]$MaxFileCandidates = 500
)

$ErrorActionPreference = "Stop"

function Normalize-ExistingRoot([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    try {
        $full = [System.IO.Path]::GetFullPath($Value)
        if (-not (Test-Path -LiteralPath $full -PathType Container)) { return $null }
        return $full.TrimEnd('\','/')
    } catch {
        return $null
    }
}

function Is-UnderRoot([string]$Candidate, [string]$Root) {
    if ([string]::IsNullOrWhiteSpace($Candidate)) { return $false }
    try {
        $c = [System.IO.Path]::GetFullPath($Candidate)
        $r = [System.IO.Path]::GetFullPath($Root).TrimEnd('\','/') + [System.IO.Path]::DirectorySeparatorChar
        return $c.StartsWith($r, [System.StringComparison]::OrdinalIgnoreCase)
    } catch {
        return $false
    }
}

function Relative-ToRoot([string]$Candidate, [string]$Root) {
    $c = [System.IO.Path]::GetFullPath($Candidate)
    $r = [System.IO.Path]::GetFullPath($Root).TrimEnd('\','/')
    if (-not (Is-UnderRoot $c $r)) { return $null }
    return $c.Substring($r.Length).TrimStart('\','/')
}

function Account-Class([string]$StartName) {
    if ([string]::IsNullOrWhiteSpace($StartName)) { return "UNKNOWN" }
    switch -Regex ($StartName) {
        '^(LocalSystem|NT AUTHORITY\\SYSTEM)$' { return "LOCAL_SYSTEM" }
        '^NT AUTHORITY\\NETWORK SERVICE$' { return "NETWORK_SERVICE" }
        '^NT AUTHORITY\\LOCAL SERVICE$' { return "LOCAL_SERVICE" }
        '^NT SERVICE\\' { return "SERVICE_IDENTITY" }
        default { return "USER_OR_OTHER" }
    }
}

$roots = @()
$rootIndex = 0
foreach ($raw in $ControlledRoots) {
    $norm = Normalize-ExistingRoot $raw
    if (-not $norm) { continue }
    $rootIndex++
    $gitHead = $null
    $gitDirty = $null
    if (Get-Command git.exe -ErrorAction SilentlyContinue) {
        try {
            $gitHead = (& git.exe -C $norm rev-parse HEAD 2>$null | Select-Object -First 1)
            $status = (& git.exe -C $norm status --porcelain 2>$null | Out-String)
            if ($LASTEXITCODE -eq 0) { $gitDirty = -not [string]::IsNullOrWhiteSpace($status) }
        } catch {}
    }
    $roots += [ordered]@{
        root_id = ("ROOT-{0:D2}" -f $rootIndex)
        root_path = $norm
        git_head = $gitHead
        git_dirty = $gitDirty
        classification = "OPERATOR_SUPPLIED_CONTROLLED_ROOT"
    }
}

if ($roots.Count -eq 0) {
    throw "NO_VALID_CONTROLLED_ROOT"
}

$allowedExt = @(".ps1",".py",".cmd",".bat",".exe")
$candidates = @()

foreach ($root in $roots) {
    if ($candidates.Count -ge $MaxFileCandidates) { break }
    $files = Get-ChildItem -LiteralPath $root.root_path -File -Recurse -ErrorAction SilentlyContinue |
        Where-Object {
            ($allowedExt -contains $_.Extension.ToLowerInvariant()) -and
            ($_.Name -match $FileNameRegex)
        }
    foreach ($file in $files) {
        if ($candidates.Count -ge $MaxFileCandidates) { break }
        $candidates += [ordered]@{
            candidate_id = ("FILE-{0:D4}" -f ($candidates.Count + 1))
            root_id = $root.root_id
            relative_path = Relative-ToRoot $file.FullName $root.root_path
            extension = $file.Extension.ToLowerInvariant()
            sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            length = [int64]$file.Length
            full_path_local_only = $file.FullName
        }
    }
}

$services = @(Get-CimInstance Win32_Service)
$serviceLinks = @()

foreach ($svc in $services) {
    $rawPathName = [string]$svc.PathName
    $isInteresting = ($svc.Name -match $ServiceNameRegex) -or
                     ($svc.DisplayName -match $ServiceNameRegex)

    foreach ($root in $roots) {
        if ($rawPathName -and $rawPathName.IndexOf($root.root_path, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            $isInteresting = $true
        }
    }
    if (-not $isInteresting) { continue }

    $matchedIds = @()
    foreach ($cand in $candidates) {
        $full = [string]$cand.full_path_local_only
        if ($rawPathName -and $rawPathName.IndexOf($full, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            $matchedIds += $cand.candidate_id
        }
    }

    # Read common NSSM-style parameters only for matching; do not emit raw values.
    $nssmMatchIds = @()
    $paramKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc.Name)\Parameters"
    if (Test-Path -LiteralPath $paramKey) {
        try {
            $props = Get-ItemProperty -LiteralPath $paramKey
            $localStrings = @()
            foreach ($propName in @("Application","AppDirectory","AppParameters")) {
                $v = $props.$propName
                if ($v) { $localStrings += [string]$v }
            }
            foreach ($cand in $candidates) {
                foreach ($v in $localStrings) {
                    if ($v.IndexOf([string]$cand.full_path_local_only, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
                        $nssmMatchIds += $cand.candidate_id
                    }
                }
            }
        } catch {}
    }

    $serviceSid = $null
    try {
        $show = (& sc.exe showsid $svc.Name 2>&1 | Out-String)
        if ($show -match '(S-1-5-80-[0-9-]+)') { $serviceSid = $Matches[1] }
    } catch {}

    $serviceLinks += [ordered]@{
        service_name = $svc.Name
        service_state = $svc.State
        process_id = [int]$svc.ProcessId
        start_account_class = Account-Class ([string]$svc.StartName)
        service_sid = $serviceSid
        direct_candidate_ids = @($matchedIds | Sort-Object -Unique)
        wrapper_parameter_candidate_ids = @($nssmMatchIds | Sort-Object -Unique)
        raw_service_path_emitted = $false
        raw_wrapper_parameters_emitted = $false
    }
}

$processLinks = @()
$procs = @(Get-CimInstance Win32_Process)
foreach ($cand in @($candidates | Where-Object { $_.extension -eq ".exe" })) {
    foreach ($proc in $procs) {
        $pp = [string]$proc.ExecutablePath
        if ($pp -and $pp.Equals([string]$cand.full_path_local_only, [System.StringComparison]::OrdinalIgnoreCase)) {
            $processLinks += [ordered]@{
                candidate_id = $cand.candidate_id
                pid = [int]$proc.ProcessId
                process_name = [string]$proc.Name
                classification = "DIRECT_EXECUTABLE_RUNTIME_LINK"
            }
        }
    }
}

# Remove local-only full paths before serializing.
$distributedCandidates = @($candidates | ForEach-Object {
    [ordered]@{
        candidate_id = $_.candidate_id
        root_id = $_.root_id
        relative_path = $_.relative_path
        extension = $_.extension
        sha256 = $_.sha256
        length = $_.length
    }
})

$distributedRoots = @($roots | ForEach-Object {
    [ordered]@{
        root_id = $_.root_id
        root_path = $_.root_path
        git_head = $_.git_head
        git_dirty = $_.git_dirty
        classification = $_.classification
    }
})

$report = [ordered]@{
    schema_version = "SYNAPSE-R7C-CONTROLLED-LAUNCHER-DISCOVERY-1"
    collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    controlled_roots = $distributedRoots
    file_candidates = $distributedCandidates
    service_links = $serviceLinks
    process_links = $processLinks
    command_line_captured = $false
    raw_service_path_emitted = $false
    raw_wrapper_parameters_emitted = $false
    authentication_result = "NOT_PERFORMED"
    authorization_status = "NOT_AUTHORIZED"
    runtime_grant_issued = $false
    g1_token_issued = $false
    f2_unlocked = $false
    authority_effect = "NONE"
}

$report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
$sha = (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash.ToLowerInvariant()
Write-Host ("WROTE " + $OutputPath)
Write-Host ("SHA256 " + $sha)
Write-Host "AUTHORITY_EFFECT=NONE"
