#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os
from pathlib import Path
from typing import Iterable

ENV_KEYS = ("USERNAME", "USER", "COMPUTERNAME", "USERPROFILE", "HOME", "TEMP", "TMP")

def variants(value: str) -> set[str]:
    return {x for x in {value, value.replace("\\", "/"), value.replace("/", "\\")} if len(x) >= 3}

def current_host_patterns() -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    for key in ENV_KEYS:
        value = os.environ.get(key)
        if value:
            for v in variants(value):
                rows.append((f"CURRENT_{key}", v))
    return rows

def encodings(value: str) -> list[bytes]:
    return [
        value.encode("utf-8", errors="ignore"),
        value.encode("utf-16le", errors="ignore"),
        value.encode("utf-16be", errors="ignore"),
    ]

def commitment(value: str) -> dict[str, object]:
    return {"sha256": hashlib.sha256(value.encode("utf-8")).hexdigest(), "length": len(value)}

def load_source_material(paths: Iterable[str]) -> tuple[list[tuple[str, str, str]], list[str]]:
    rows: list[tuple[str, str, str]] = []
    source_ids: list[str] = []
    for raw in paths:
        doc = json.loads(Path(raw).read_text(encoding="utf-8-sig"))
        if doc.get("schema_version") != "SYNAPSE-PRIVACY-SOURCE-MATERIAL-1":
            raise ValueError("PRIVACY_SOURCE_MATERIAL_SCHEMA_INVALID")
        source_id = str(doc.get("source_id") or "")
        if not source_id:
            raise ValueError("PRIVACY_SOURCE_ID_MISSING")
        source_ids.append(source_id)
        for p in doc.get("patterns") or []:
            literal = p.get("literal")
            if isinstance(literal, str) and len(literal) >= 3:
                rows.append((source_id, str(p.get("class") or "SOURCE"), literal))
    return rows, source_ids

def scan_tree(root: Path, patterns: list[tuple[str, str, str]], exclude: set[Path]) -> list[dict]:
    excluded = {p.resolve() for p in exclude}
    hits: list[dict] = []
    for p in root.rglob("*"):
        if not p.is_file() or p.resolve() in excluded:
            continue
        data = p.read_bytes()
        for source_id, label, literal in patterns:
            found = False
            count = 0
            for b in encodings(literal):
                if not b:
                    continue
                c = data.count(b)
                if c:
                    found = True
                    count = max(count, c)
            if found:
                hits.append({
                    "file": p.relative_to(root).as_posix(),
                    "source_id": source_id,
                    "pattern_class": label,
                    "match_count": count,
                })
    return hits

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("-o", "--output", required=True)
    ap.add_argument("--source-material", action="append", default=[])
    ap.add_argument("--require-source-id", action="append", default=[])
    ns = ap.parse_args()

    patterns: list[tuple[str, str, str]] = [
        ("CURRENT_HOST", label, literal) for label, literal in current_host_patterns()
    ]
    imported, imported_ids = load_source_material(ns.source_material)
    patterns.extend(imported)

    missing = sorted(set(ns.require_source_id) - set(imported_ids))
    out = Path(ns.output)
    hits = scan_tree(Path(ns.root), patterns, {out, *(Path(x) for x in ns.source_material)})

    if missing:
        status = "PRIVACY_SOURCE_COVERAGE_INCOMPLETE"
    elif hits:
        status = "BLOCKED_PRIVACY_MATCH"
    else:
        status = "PASS"

    report = {
        "schema_version": "SYNAPSE-DISTRIBUTABLE-PRIVACY-SEAL-2",
        "scan_mode": "RAW_BYTES_UTF8_UTF16LE_UTF16BE",
        "current_host_pattern_count": sum(1 for s, _, _ in patterns if s == "CURRENT_HOST"),
        "imported_source_ids": sorted(set(imported_ids)),
        "required_source_ids": sorted(set(ns.require_source_id)),
        "missing_required_source_ids": missing,
        "pattern_commitments": [
            {
                "source_id": source_id,
                "class": label,
                **commitment(literal),
            }
            for source_id, label, literal in patterns
        ],
        "matches": hits,
        "status": status,
        "authority_effect": "NONE",
    }
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "matches": len(hits), "missing_source_ids": missing}, indent=2))
    return 0 if status == "PASS" else 2

if __name__ == "__main__":
    raise SystemExit(main())
