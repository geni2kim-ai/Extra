#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, os
from pathlib import Path

ENV_KEYS = ("USERNAME", "USER", "COMPUTERNAME", "USERPROFILE", "HOME", "TEMP", "TMP")

def variants(value: str) -> list[str]:
    vals = {value, value.replace("\\", "/"), value.replace("/", "\\")}
    return sorted(v for v in vals if len(v) >= 3)

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-id", required=True)
    ap.add_argument("--extra", action="append", default=[])
    ap.add_argument("-o", "--output", required=True)
    ns = ap.parse_args()

    literals: list[dict[str, str]] = []
    seen: set[str] = set()
    for key in ENV_KEYS:
        value = os.environ.get(key)
        if not value:
            continue
        for v in variants(value):
            if v.casefold() in seen:
                continue
            seen.add(v.casefold())
            literals.append({"class": f"ENV_{key}", "literal": v})
    for i, value in enumerate(ns.extra, 1):
        for v in variants(value):
            if v.casefold() in seen:
                continue
            seen.add(v.casefold())
            literals.append({"class": f"EXTRA_{i:03d}", "literal": v})

    result = {
        "schema_version": "SYNAPSE-PRIVACY-SOURCE-MATERIAL-1",
        "source_id": ns.source_id,
        "patterns": literals,
        "commitments": [
            {
                "class": row["class"],
                "sha256": hashlib.sha256(row["literal"].encode("utf-8")).hexdigest(),
                "length": len(row["literal"]),
            }
            for row in literals
        ],
        "distribution": "LOCAL_ONLY_DO_NOT_PACKAGE",
    }
    Path(ns.output).write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"source_id": ns.source_id, "patterns": len(literals), "distribution": result["distribution"]}))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
