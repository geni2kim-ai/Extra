from __future__ import annotations
import importlib.util, json
from pathlib import Path

P = Path(__file__).parents[1] / "distribution" / "privacy_seal.py"
spec = importlib.util.spec_from_file_location("privacy_v2", P)
m = importlib.util.module_from_spec(spec); assert spec.loader
spec.loader.exec_module(m)

def test_source_material_import_and_scan(tmp_path):
    material = tmp_path / "source.json"
    material.write_text(json.dumps({
        "schema_version": "SYNAPSE-PRIVACY-SOURCE-MATERIAL-1",
        "source_id": "NODE-A",
        "patterns": [{"class": "ACCOUNT", "literal": "ALPHA_TEST_USER"}],
        "commitments": [],
        "distribution": "LOCAL_ONLY_DO_NOT_PACKAGE",
    }), encoding="utf-8")
    imported, ids = m.load_source_material([str(material)])
    assert ids == ["NODE-A"]
    assert imported == [("NODE-A", "ACCOUNT", "ALPHA_TEST_USER")]

    stage = tmp_path / "stage"; stage.mkdir()
    (stage / "log.txt").write_text("x ALPHA_TEST_USER y", encoding="utf-8")
    hits = m.scan_tree(stage, imported, set())
    assert hits and hits[0]["source_id"] == "NODE-A"

def test_utf16_source_pattern_detected(tmp_path):
    stage = tmp_path / "stage"; stage.mkdir()
    (stage / "x.bin").write_bytes("ALPHA_TEST_USER".encode("utf-16le"))
    hits = m.scan_tree(stage, [("NODE-A","ACCOUNT","ALPHA_TEST_USER")], set())
    assert hits

def test_commitment_does_not_echo_literal():
    c = m.commitment("ALPHA_TEST_USER")
    assert "ALPHA_TEST_USER" not in json.dumps(c)
