from __future__ import annotations
from copy import deepcopy
from r7c.evaluator import evaluate, DiscoveryDenied

def base():
    return {
        "schema_version": "SYNAPSE-R7C-CONTROLLED-LAUNCHER-DISCOVERY-1",
        "controlled_roots": [
            {"root_id": "ROOT-01", "root_path": "ROOT_MASKED", "git_head": "abc", "git_dirty": False}
        ],
        "file_candidates": [
            {
                "candidate_id": "FILE-0001",
                "root_id": "ROOT-01",
                "relative_path": "agent/runner.py",
                "extension": ".py",
                "sha256": "a" * 64,
                "length": 100,
            }
        ],
        "service_links": [],
        "process_links": [],
        "command_line_captured": False,
        "raw_service_path_emitted": False,
        "raw_wrapper_parameters_emitted": False,
        "authentication_result": "NOT_PERFORMED",
        "authorization_status": "NOT_AUTHORIZED",
        "runtime_grant_issued": False,
        "g1_token_issued": False,
        "f2_unlocked": False,
        "authority_effect": "NONE",
    }

def test_source_without_runtime_binding_is_valid_stop():
    r = evaluate(base())
    assert r["result"] == "R7C_CONTROLLED_SOURCE_FILES_FOUND_NO_RUNTIME_BINDING"
    assert r["authority_effect"] == "NONE"

def test_service_link_promotes_only_to_candidate_found():
    d = base()
    d["service_links"] = [{
        "service_name": "agent-runner",
        "service_state": "Running",
        "process_id": 123,
        "service_sid": "S-1-5-80-1",
        "direct_candidate_ids": [],
        "wrapper_parameter_candidate_ids": ["FILE-0001"],
    }]
    r = evaluate(d)
    assert r["result"] == "R7C_CONTROLLED_LAUNCHER_CANDIDATE_FOUND"
    assert r["next_action"] == "R7D_REVIEW_LINKED_SOURCE_ENTRYPOINT"
    assert r["authorization_status"] == "NOT_AUTHORIZED"

def test_direct_process_link_counts():
    d = base()
    d["process_links"] = [{"candidate_id": "FILE-0001", "pid": 999, "process_name": "runner.exe"}]
    r = evaluate(d)
    assert r["runtime_link_count"] == 1

def test_unknown_candidate_link_denied():
    d = base()
    d["service_links"] = [{
        "service_name": "x", "direct_candidate_ids": ["FILE-9999"], "wrapper_parameter_candidate_ids": []
    }]
    try:
        evaluate(d)
    except DiscoveryDenied as e:
        assert e.code == "SERVICE_LINK_UNKNOWN_CANDIDATE"
    else:
        assert False

def test_raw_service_path_forbidden():
    d = base(); d["raw_service_path_emitted"] = True
    try:
        evaluate(d)
    except DiscoveryDenied as e:
        assert e.code == "RAW_SERVICE_PATH_FORBIDDEN"
    else:
        assert False

def test_commandline_capture_forbidden():
    d = base(); d["command_line_captured"] = True
    try:
        evaluate(d)
    except DiscoveryDenied as e:
        assert e.code == "COMMAND_LINE_CAPTURE_FORBIDDEN"
    else:
        assert False

def test_authority_flag_denied():
    d = base(); d["f2_unlocked"] = True
    try:
        evaluate(d)
    except DiscoveryDenied as e:
        assert e.code == "AUTHORITY_FLAG_TRUE"
    else:
        assert False
