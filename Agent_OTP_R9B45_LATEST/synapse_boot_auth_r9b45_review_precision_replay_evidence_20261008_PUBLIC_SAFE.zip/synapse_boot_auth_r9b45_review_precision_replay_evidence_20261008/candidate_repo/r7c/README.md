# R7C — project-controlled launcher/runner discovery

Status: `CANDIDATE / READ-ONLY / NO AUTHORITY`

R7B showed that the installed desktop process has no confirmed project-controlled hook boundary.

R7C searches only operator-supplied controlled roots and correlates candidate launcher/source files with:
- Windows service configuration,
- common NSSM-style service parameters,
- directly running controlled executables.

The raw service command line and NSSM parameters are used only for local matching and are **not emitted**.

A controlled script/file being found still does not prove a workload identity.

Permitted results:
- `R7C_CONTROLLED_LAUNCHER_CANDIDATE_FOUND`
- `R7C_CONTROLLED_SOURCE_FILES_FOUND_NO_RUNTIME_BINDING`
- `R7C_NO_CONTROLLED_LAUNCHER_FOUND`

Only the first result is eligible for an R7D source review.
