# Synapse Boot Auth R6 successor package

Input YM R4.1/R5.1 package SHA-256: `8b7af810641f776c701984fd87e77f6799c1532f9d20d1367da0792f412d3a74`

Leonardo disposition:
- YM evidence accepted.
- TPM path remains correctly blocked on YM because TPM was measured absent.
- R6 proceeds independently to test kernel/OS-observed workload capture.
- no TPM bypass or software-key downgrade is introduced.

Current environment executed the Python policy/static contract tests only.
Windows C# `Add-Type` compilation and Named Pipe loopback remain `NOT_RUN` until YM executes the work packet.


R7A read-only real-workload discovery has been added. R6.3 functional PASS is accepted; live authority remains NONE.


R7B read-only hook source/control assessment added. No injection or authority issuance is permitted.


R7C read-only controlled launcher/runner discovery added. Installed opaque desktop binaries remain excluded as hook targets.


R7C.1 reference-first discovery and R7D bounded source-root locator added. Authority remains NONE.


R7D.1 portability fix and R8 synthetic controlled-launcher rehearsal added; child identity remains NOT_PROVED.


R8.1 adds OS parent-PID binding. R8B defines an unauthenticated mediator / untrusted-child boundary; no child identity is promoted.


R8B.1 opaque child mediation rehearsal and R9 dedicated mediator identity requirements added. Shared-interpreter mediator authentication is blocked.


R8B.2 bounded I/O policy and R9A dedicated mediator executable candidate added. No mediator/child authentication or authority is enabled.


R9A.1 replaces the environment-sensitive PowerShell encoded-command synthetic child with a separately packaged helper executable. No authentication/authority is enabled.


R9A.2 adds bounded, process-instance-anchored retry for transient WMI child path observation. No authentication or authority is enabled.


R9A.3 replaces WMI/.NET property-based child identity evidence with native process-handle-bound Windows APIs. No authentication or authority is enabled.


R9A.3.1 fixes portable matrix exit-code evidence capture. R9B defines verifier-derived local workload measurement but explicitly remains MEASURED_NOT_AUTHENTICATED.


R9B.1 adds a local Named Pipe client mode to the dedicated mediator for verifier-derived workload measurement only. Result ceiling is MEASURED_NOT_AUTHENTICATED; node identity and G1/F2 remain unbound/closed.


R9B.2 separates registry provisioning from measurement and requires an exact registry SHA pin. Result ceiling remains MEASURED_NOT_AUTHENTICATED; G1/F2 stay closed.

R9B.3 remediates the R9B.2 adversarial findings: external operator SHA inputs, pinned R6 evidence-producer source, run/session/pipe/nonce/freshness binding, robust failure cleanup, SID-aware privacy sealing, assignment-aware PowerShell lint, and regenerated current integrity metadata. It remains MEASURED_NOT_AUTHENTICATED and review-gate blocked.


R9B.4 addresses R9B.3 independent-review evidence gaps with a compiled pinned verifier server, one-time local replay ledger, runtime PID/time cross-binding, derived cleanup receipts, forced cleanup probing, and a review-safe re-bound evidence set. R9C remains blocked.

## R9B.4.1 correction

The previously issued R9B.4 ZIP is `DO_NOT_RUN_REPACKAGE_REQUIRED`.

R9B.4.1 restores all referenced core files, reinstates the authority-ceiling checks, replaces the flawed cleanup
probe with a production-harness timeout probe using the shared cleanup module, adds post-run SHA checks, and adds
clean-extract/reference-completeness release gates.

Use only `handoff/YM_R9B41_WORK_PACKET.md` for the next Windows rehearsal.

## R9B.4.2 verifier PID contract correction

Real R9B.4.1 Windows execution exposed a producer/evaluator mismatch: the evaluator required verifier PIDs that the verifier server did not emit. R9B.4.2 emits `capture.verifier.pid` and `completion.verifier_pid` from one `selfPid`, keeps the evaluator strict, and adds a release regression test.

Use only `handoff/YM_R9B42_WORK_PACKET.md`. Windows rehearsal and independent/HUMAN review remain required.

## R9B.4.4 HUMAN review completeness / cleanup hardening

R9B.4.4 is a review/evaluator hardening step on top of the accepted R9B.4.2 Windows evidence.

It does not relabel the historical Windows live run as an R9B.4.4 live run.

New items:
- strict cleanup receipt validation;
- standalone timeout/tree/wrong-SID cleanup evidence validator;
- self-contained HUMAN toolchain;
- byte-identical runtime replay/cleanup evidence supplement;
- corrected V2 question traceability;
- full review-safe rebinding map;
- measured-vs-pass-through classification.

R9C remains blocked pending an explicit HUMAN verdict.

## R9B.4.5 review-evidence precision

R9B.4.5 narrows three remaining review precision gaps:

- automatic complete privacy/rebinding inventory;
- packaged-vs-runtime evidence-byte provenance;
- self-describing replay success/denial results.

Use only `handoff/YM_R9B45_WORK_PACKET.md` for the next fresh Windows evidence run.

R9C remains blocked pending fresh R9B.4.5 evidence and an explicit HUMAN verdict.

