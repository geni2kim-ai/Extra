from pathlib import Path
import json
ROOT=Path(__file__).parents[1]
def test_doc_blocks_shared_interpreter_auth():
    t=(ROOT/"R9_MEDIATOR_IDENTITY_REQUIREMENTS.md").read_text(encoding="utf-8")
    assert "must **not** be promoted directly" in t
    assert "R9_DEDICATED_MEDIATOR_BINARY_REQUIRED" in t
    assert "opaque child" in t.lower()
def test_schema_has_no_active_status():
    d=json.loads((ROOT/"schemas"/"mediator_identity_candidate.schema.json").read_text())
    assert d["properties"]["status"]["const"]=="CANDIDATE"
    assert d["properties"]["authority_effect"]["const"]=="NONE"
