# R9 — dedicated mediator identity requirements

Status: `PREP / BLOCKED ON DEDICATED WORKLOAD IDENTITY`

## Problem

The current mediator prototype is a PowerShell script. OS process evidence sees the shared interpreter
`powershell.exe`. Under the same user SID, different scripts can have the same executable path/hash.

Therefore a PowerShell-hosted mediator must **not** be promoted directly to an authenticated workload principal.

## Required before live mediator authentication

At least one uniquely OS-observable workload boundary:

1. dedicated mediator executable with exact binary SHA-256, or
2. dedicated Windows service identity/service SID bound to controlled executable, or
3. equivalent protected workload identity observable by the verifier.

## R9 principal rule

Future runtime grant, if ever enabled, binds to the authenticated mediator only.

The opaque child:
- remains `NOT_PROVED`,
- receives no credential/token/grant,
- cannot select node/principal/capabilities,
- contributes only `UNTRUSTED_CHILD_INPUT`.

## Current gate

`R9_DEDICATED_MEDIATOR_BINARY_REQUIRED`

No G1/F2 activation is permitted.
