# Measurement claim classification

This file prevents the HUMAN review from treating every serialized SHA as a verifier-observed measurement.

## Directly observed/measured by the verifier-server path

- named-pipe peer PID from `GetNamedPipeClientProcessId`;
- process creation time from the opened process handle;
- OS-reported process image path;
- on-disk client executable SHA-256 at that path;
- impersonated client token SID;
- verifier's own running PID;
- verifier's own on-disk executable SHA-256;
- request payload / measurement nonce as received through the pipe.

## Bound inputs passed into the verifier process

These values are serialized by the verifier but are supplied through its command line:

- `verifier_source_sha256`;
- `preflight_sha256`;
- `run_context_sha256`;
- `build_receipt_sha256`.

Their security value comes from cross-checking in the harness/evaluator and external rehearsal pins, not from the verifier
independently measuring those objects.

## Derived/checked outside the verifier process

- external operator SHA pins;
- harness server/client PID cross-bindings;
- post-run SHA revalidation;
- replay-ledger one-time consumption;
- timeout/tree cleanup receipts;
- review-safe transformed/re-bound hashes.

## Explicit residuals

- source -> binary reproducibility is not proven (`deterministic_build_verified=false`);
- executable hashing is on-disk, not loaded-image measurement;
- the rehearsal is same-user and does not establish principal authentication;
- producer-owned GitHub anchor is an immutable publication/binding, not an independent attestation.
