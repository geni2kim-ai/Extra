# QUESTION_TRACEABILITY_V2

This table follows the current HUMAN V2 question numbering exactly.

| V2 | Question | Evidence in this packet | Limits |
|---|---|---|---|
| Q1 | sealed bytes + anchor | `R9B43_review_bundle.zip`, `ANCHOR_SEMANTICS.md`, external Git commit reference in `HUMAN_REVIEW_REQUEST_V3.md` | Producer-owned immutable publication, not independent attestation |
| Q2 | measurement bindings | sealed `capture/harness/completion/cleanup` + `toolchain/r9b4/evaluator.py` + `runtime_evidence/deliverable/R9B4_live_result.json` | Measurement-only; on-disk image SHA |
| Q3 | verifier/server binding | sealed `VerifierServer.cs`, `toolchain/src/VerifierServer.cs`, `lineage/R9B41_TO_R9B42_candidate.patch`, `MEASURED_VS_BOUND_INPUTS.md` | PID consistency is stronger than source->binary provenance; source SHA is pass-through input |
| Q4 | authority ceiling | `runtime_evidence/evidence/negatives/authority_ceiling_summary.json`, hardened evaluator source/tests | No runtime authority granted |
| Q5 | replay | `runtime_evidence/deliverable/R9B4_live_result.json`, `R9B4_live_result_dup.json`, `replay_ledger_digest.json`, `toolchain/r9b4/replay.py` | Local retained-ledger consumption only, not global/network anti-replay |
| Q6 | cleanup | timeout/tree/wrong-SID files under `runtime_evidence/evidence/probes/`, `toolchain/windows/R9B4Cleanup.psm1`, `toolchain/validate_cleanup_evidence.py` | Same-user rehearsal; cleanup validator is R9B.4.4 review hardening |
| Q7 | privacy/rebinding | sealed `PRIVACY_SCAN.json`, `TRANSFORMATION_RECEIPT.json`, this packet `REBINDING_MAP.json` | Review set is transformed/re-bound, not raw runtime bytes |
| Q8 | residuals acceptable for R9C design? | `MEASURED_VS_BOUND_INPUTS.md`, `ANCHOR_SEMANTICS.md`, `KNOWN_RESIDUALS_V3.md` | HUMAN judgment required |
| Q9 | findings requiring remediation? | `KNOWN_RESIDUALS_V3.md`, CodeDiff feedback commit `9958d130a542f1ae7d9e28bae8fb9ec99641fc20` | HUMAN judgment required |
| Q10 | acceptance limitations | `decision/HUMAN_REVIEW_DECISION_V3.json` template | ACCEPT permits R9C design only; no runtime/G1/F2/production authority |
