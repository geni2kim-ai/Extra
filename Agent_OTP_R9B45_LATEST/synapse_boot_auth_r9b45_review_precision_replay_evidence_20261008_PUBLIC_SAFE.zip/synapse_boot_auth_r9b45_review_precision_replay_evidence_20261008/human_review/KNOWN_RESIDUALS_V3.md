# Known residuals for HUMAN review

- Operator-supplied SHA pins are rehearsal provenance, not a protected/non-exportable credential.
- Client/verifier executable SHA is an on-disk file measurement, not loaded-memory image attestation.
- The Windows rehearsal is same-user; it does not prove distinct-principal authentication.
- Pipe name / nonce secrecy is not a security boundary; a same-user process can cause fail-closed availability loss.
- `verifier_source_sha256`, `preflight_sha256`, `run_context_sha256`, and `build_receipt_sha256` are bound inputs passed into the verifier, not verifier-observed measurements.
- Source-to-binary reproducibility is not proven.
- Local replay ledger semantics are limited to one-time consumption within the retained ledger namespace.
- Review evidence is privacy-transformed and re-bound, not raw runtime bytes.
- GitHub anchor is producer-owned immutable publication, not independent attestation.
- CodeDiff v2.6 remains review/sensor infrastructure, not approval authority.
