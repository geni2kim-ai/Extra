# Evaluator version note — R9B.4.5

Historical live Windows evidence was produced with R9B.4.2.

R9B.4.4 added cleanup-evidence validation.

R9B.4.5 retains the R9B.4.4 cleanup hardening and adds self-describing replay execution binding.

Current R9B.4.5 hashes:

- evaluator CLI: `da459f8f640b0daa9a4dcc351d9f4f857ec01850cc577864c08ef8788fb7f2fd`
- evaluator core: `20586568eeb526dca1472faf7ee1291dd2621d571cdfd95301b926925651f575`
- replay implementation: `5574e3a84a511383ba504be3061b39d185ed716490fb4cb254fe0b3a1f038ba4`

R9B.4.5 requires a **fresh Windows first/duplicate evaluation** because historical duplicate output cannot be
retroactively supplied with evaluator/input/timestamp fields.

A final HUMAN review should use the fresh R9B.4.5 evidence returned by that work unit.

The historical R9B.4.2 evidence remains useful background evidence only.
