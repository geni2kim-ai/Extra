# Evidence byte provenance

The runtime-evidence supplement is copied byte-for-byte from entries in:

`ym_r9b42_package_20261008.zip`

Source ZIP SHA-256:

`4298587e16c9836da66765aabf7620f22ebc83ebfbd9f387333493e0b0995354`

External digest publication:

- repository: `geni2kim-ai/PR-with-codediff-finder`
- path: `docs/anchors/20261008_R9B42_YM_return_source_zip_anchor.json`
- commit: `69a49faa35b56d48e9e3067e5f484b443735df67`

This **does not** mean every packaged text file is byte-identical to the original Windows runtime file.

`runtime_evidence/EVIDENCE_PROVENANCE_V2.json` distinguishes:

- packaged YM-return entry SHA;
- Windows harness-recorded runtime SHA where available;
- LF -> CRLF reconstruction relation where independently confirmed.

Three reviewed files have a confirmed line-ending relation:
timeout cleanup receipt, wrong-SID cleanup receipt, and wrong-SID server stderr.

The semantic evidence remains useful, but runtime-byte identity is not claimed for those normalized files.
