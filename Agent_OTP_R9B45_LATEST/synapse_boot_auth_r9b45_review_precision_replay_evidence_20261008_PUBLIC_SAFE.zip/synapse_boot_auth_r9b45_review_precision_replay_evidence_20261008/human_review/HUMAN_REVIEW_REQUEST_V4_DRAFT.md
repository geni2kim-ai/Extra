# HUMAN review request V4 — DRAFT, activate only after R9B.4.5 fresh Windows evidence returns

Do not issue a HUMAN verdict from this draft yet.

Before final review, the returned R9B.4.5 package must demonstrate:

- first live evaluation PASS with complete `execution_binding`;
- immediate same-ledger duplicate `RUN_TOKEN_ALREADY_CONSUMED`;
- exact equality of evaluator CLI/core/replay hashes across first/duplicate;
- exact equality of run_id, nonce, `input_set_sha256`, and input bindings;
- automatic review-safe change inventory including `/preflight/allowed_user_sid`;
- review-safe offline verifier PASS;
- evidence provenance report distinguishing packaged bytes from runtime hashes;
- existing authority/pin/cleanup/wrong-SID regressions remain PASS.

Only after those checks should this be converted into the final HUMAN request.
