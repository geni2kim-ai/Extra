# Replay evidence precision

## Historical R9B.4.2 evidence

The historical first live result and duplicate denial remain valid evidence of:

- first live measurement evaluation success;
- local replay-ledger token creation;
- second evaluation denial with `RUN_TOKEN_ALREADY_CONSUMED`.

However, the historical duplicate output does **not** record its own:

- evaluation timestamp;
- evaluator CLI SHA;
- evaluator-core SHA;
- replay implementation SHA;
- run_id / nonce;
- exact evidence input-set digest.

Therefore R9B.4.5 does not overclaim that the historical duplicate JSON alone proves command/input identity.

## R9B.4.5 closure requirement

A fresh Windows run must produce first and duplicate results from the R9B.4.5 evaluator CLI.

Both results must include `execution_binding`.

For the duplicate to close the precision gap:

- `evaluator_cli_sha256` must match between first and duplicate;
- `evaluator_core_sha256` must match;
- `replay_impl_sha256` must match;
- `run_id` and `measurement_nonce` must match;
- `input_set_sha256` must match;
- the duplicate evaluation timestamp must be later;
- duplicate result must be `R9B4_DENIED / RUN_TOKEN_ALREADY_CONSUMED`.

This remains local retained-ledger replay evidence, not global/network anti-replay.
