# R9B.4.1 -> R9B.4.2 change note

The R9B.4.1 Windows run exposed a producer/evaluator contract defect:

- evaluator required `capture.verifier.pid`;
- evaluator required `completion.verifier_pid`;
- the R9B.4.1 verifier server emitted neither field.

R9B.4.2 changed the verifier producer to obtain one `selfPid` from the running server process and emit:

- `capture.verifier.pid = selfPid`;
- `completion.verifier_pid = selfPid`.

The evaluator PID equality checks were not relaxed.

The exact synthetic package diff is included as `R9B41_TO_R9B42_candidate.patch`.

This lineage is package-diff evidence, not an upstream Git authority statement.
