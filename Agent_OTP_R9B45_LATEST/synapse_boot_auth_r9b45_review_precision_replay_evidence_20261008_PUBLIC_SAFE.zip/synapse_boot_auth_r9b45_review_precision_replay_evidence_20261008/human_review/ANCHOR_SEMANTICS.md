# External anchor semantics

The R9B.4.3 review ZIP is externally bound at:

- repository: `geni2kim-ai/PR-with-codediff-finder`
- commit: `e9a113bf454fd36f68709504fea870e92b0e3155`
- path: `docs/anchors/20261008_R9B43_review_bundle_anchor.json`
- sealed ZIP SHA-256: `f040b1f81780ac233335b3d769782fa3a6e868afde611b3350c77ef50461e778`

This proves a producer-owned immutable publication at that Git commit.

It does **not** prove:
- reviewer independence;
- third-party authorship;
- independent cryptographic attestation of the underlying Windows run.

Reviewer independence comes only from the HUMAN reviewer and must be stated in the final decision.
