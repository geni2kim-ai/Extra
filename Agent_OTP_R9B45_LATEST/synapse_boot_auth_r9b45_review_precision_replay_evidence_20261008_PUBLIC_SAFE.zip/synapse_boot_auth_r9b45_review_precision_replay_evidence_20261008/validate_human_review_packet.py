#!/usr/bin/env python3
from __future__ import annotations
import argparse,hashlib,json,zipfile
from pathlib import Path

REQUIRED=[
 "human_review/R9B43_review_bundle.zip",
 "human_review/HUMAN_REVIEW_REQUEST_V4_DRAFT.md",
 "human_review/REPLAY_EVIDENCE_PRECISION.md",
 "human_review/EVIDENCE_BYTE_PROVENANCE.md",
 "human_review/runtime_evidence/SOURCE_DIGESTS.json",
 "human_review/runtime_evidence/EVIDENCE_PROVENANCE_V2.json",
 "human_review/toolchain/TOOLCHAIN_SHA256.json",
 "human_review/toolchain/evaluate_r9b4.py",
 "human_review/toolchain/r9b4/evaluator.py",
 "human_review/toolchain/r9b4/replay.py",
 "human_review/toolchain/distribution/make_review_safe_bundle.py",
 "human_review/decision/HUMAN_REVIEW_DECISION_V3.json"
]
SEALED_SHA="f040b1f81780ac233335b3d769782fa3a6e868afde611b3350c77ef50461e778"

def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda:f.read(1024*1024),b""):h.update(c)
    return h.hexdigest()

def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument("--root",default=".");ap.add_argument("-o","--output",required=True)
    ns=ap.parse_args();root=Path(ns.root).resolve()
    missing=[x for x in REQUIRED if not (root/x).is_file()]
    issues=[]

    sealed=root/"human_review/R9B43_review_bundle.zip"
    if sealed.is_file():
        if sha(sealed)!=SEALED_SHA:issues.append("SEALED_REVIEW_ZIP_SHA_MISMATCH")
        else:
            with zipfile.ZipFile(sealed) as z:
                if z.testzip() is not None:issues.append("SEALED_REVIEW_ZIP_CRC_FAILURE")

    tm=root/"human_review/toolchain/TOOLCHAIN_SHA256.json"
    if tm.is_file():
        d=json.loads(tm.read_text(encoding="utf-8"))
        for rel,digest in d.get("files",{}).items():
            p=root/"human_review/toolchain"/rel
            if not p.is_file():issues.append("TOOL_MISSING:"+rel)
            elif sha(p)!=digest:issues.append("TOOL_SHA_MISMATCH:"+rel)

    sm=root/"human_review/runtime_evidence/SOURCE_DIGESTS.json"
    if sm.is_file():
        d=json.loads(sm.read_text(encoding="utf-8"))
        if d.get("copy_semantics")!="PACKAGED_YM_RETURN_ZIP_ENTRY_BYTES_ONLY":
            issues.append("SOURCE_COPY_SEMANTICS_INVALID")
        if d.get("runtime_byte_identity_claimed") is not False:
            issues.append("RUNTIME_BYTE_IDENTITY_MUST_NOT_BE_CLAIMED")

    pv=root/"human_review/runtime_evidence/EVIDENCE_PROVENANCE_V2.json"
    if pv.is_file():
        d=json.loads(pv.read_text(encoding="utf-8"))
        required=[
          "evidence/probes/R9B42_timeout_probe/cleanup_receipt.json",
          "evidence/probes/R9B4_wrongsid/cleanup_receipt.json",
          "evidence/probes/R9B4_wrongsid/server.stderr.txt"
        ]
        for rel in required:
            item=d.get("files",{}).get(rel,{})
            if item.get("normalization_relation")!="PACKAGED_LF_TO_CRLF_RECONSTRUCTION_MATCHES_HARNESS":
                issues.append("NORMALIZATION_RELATION_NOT_PROVEN:"+rel)

    decision=root/"human_review/decision/HUMAN_REVIEW_DECISION_V3.json"
    if decision.is_file():
        d=json.loads(decision.read_text(encoding="utf-8"))
        if not str(d.get("verdict","")).startswith("<"):issues.append("HUMAN_DECISION_WAS_PRE_FILLED")

    status="PASS" if not missing and not issues else "FAIL"
    out={"schema_version":"SYNAPSE-R9B45-PREHUMAN-PACKET-COMPLETENESS-1","status":status,
         "required_count":len(REQUIRED),"missing_required":missing,"issues":issues,
         "fresh_windows_evidence_required":True,"human_verdict":"PENDING","authority_effect":"NONE"}
    Path(ns.output).write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8",newline="\n")
    print(json.dumps(out,indent=2))
    return 0 if status=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
