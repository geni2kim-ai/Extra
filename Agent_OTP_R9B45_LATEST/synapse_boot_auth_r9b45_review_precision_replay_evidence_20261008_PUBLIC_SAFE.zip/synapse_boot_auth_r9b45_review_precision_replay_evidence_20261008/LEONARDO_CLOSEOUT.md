# Leonardo closeout — R9B.4.5 static evidence-precision candidate

The non-authoritative R9B.4.4 review is adopted without treating it as a HUMAN verdict.

## R1 — rebinding precision

Fixed in the generator:
- privacy transforms run recursively across all review JSON;
- final change inventory is generated automatically by comparing original vs final review documents;
- `preflight.allowed_user_sid` is therefore no longer dependent on a hand-maintained list;
- all derived SHA rebinding changes are automatically enumerated.

Synthetic review-safe round trip verifies `/preflight/allowed_user_sid` is present.

## R2 — evidence-byte provenance

The prior phrase `copied_byte_for_byte` was too broad.

R9B.4.5 now says:
- byte-identical to the **packaged YM return ZIP entry**;
- runtime-byte identity is not claimed when the harness digest differs.

The provenance builder independently reproduces:
- timeout cleanup LF -> CRLF -> harness SHA match;
- wrong-SID cleanup LF -> CRLF -> harness SHA match;
- wrong-SID server stderr LF -> CRLF -> harness SHA match.

The source YM ZIP digest is separately published at GitHub commit
`69a49faa35b56d48e9e3067e5f484b443735df67`.

## R3/R4 — replay precision and evaluator version

Historical evidence cannot be made self-describing after the fact.

R9B.4.5 evaluator CLI now records on success and denial:
- evaluation start/end time;
- CLI/core/replay implementation SHA;
- run_id / nonce;
- deterministic input-set SHA;
- complete input-binding map.

A fresh Windows first/duplicate evaluation is therefore required.

## Static verification

- R9B.4.5 pytest: 59 passed / 0 failed
- PowerShell semantic lint: PASS / 0 findings
- evidence provenance builder: PASS
- automatic preflight SID inventory assertion: PASS

The full historical 23-suite regression was not rerun in this packaging turn due the bounded execution environment.
The prior R9B.4.4 package's 270/270 regression evidence remains historical evidence, not a new R9B.4.5 claim.

Current state:

`R9B45_REVIEW_EVIDENCE_PRECISION_STATIC_CANDIDATE`
`FRESH_WINDOWS_EVALUATION_REQUIRED`
`HUMAN_VERDICT_PENDING`
`R9C_BLOCKED`

Security ceiling remains:

`MEASURED_NOT_AUTHENTICATED / UNBOUND / NOT_AUTHORIZED / NONE`.
